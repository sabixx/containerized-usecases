var searchData=
[
  ['unlockxplmutex',['UnlockXplMutex',['../group__Xpl.html#ga2ca25328e8fd40fa588bd8b8ea6fa1a0',1,'platform.h']]],
  ['urldecode',['UrlDecode',['../group__Xpl.html#ga20467a464fdf745a607e65a3d746aefa',1,'platform.h']]],
  ['urlencode',['UrlEncode',['../group__Xpl.html#ga3dac8b90496c1615047c7985390e4af6',1,'platform.h']]],
  ['utf8cpdisplaylen',['Utf8CPDisplayLen',['../group__Xpl.html#gaff889827cbb8b2b59c2275c82624f81c',1,'platform.h']]],
  ['utf8cplen',['Utf8CPLen',['../group__Xpl.html#gab41012369ac89649d0127ddd1b13c46c',1,'platform.h']]],
  ['utf8cpsize',['Utf8CPSize',['../group__Xpl.html#gad5df30e4a54fe08c666677332177c40f',1,'platform.h']]],
  ['utf8displaylen',['Utf8DisplayLen',['../group__Xpl.html#ga0521c10e4c052f3697bd6eca40fee4ef',1,'platform.h']]],
  ['utf8strlen',['Utf8Strlen',['../group__Xpl.html#ga9ae43a84df3f03c3ef8ed2d1a97a1781',1,'platform.h']]]
];
