var searchData=
[
  ['stackcreate',['StackCreate',['../group__Xpl.html#gad6e0c12a858784b8fdfd64255df3543a',1,'platform.h']]],
  ['stackdestroy',['StackDestroy',['../group__Xpl.html#gab682c4b613768bf5435d1875550060f5',1,'platform.h']]],
  ['stackpop',['StackPop',['../group__Xpl.html#ga058a291f86d19d23587d9eeaa7751fe5',1,'platform.h']]],
  ['stackpush',['StackPush',['../group__Xpl.html#gaae6043836b0895409ced7c30614035da',1,'platform.h']]],
  ['strchrs',['strchrs',['../group__Xpl.html#ga8a1d14b6d89b92fe49431e679906f6e0',1,'platform.h']]],
  ['strrchrs',['strrchrs',['../group__Xpl.html#ga066baaf11609d37405c7b60d49fa54e4',1,'platform.h']]]
];
