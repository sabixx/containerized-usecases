var searchData=
[
  ['readbinary',['ReadBinary',['../group__Xpl.html#gac99e2ad0e0503f01ef21e3a53fae5e32',1,'platform.h']]],
  ['readline',['ReadLine',['../group__Xpl.html#ga547e7395e416a8d3df46d1399cc3aeb7',1,'platform.h']]],
  ['release',['release',['../group__Xpl.html#gac168b25247bbd0eddc546ccef4877905',1,'platform.h']]],
  ['reversearray',['ReverseArray',['../group__Xpl.html#ga7dcd5ebb0e21a3ef6f2c4da07f2e9069',1,'platform.h']]]
];
