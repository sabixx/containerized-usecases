var searchData=
[
  ['getapplicationinfo',['GetApplicationInfo',['../group__LibHsm.html#ga28625a43613d4c48119edacc39026524',1,'libhsm.h']]],
  ['getarch',['GetArch',['../group__Xpl.html#ga53b98961e5f151991c72c412d1a1ec6c',1,'platform.h']]],
  ['getasn1length',['GetAsn1Length',['../group__Xpl.html#ga924691a7ad82e301ee458f866860726a',1,'platform.h']]],
  ['getfilenamefrompath',['GetFilenameFromPath',['../group__Xpl.html#gaa38f256dcb15fc7667991c63b8831391',1,'platform.h']]],
  ['getosinfo',['GetOSInfo',['../group__Xpl.html#ga5960415eed4ee59eeee93b68d623188c',1,'platform.h']]],
  ['getprocessinfo',['GetProcessInfo',['../group__LibHsm.html#gaedabc0197f1a4b81cfd8f7e2690165d7',1,'libhsm.h']]],
  ['getprogramname',['GetProgramName',['../group__Xpl.html#ga9bc86b75cad7f194d8783e3095060118',1,'platform.h']]],
  ['getprogrampath',['GetProgramPath',['../group__Xpl.html#ga2b46228b279abf35c28b672f21410ca8',1,'platform.h']]],
  ['gettempfile',['GetTempFile',['../group__Xpl.html#ga1f97122b015d53326a79be23d0378097',1,'platform.h']]],
  ['getutf8argv',['GetUtf8Argv',['../group__Xpl.html#ga6928a0fbe9b3330af605ff1a7d6c2f7c',1,'platform.h']]],
  ['guidcreate',['GuidCreate',['../group__Xpl.html#gaa8a3b4814b54cce9402d668365bd4a63',1,'platform.h']]],
  ['guidfree',['GuidFree',['../group__Xpl.html#ga2a1dc97d23661b31558a60fd469dd650',1,'platform.h']]]
];
