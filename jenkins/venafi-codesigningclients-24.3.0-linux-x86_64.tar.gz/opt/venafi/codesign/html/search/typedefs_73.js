var searchData=
[
  ['stack',['Stack',['../group__Xpl.html#ga51a53c46dc56ca6105614ceb9f560aa9',1,'platform.h']]]
];
