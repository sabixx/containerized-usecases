var searchData=
[
  ['quickcompare',['QuickCompare',['../group__Xpl.html#ga812ebc2f8b1d59a31deb8fab3ac18f8b',1,'platform.h']]],
  ['quickcomparelen',['QuickCompareLen',['../group__Xpl.html#ga622a69e3cdd3e236ef76760e7dcb54d8',1,'platform.h']]]
];
