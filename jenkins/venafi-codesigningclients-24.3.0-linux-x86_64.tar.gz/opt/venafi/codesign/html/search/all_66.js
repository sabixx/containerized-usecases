var searchData=
[
  ['fileexists',['FileExists',['../group__Xpl.html#gafa32f580b477bab8843653fa9c64de1f',1,'platform.h']]],
  ['freeprocessinfo',['FreeProcessInfo',['../group__LibHsm.html#ga464b918ae8cbec6920b97de9549dc5c6',1,'libhsm.h']]],
  ['freeprogramname',['FreeProgramName',['../group__Xpl.html#ga21d72d7ade93496f3417640d62c5d19e',1,'platform.h']]],
  ['freeutf8argv',['FreeUtf8Argv',['../group__Xpl.html#gaa55e631fe082c980068883c02fc74873',1,'platform.h']]]
];
