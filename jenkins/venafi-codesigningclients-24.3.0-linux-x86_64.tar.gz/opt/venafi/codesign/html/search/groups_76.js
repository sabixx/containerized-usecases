var searchData=
[
  ['venafi_20platform_20library_20_28libxpl_29',['Venafi Platform Library (libxpl)',['../group__Xpl.html',1,'']]]
];
