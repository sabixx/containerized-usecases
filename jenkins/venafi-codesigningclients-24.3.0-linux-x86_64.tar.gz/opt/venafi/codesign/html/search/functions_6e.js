var searchData=
[
  ['naturalcase',['NaturalCase',['../group__Xpl.html#ga21eb225a81ad0bddeef728f5f479e122',1,'platform.h']]]
];
