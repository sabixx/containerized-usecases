var searchData=
[
  ['processinfostruct',['ProcessInfoStruct',['../structProcessInfoStruct.html',1,'']]]
];
