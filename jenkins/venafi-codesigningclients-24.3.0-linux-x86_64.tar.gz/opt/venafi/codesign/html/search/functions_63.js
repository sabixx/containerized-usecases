var searchData=
[
  ['createxplmutex',['CreateXplMutex',['../group__Xpl.html#gaccadfc080da6d09b876154cbace80a82',1,'platform.h']]]
];
