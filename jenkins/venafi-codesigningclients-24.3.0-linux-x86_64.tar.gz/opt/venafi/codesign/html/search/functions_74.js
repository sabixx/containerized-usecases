var searchData=
[
  ['trim',['Trim',['../group__Xpl.html#gaf920d3e8c7f8797239441ead87697f75',1,'platform.h']]],
  ['trimwithquotes',['TrimWithQuotes',['../group__Xpl.html#ga71564a96f9e245e2ffd040eec609939f',1,'platform.h']]]
];
