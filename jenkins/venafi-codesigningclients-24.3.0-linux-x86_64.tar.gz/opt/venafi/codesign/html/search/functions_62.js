var searchData=
[
  ['base64urldecode',['Base64URLDecode',['../group__Xpl.html#ga6ba14ca438b97f8f90c21121559903a3',1,'platform.h']]],
  ['base64urlencode',['Base64URLEncode',['../group__Xpl.html#gae7f93bf9dff095327276cc460b8b3808',1,'platform.h']]],
  ['bin2hex',['Bin2Hex',['../group__Xpl.html#ga953fab99a720ae5a69b9f895d67fcf26',1,'platform.h']]]
];
