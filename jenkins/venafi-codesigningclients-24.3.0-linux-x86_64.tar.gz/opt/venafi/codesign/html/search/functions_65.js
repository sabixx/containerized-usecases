var searchData=
[
  ['ed25519_5fcreatekeypair',['ed25519_CreateKeyPair',['../group__LibHsm.html#ga96ba2d83955507e36013a373a0db74d6',1,'libhsm.h']]],
  ['ed25519_5fsignmessage',['ed25519_SignMessage',['../group__LibHsm.html#gaec6cff01ad8256659cf8ef1e26f52a09',1,'libhsm.h']]],
  ['ed25519_5fverifysignature',['ed25519_VerifySignature',['../group__LibHsm.html#ga16c8577d4654bc0672987aa353b2cad4',1,'libhsm.h']]],
  ['encodebase64',['EncodeBase64',['../group__Xpl.html#ga4632c5ecf77ea1281c4f2ccdcd5a7b8b',1,'platform.h']]]
];
