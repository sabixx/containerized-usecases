var searchData=
[
  ['xplfreebuffer',['XplFreeBuffer',['../group__Xpl.html#gaa5c6a10598a4a29d2db601d97f64601e',1,'platform.h']]]
];
