/// 
/// Copyright 2016-2020 Venafi, Inc.
/// All Rights Reserved.
/// 
/// This program is unpublished proprietary source code of Venafi, Inc.
/// Your use of this code is limited to those rights granted in the license between you and Venafi.
/// 
/// Author: Peter Dennis Bartok (peter@venafi.com)
///
/// 
/// \file
/// \brief Provides cross-platform definitions and function prototypes for the Venafi Platform Library
/// \addtogroup Xpl Venafi Platform Library (libxpl)
/// \{
/// 

#ifndef _PLATFORM_H
#define _PLATFORM_H

/* Define the following (and then recompile everything) to have full memory logging/checking */
//#define CHECK_MEMORY

/* Define the following (and CHECK_MEMORY above) and commit to trigger memory testing during the jenkins build */
//#define INTEGRATION_TEST

#include <inttypes.h>
/*
 * Platform-specific includes
 */

/* Auto-detect the OS */
#if !defined(WIN32) && !defined(LINUX) && !defined(MAC)
# if defined(__VISUALC__)
#  define WIN32
# elif defined(linux)
#  define LINUX
# else
#  error You must define one option: WIN32, LINUX, or MAC
# endif
#endif /* !WIN32 && !LINUX && !MAC */

#if !defined(DOXYGEN)
# if defined(WIN32)
#  include <xpl/xpl_win.h>
# elif defined(LINUX)
#  include <xpl/xpl_lin.h>
# elif defined(MAC)
#  include <xpl/xpl_mac.h>
# endif
#endif /* !DOXYGEN */


/*
 * General definitions relevant for all platforms
 */

#ifndef TRUE
	#define	TRUE		1
#endif

#ifndef FALSE
	#define	FALSE		0
#endif

/*
 * Helper macro to allow enabling warnings for functions that take a format
 * string with `printf` style varargs.
 */
#if defined __GNUC__
#define FormatString(formatStringIndex, firstToCheck)	__attribute__ ((format (printf, formatStringIndex, firstToCheck)))
#else
#define FormatString(formatStringIndex, firstToCheck)
#endif

#ifdef __cplusplus
extern "C" {
#endif

/** @name String Encoding, Decoding and Conversion
 *  Functions to convert between different character sets and encodings
 *  @{
 */
/**
 * \brief                   Decode a Base64 string.
 * \details Decode a Base64 string. The decoded data replaces the passed-in Base64 string.
 *
 * \param[in] data          The Base64 string to decode. On return, holds the decoded byte array.
 * \param[in] size          The length, in bytes, of the Base64 string
 * \param[out] remainder    On return, holds the number of non-Base64 bytes not decoded at the end of the Base64 string, if any
 * \return                  Returns the \p Data pointer now holding the decoded data
 */
int	DecodeBase64(char *data, int size, int *remainder);

/**
 * \brief                   Encode a byte array as Base64 string.
 * \details Encode a byte array as Base64 string. The returned pointer must be freed with XplFreeBuffer().
 *
 * \param[in] array         The Base64 string to decode. On return, holds the decoded byte array.
 * \param[in] length        The length, in bytes, of the Base64 string
 * \return                  Returns a buffer with the Base64 encoded array. Must be freed with XplFreeBuffer()
 */
char *EncodeBase64(const unsigned char *array, int length);

/**
 * \brief                   Decode a Base64URL string.
 * \details Decode a Base64URL string. The returned pointer must be freed with XplFreeBuffer().
 *
 * \param[in] data           The Base64 string to decode. On return, holds the decoded byte array.
 * \param[in] data_length    The length, in bytes, of the Base64 string
 * \param[out] out           The decoded data
 * \param[out] out_length    The length of the decoded data
 * \return                   Returns if decoding was successful TRUE or failed FALSE
 */
BOOL Base64URLDecode(const unsigned char* data, const size_t data_length, uint8_t** out, size_t* out_length);

/**
 * \brief                   Encode a byte array as Base64URL string.
 * \details Encode a byte array as Base64 string. The returned pointer must be freed with XplFreeBuffer().
 *
 * \param[in] data          The Base64 string to decode. On return, holds the decoded byte array.
 * \param[in] data_length   The length, in bytes, of the Base64URL string
 * \return                  Returns a buffer with the Base64URL encoded array. Must be freed with XplFreeBuffer()
 */
char *Base64URLEncode(unsigned char* data, size_t data_length);

/**
 * \brief                   Capitalizes the first char of each word, lowercases the rest.
 * \details This function alters the capitalization of a provided string by uppercasing the first
 * character after any whitespace character, and lowercasing the remaining characters up to the next
 * whitespace or the end of the string. The original string stays untouched, and a newly allocated
 * copy is returned.
 *
 * \param[in] str           Pointer to the string to switch to natural case
 *
 * \return                  Pointer to the newly allocated string. Must be freed with XplFreeBuffer()
 */
char *NaturalCase(const char *str);

/**
 * \brief					Return the number of UTF-8 characters in the provided string.
 * \details This function counts the number of UTF-8 characters in the provided
 * string. Since a UTF-8 character may be encoded as more than 1 byte this will
 * always return a value that is less than or equal to the value returned by
 * `strlen()` on the same input.
 *
 * \param[in] str			Pointer to the string
 *
 * \return					The number of UTF-8 characters in the provided string.
 */
size_t Utf8Strlen(const char *str);

/**
 * \brief					Return the number of bytes used by a single UTF-8 character.
 * \details This function returns the number of characters that the first full
 * UTF-8 character in the specified string consumes.
 *
 * If the character is not a valid UTF-8 character then 1 will be returned.
 *
 * \param[in] str			Pointer to the string
 *
 * \return					The number of bytes
 */
size_t Utf8CPLen(const char *str);

/**
 * \brief					Return the number of bytes needed to store a full
 * UTF-8 multi-byte character, where `u` is the first byte.
 *
 * If the character is not a valid UTF-8 character then 1 will be returned.
 *
 * \param[in] u				The first byte of a UTF-8 CP
 *
 * \return					The number of bytes
 */
size_t Utf8CPSize(const char u);

/**
 * \brief					Return the number of columns needed to print the specified string.
 * \details This function returns the number of columns that *most* consoles will
 * need to display the specified string using a fixed width font.
 *
 * \param[in] str			Pointer to the string
 * \param[in] size          The size in bytes of the string, or -1 if it is NULL terminated
 *
 * \return					The number of columns needed to print the specified string.
 */
int Utf8DisplayLen(const char *str, int size);

/**
 * \brief					Return the number of columns needed to print the
 * character of the specified string.
 * \details This function returns the number of columns that *most* consoles will
 * need to display the specified character using a fixed width font.
 *
 * \param[in] str			Pointer to the string
 * \param[out] bytes		If not \c NULL then the number of bytes used by the specified character will be stored.
 *
 * \return					The number of columns needed to print the specified character.
 */
int Utf8CPDisplayLen(const char *str, int *bytes);

/**
 * \brief                   Encodes a string according to URL encoding rules.
 * \details                 This function converts a string to a URL that includes percentage encoding for special characters.
 *
 * \param[in] src           Pointer to the string to switch to natural case
 * \param[out] dest         Returns a pointer to the converted string. Must be freed with XplFreeBuffer() when no longer needed.
 *
 * \return                  The number of characters in the encoded string, or 0 if an error occurred.
 */
int UrlEncode(const char *src, char **dest);

/**
 * \brief                   Decodes a URL-encoded string.
 * \details                 This function decodes and unescapes a URL string. It converts the string in place, altering the source.
 *
 * \param[in] url           Pointer to a string to decode
 *
 * \return                  The number of characters in the decoded string.
 */
int UrlDecode(char *url);

/**
 * \brief					Find the first occurance of any character in needle within haystack
 *
 * \param[in] haystack		The \c NULL terminated string to search in
 * \param[in] needle		The \c NULL terminated string containing the characters to search for
 *
 * \return					The pointer to the first matching character, or NULL if none are found.
*/
char * strchrs(const char *haystack, char *needle);

/**
 * \brief					Find the last occurance of any character in needle within haystack
 *
 * \param[in] haystack		The \c NULL terminated string to search in
 * \param[in] needle		The \c NULL terminated string containing the characters to search for
 *
 * \return					The pointer to the last matching character, or NULL if none are found.
*/
char * strrchrs(const char *haystack, char *needle);

#if defined(WIN32) || defined(DOXYGEN)
 /**
 * \brief                   Translates a unicode string to UTF-8.
 * \details                 This function will convert a Windows wchar string to UTF-8.
 *
 * \param[in] utf8          Pointer to UTF-8 string
 * \param[in] size          The size in bytes of the string, or -1 if it is NULL terminated
 *
 * \return                  Pointer to unicode version of \p utf8. Must be freed with FreeUtf8()
 *
 * \note This function is only available on Windows
 */
wchar_t *Utf8ToWchar(const char *utf8, int size);

/**
 * \brief                   Translates a UTF-8 string to unicode.
 * \details                 This function will convert a UTF-8 string to a Windows wchar string.
 *
 * \param[in] utf16         Pointer to wchar string
 *
 * \return                  Pointer to UTF-8 version of \p utf16. Must be freed with FreeWchar()
 *
 * \note This function is only available on Windows
 */
char *WcharToUtf8(const wchar_t *utf16);

/**
 * \brief                   Free a wchar string returned by Utf8ToWchar().
 *
 * \param[in] utf16         Pointer to the wchar string to free
 *
 * \note This function is only available on Windows
 */
void FreeWchar(wchar_t *utf16);

/**
 * \brief                   Free a UTF-8 string returned by WcharToUtf8().
 *
 * \param[in] utf8          Pointer to the UTF-8 string to free
 *
 * \note This function is only available on Windows
 */
void FreeUtf8(char *utf8);
#endif /* WIN32 */

/**
 * \brief                   Convert a hex string into a byte array.
 *
 * \param[in] hex           Hex string to convert
 * \param[out] bin          Returns a pointer to the byte array. Must be freed with XplFreeBuffer()
 * \param[out] len          Returns the length of the byte array.
 *
 * \return                  \c TRUE if successful, \c FALSE otherwise
 */
BOOL Hex2Bin(const char *hex, BYTE **bin, size_t *len);

/**
 * \brief                   Convert a byte array into a hex string.
 *
 * \param[in] bin           Byte array to convert
 * \param[in] len           Length, in bytes, of byte array \p bin
 * \param[out] hex          Returns a pointer to the hex string. Must be freed with XplFreeBuffer()
 *
 * \return                  \c TRUE if successful, \c FALSE otherwise
 */
BOOL Bin2Hex(BYTE *bin, int len, char **hex);

/**
 * \brief                   Escape a string for use as JSON name or value.
 *
 * \param[in] in            The string to escape
 *
 * \return                  Pointer to the escaped string. Must be freed with XplBuffer()
 */
char *JsonEscapeString(const char *in);

/**
 * \brief                   Trim leading and trailing whitespace.
 * \details Removes any leading and trailing whitespace characters from a string. \c isspace is used to determine what is whitespace. 
 * The function modifies the string that is passed in.
 *
 * \param[in,out] str       The string to trim
 *
 * \return                  Returns \p str
 */
char *Trim(char *str);

/* Trim leading and trailing whitespace as well as leading and trailing quotes from a string; modifies the string */
/**
 * \brief                   Trim leading and trailing whitespace and double-quote characters.
 * \details Removes any leading and trailing whitespace and double-quote characters. \c isspace is used to determine what is whitespace. 
 * The function modifies the string that is passed in. Only quotes that are leading or trailing are removed.
 *
 * \param[in,out] str       The string to trim
 *
 * \return                  Returns \p str
 */
char *TrimWithQuotes(char *str);

/**@} String Encoding */

/** @name Dictionaries
 *  Fast name/value dictionary lookup
 *  @{
 */
/**
 * \typedef Dict
 *
 * \brief Dictionary object.
 *
 * \details The \p Dict object holds a dictionary. The dictionary is made up of key/value pairs. The same 
 * key may be added multiple times with different values.
 *
 * \headerfile platform.h <venafi/platform.h>
 */
typedef struct dict *Dict;

/* create a new empty dictionary */
/**
 * \brief                   Create a new dictionary.
 * \details Creates a new dictionary. Dictionaries provide fast access to arbitrary data through key lookup.
 *
 * \return                  Returns a new \p Dict dictionary, or \c NULL on failure
 */
Dict DictCreate(void);

/**
 * \brief                   Destroys an existing dictionary.
 * \details Releases all memory associated with a dictionary.
 *
 * \param[in] d             The dictionary to destroy
 */
void DictDestroy(Dict d);

/**
 * \brief                  Adds a new key/value pair to a dictionary.
 * \details Adds a new key/value pair to the dictionary. The key can be binary data and the value is of type void*. It is legal to add
 * the multiple values for the same key to the dictionary.
 *
 * \param[in] d             An existing dictionary object
 * \param[in] key          Pointer to the key
 * \param[in] key_len      Length of the key
 * \param[in] value        The value to associate with the key
 * \return                 \c TRUE if the key/value pair was added, \c FALSE on error
 */
BOOL DictInsert(Dict d, const BYTE *key, size_t key_len, void *value);

/**
 * \brief                  Looks up a dictionary value by key.
 * \details Finds the most recently added value for a key.
 *
 * \param[in] d            An existing dictionary object
 * \param[in] key          Pointer to the key
 * \param[in] key_len      Length of the key
 * \return                 The most recently inserted value associated with the given key, or \c NULL if the key was not in the dictionary
 */
const void *DictSearch(Dict d, const BYTE *key, size_t key_len);

/**
 * \brief                  Delete the most recently inserted value for a key.
 * \details Deletes the most recently inserted key/value pair for the given key. If the key does not exist, the function call has no effect.
 *
 * \param[in] d            An existing dictionary object
 * \param[in] key          Pointer to the key
 * \param[in] key_len      Length of the key
 */
void DictDelete(Dict d, const BYTE *key, size_t key_len);

/**
 * \brief                  Returns all key/value pairs in the dictionary in a sparse array.
 * \details Returns an array with all entries in the dictionary. May return NULL values in the list. So, you must check that plist[index] is not NULL, and cannot
 * assume that every item in the array has a value. The returned pointer \p plist must be freed with XplFreeBuffer().
 *
 * \param[in] d            An existing dictionary object
 * \param[out] plist       Holds a pointer to an array of dictionary entries on return
 * \return                 The number of items in the array
 */
int DictToArray(Dict d, void ***plist);
/**@} Dictionaries */

/** @name Lists
 *  List management functionality
 *  @{
 */

 /**
  * \typedef List
  *
  * \brief List object.
  *
  * \details The \p List object holds a list of items. The list can hold arbirary \c void* entries.
  *
  * \headerfile platform.h <venafi/platform.h>
  */
typedef void *List;

/**
 * \typedef ListItem
 *
 * \brief ListItem holding a caller-provided value.
 *
 * \details The \p ListItem represents a single item in a list.
 *
 * \headerfile platform.h <venafi/platform.h>
 */
typedef void *ListItem;

/**
 * \typedef ListEnum
 *
 * \brief Enumerator object to enumerate all items in a list.
 *
 * \headerfile platform.h <venafi/platform.h>
 */
typedef void *ListEnum;

/**
 * \brief                  Creates a new list.
 * \details This function creates a new list and returns a handle to it. When the list is no longer needed, it must be destroyed with ListDestroy().
 *
 * \return                 Returns a \ref List handle
 */
List ListCreate(void);

/* Destroys a list created by ListCreate() */
/**
 * \brief                  Release all resources associated with a \ref List.
 * \details Use this function to free a list created with ListCreate().
 *
 * \param[in] list         A valid \ref List handle
 */
void ListDestroy(List list);

/* Addeds a value to the list */
/**
 * \brief                   Add a value to a list.
 * \details                 This function adds a \c void* pointer to the first free slot in the specified \p list. No error is returned if the item already exists in
 * the list, it will simply be added again.
 *
 * \param[in] list          A valid \c List handle
 * \param[in] value         The value to add
 *
 * \return                  \c TRUE if the value was added, \c FALSE on error 
 */
BOOL ListAdd(List list, void *value);

/**
 * \brief                   Removes a value from a list.
 * \details                 This function removes the specified \c void* pointer from the list. If the value is in the list multiple times, only the first occurrence is removed.
 *
 * \param[in] list          A valid \c List handle
 * \param[in] value         The value to remove
 *
 * \return                  \c TRUE if the value was found and removed, \c FALSE on error
 */
BOOL ListRemove(List list, void *value);

/**
 * \brief                   Starts an enumeration of the list.
 * \details                 Use this function obtain an enumerator and to start retrieving values from the list. To obtain the next value, use ListGetNext(), end the enumeration
 * with ListEndEnumeration().
 *
 * \param[in] list          A valid \c List handle
 * \param[out] value        Returns the first value in the list
 *
 * \return                  A \ref ListEnum enumeration handle to be used with ListGetNext() and ListEndEnumeration()
 */
ListEnum ListGetFirst(List list, void **value);

/**
 * \brief                   Returns the next item in a list.
 * \details                 Use this function to get the next item in the list after starting an enumeration with ListGetFirst(). If \c NULL is returned, no call to ListEndEnumeration() is needed to end the enumeration.
 *
 * \param[in] enumerator    A valid \ref ListEnum obtained via ListGetFirst() or ListGetNext()
 * \param[out] value        Returns the next value in the list
 *
 * \return                  Returns the \p enumerator, or \c NULL if no more items are in the list
 */
ListEnum ListGetNext(ListEnum enumerator, void **value);

/**
 * \brief                   Terminate an enumeration started via ListGetFirst().
 * \details                 This function ends an enumeration if not all items were enumerated via ListGetNext().
 *
 * \param[in] enumerator    A valid \ref ListEnum obtained via ListGetFirst() or ListGetNext()
 *
 */
void ListEndEnumeration(ListEnum enumerator);

/**@} Lists */



/** @name Command line
 *  Easy command line argument parsing
 *  @{
 */

/**
 * \brief                  Extracts the application name from argv0.
 * \details This function expects to be passed argv[0] and it will return the application name (stripped of the .EXE suffix on Windows). It requires the returned handle to be freed with FreeProgramName().
 *
 * \param[in] argv0        \c arv[0] of the application
 * \param[out] handle      Returns a handle pointer to allow freeing the returned pointer when no longer needed
 * \return                 Read-only pointer to application name
 */
const char *GetProgramName(const char *argv0, void **handle);

/**
 * \brief                  Returns the path to the running executable.
 * \details This function will return the application path. It requires the returned handle to be freed with FreeProgramName().
 *
 * \param[out] handle      Returns a handle pointer to allow freeing the returned pointer when no longer needed
 * \return                 Read-only pointer to application path
 */
char *GetProgramPath(void **handle);




/**
 * \brief                  Free memory allocated by GetProgramName().
 * \details Call this function to free any memory allocated when GetProgramName() was called.
 *
 * \param[in] handle       The handle returned by GetProgramName()
 */
void FreeProgramName(void *handle);
/**@} Command line */


#define	ArgCheckString(name, value)			if (CmdParserGetArgument(argc, argv, &i, name, FALSE, NULL, &value, NULL, NULL, NULL, NULL, FALSE)) continue;
#define	ArgCheckInt(name, value)			if (CmdParserGetArgument(argc, argv, &i, name, FALSE, NULL, NULL, &value, NULL, NULL, NULL, FALSE)) continue;
#define	ArgCheckBool(name, value)			if (CmdParserGetArgument(argc, argv, &i, name, FALSE, NULL, NULL, NULL, &value, NULL, NULL, FALSE)) continue;
#define	ArgCheckFlag(name, value)			if (CmdParserGetArgument(argc, argv, &i, name, FALSE, NULL, NULL, NULL, NULL, &value, NULL, FALSE)) continue;
#define	ArgCheckBoolExact(name, value)		if (CmdParserGetArgument(argc, argv, &i, name, TRUE, NULL, NULL, NULL, &value, NULL, NULL, TRUE)) continue;
#define	ArgCheckFlagExact(name, value)		if (CmdParserGetArgument(argc, argv, &i, name, TRUE, NULL, NULL, NULL, NULL, &value, NULL, FALSE)) continue;
#define	ArgCheckMatch(name, match, value)	if (CmdParserGetArgument(argc, argv, &i, name, FALSE, match, NULL, NULL, NULL, NULL, &value, FALSE)) continue;
#define	ArgCheckIfMatch(name, match, value)	if (CmdParserGetArgument(argc, argv, &i, name, FALSE, match, NULL, NULL, NULL, NULL, &value, FALSE))
#define	ArgCheckIf(name)					if (CmdParserGetArgument(argc, argv, &i, name, FALSE, NULL, NULL, NULL, NULL, NULL, NULL, TRUE))
#define	ArgCheckStringIf(name,value)		if (CmdParserGetArgument(argc, argv, &i, name, FALSE, NULL, &value, NULL, NULL, NULL, NULL, FALSE))
#define	ArgCheckBoolIf(name, value)			if (CmdParserGetArgument(argc, argv, &i, name, FALSE, NULL, NULL, NULL, &value, NULL, NULL, FALSE))
#define	ArgCheckIfExact(name)				if (CmdParserGetArgument(argc, argv, &i, name, TRUE, NULL, NULL, NULL, NULL, NULL, NULL, TRUE))

BOOL CmdParserGetArgument(int argc, const char **argv, int *index, const char *name, BOOL exact, const char *match, char **string_value, int *int_value, BOOL *bool_value, int *flag_value, BOOL *match_bool, BOOL check_only);

/** @name Threading
 *  Multi-threading support functionality
 *  @{
 */

 /**
  * \brief Error code enumeration of all \c libhsm errors.
  *
  * \headerfile HsmErrors.h <venafi/hsm/HsmErrors.h>
  */
typedef enum {
	LibXplMutexOk             = 0x0000,   /**< The function completed without error */
	LibXplMutexGeneralError   = 0x0005,   /**< An unspecified error occurred */
	LibXplMutexBadHandle      = 0x01a0,   /**< An invalid mutex handle was provided */
	MutexVendorSpecific = 0x80000000
} LibXplMutexResult;

/**
 * \brief                   Creates a mutex.
 * \details                 This function creates a mutex that can be used to provide protection around code that must not be executed by more than a single thread.
 *
 * \param[out] ppMutex      Holds the mutex handle on return
 *
 * \return                  \ref LibXplMutexOk if the mutex was created, \ref LibXplMutexGeneralError otherwise
 */
unsigned long CreateXplMutex(void **ppMutex);

/**
 * \brief                   Destroys a mutex.
 * \details                 This function destroys a mutex previously created by CreateXplMutex().
 *
 * \param[in] pMutex        The mutex to destroy
 *
 * \return                  \ref LibXplMutexOk if the mutex was destroyed, \ref LibXplMutexBadHandle if \p pMutex was not a valid handle, \ref LibXplMutexGeneralError otherwise
 */
unsigned long DestroyXplMutex(void *pMutex);

/**
 * \brief                   Obtains a mutex lock.
 * \details                 This function obtains an exclusive lock on the mutex. If the mutex is already locked, it will block until another thread releases it.
 *
 * \param[in] pMutex        The mutex to lock
 *
 * \return                  \ref LibXplMutexOk if the lock was obtained, \ref LibXplMutexBadHandle if \p pMutex was not a valid handle, \ref LibXplMutexGeneralError otherwise
 */
unsigned long LockXplMutex(void *pMutex);

/**
 * \brief                   Releases a mutex lock.
 * \details                 This function releases a lock previously obtained via LockXplMutex().
 *
 * \param[in] pMutex        The mutex to unlock
 *
 * \return                  \ref LibXplMutexOk if the lock was released, \ref LibXplMutexBadHandle if \p pMutex was not a valid handle, \ref LibXplMutexGeneralError otherwise
 */
unsigned long UnlockXplMutex(void *pMutex);
/**@} Mutex Functions*/

/** @name Stack
 *  Stack (LIFO) functionality
 *  @{
 */

 /**
  * \typedef Stack
  *
  * \brief Stack object.
  *
  * \details The \p Stack object holds a last-in first-out list of items. A stack consists of slots for keys where each key holds a LIFO list of values.
  *
  * \headerfile platform.h <venafi/platform.h>
  */
typedef struct stack *Stack;

 /**
  * \brief                   Create a new stack.
  * \details                 Creates a new stack. Stacks provide fast access to previously pushed values for a key.
  *
  * \return                  Returns a new \p Stack stack, or \c NULL on failure.
  */
Stack StackCreate(void);

/**
 * \brief                   Destroys an existing stack.
 * \details Releases all memory associated with a stack. If the free_func parameter is not set to \c NULL, the reference function is called for every value still stored in the stack.
 *
 * \param[in] s             The stack to destroy
 */
void StackDestroy(Stack s, void(free_func)(void *));

/**
 * \brief                  Pushes a new value for a key onto the stack.
 * \details Adds a new value for a key onto the stack. The key can be binary data and the value is of type void*.
 *
 * \param[in] s            An existing Stack object
 * \param[in] key          Pointer to the key
 * \param[in] key_len      Length of the key
 * \param[in] value        The value to associate with the key
 * \return                 \c TRUE if the stack entry was pushed, \c FALSE on error
 */
BOOL StackPush(Stack s, const BYTE *key, size_t key_len, void *value);

/**
 * \brief                  Pops a value for a key off the stack.
 * \details Returns the most recently added value for a key and removes it from the stack. If the last value for a key is popped, the key is also removed from the stack.
 *
 * \param[in] s            An existing stack object
 * \param[in] key          Pointer to the key
 * \param[in] key_len      Length of the key
 * \return                 The most recently pushed value associated with the given key, or \c NULL if the key was not in the dictionary.
 */
void *StackPop(Stack s, const BYTE *key, size_t key_len);
/**@} Stack Functions*/

/** @name Miscellaneous
 *  Various support functions
 *  @{
 */
 /**
 * \brief                   Generate a new guid.
 * \details Generates a new GUID and returns it as UTF-8 string.
 *
 * \return                  Returns the buffer containing the GUID. Must be freed with GuidFree().
 */
char *GuidCreate(void);

/**
 * \brief                   Deallocate GUID buffer.
 * \param[in] guid          The pointer to free
 * \details Frees the memory returned by GuidCreateA()
 */
void GuidFree(char *guid);

/**
 * \brief                   Get operating system name and version.
 * \details This function detects the type and version of operating system that is being used and returns the name and a standardized version in the format release.version.build.
 * \param[out] os_name      Returns a pointer to a string with the OS name
 * \param[out] os_version   Returns a pointer to a string with the OS version
 * \return                  \c TRUE if successful, \c FALSE otherwise
 */
BOOL GetOSInfo(const char **os_name, const char **os_version);

/**
 * \brief                   Get the architecture type the code is running on.
 * \details This function returns the architecture libxpl was compiled for
 * \param[out] arch         Returns a pointer to a string with the architecture name (x86_32, x86_64 or arm64)
 * \return                  \c TRUE if successful, \c FALSE otherwise
 */
BOOL GetArch(const char **arch);

/**
 * \brief                   Prompt for input.
 * \details This function displays a prompt on stdin, and then waits for input on stdout. Input ends when \n is encountered. The input is echoed to stdout
 * unless \p masked is set to \c TRUE. In that case, an asterisk is displayed for every entered character. The function handles backspace to erase entered characters.
 * \param[in] prompt        The prompt to display
 * \param[out] buffer       The buffer to store the received input in
 * \param[in] bufsize       The size, in bytes, of \p buffer. The function will, at most, return \p bufsize bytes even if the user entered more
 * \param[in] masked        \c TRUE if the input should be obscured
 * \return                  Returns \p buffer pointer
 */
char *ReadLine(const char *prompt, char *buffer, size_t bufsize, BOOL masked);

/**
 * \brief                   Read binary data from stdin.
 * \details This function displays a prompt on stdout and then reads binary data from stdin. It will switch the input to BINARY mode to avoid any character translation.
 * \param[in] prompt        The prompt to display
 * \param[out] buffer       The buffer to store the received input in
 * \param[in] length        The number of bytes to read. \p buffer must be at least \p length bytes in size.
 * \return                  \c TRUE if \p length bytes were read.
 */
BOOL ReadBinary(const char *prompt, char *buffer, size_t length);

/**
 * \brief                  Check if a file exists and the caller rights for the file.
 * \details This function checks if a given file exists.  If it exists, caller rights are also verified. In Windows, this function verifies that the caller has read or write access to the file. On non-Windows systems,
 * the function also determines if anyone but the calling user has rights to read the file.
 *
 * \param[in] filename     The path & name of the file to check
 * \param[out] can_read    If the caller can read the file, returns \c TRUE on return; pass \c NULL if value is not needed
 * \param[out] can_write   If the caller can write to the file, returns \c TRUE on return; pass \c NULL if value is not needed
 * \param[out] safe        If only the caller can read the file, returns \c TRUE on return; pass \c NULL if value is not needed. Only applicable to non-Windows platforms
 * \return                 \c TRUE if the file exists, \c FALSE otherwise
 */
BOOL FileExists(const char *filename, BOOL *can_read, BOOL *can_write, BOOL *safe);

#ifdef WIN32
/**
 * \brief                  Check if a file exists and the caller rights for the file.
 * \details This function checks if a given file exists.  If it exists, caller rights are also verified. In Windows, this function verifies that the caller has read or write access to the file. On non-Windows systems,
 * the function also determines if anyone but the calling user has rights to read the file.
 *
 * \param[in] filename     The path & name of the file to check
 * \param[out] can_read    If the caller can read the file, returns \c TRUE on return; pass \c NULL if value is not needed
 * \param[out] can_write   If the caller can write to the file, returns \c TRUE on return; pass \c NULL if value is not needed
 * \param[out] safe        If only the caller can read the file, returns \c TRUE on return; pass \c NULL if value is not needed. Only applicable to non-Windows platforms
 * \return                 \c TRUE if the file exists, \c FALSE otherwise
 */
BOOL FileExistsW(const wchar_t *filename, BOOL *can_read, BOOL *can_write, BOOL *safe);
#endif

/**
 * \brief                  Gets the length of an ASN.1 sequence.
 * \details This function, when passed a byte array containing an ASN.1 sequence, will return the length of the sequence.
 *
 * \param[in] asn1_blob    The byte array holding ASN.1
 * \return                 The length of the sequence, in bytes
 */
DWORD GetAsn1Length(const BYTE *asn1_blob);

/**
 * \brief                  Reverse the content of a byte array.
 * \details This function flips the bytes in an array, reversing their order.
 *
 * \param[in] data         The byte array
 * \param[in] len          The length, in bytes, of \p data
 */
void ReverseArray(BYTE *data, DWORD len);

/**
 * \brief                  Fast string compare.
 * \details This function compares two strings.
 *
 * \param[in] s1           The first string
 * \param[in] s2           The second string
 * \return                 \c TRUE if the strings match, \c FALSE otherwise
 */
BOOL QuickCompare(const char *s1, const char *s2);

/**
 * \brief                  Fast memory compare.
 * \details This function compares two byte arrays of a given length.
 *
 * \param[in] s1           The first array
 * \param[in] s2           The second array
 * \param[in] len          The length of both arrays. Both arrays must be at least \p len bytes long
 * \return                 \c TRUE if they arrays match for \p len bytes, \c FALSE otherwise
 */
BOOL QuickCompareLen(const byte *s1, const byte *s2, int len);

/**
 * \brief                  Get the filename component of a path.
 * \details This function detects the filename part of a path and returns a pointer to it.
 *
 * \param[in] path         The path to analyze
 * \return                 The pointer to the start of the filename in \p path.
 */
const char *GetFilenameFromPath(const char *path);

/**
 * \brief                  Gets a temporary filename in a temporary directory.
 * \details This function uses generates a temporary filename. The path for the file is the users temp directory. If a prefix is passed in, it will be part of the filename.
 *
 * \param[in] prefix       The temporary filename prefix, or \c NULL if no prefix is desired.
 * \return                 Returns a pointer to the temporary filename, or \c NULL on error. Must be freed with XplFreeBuffer()
 */
char *GetTempFile(char *prefix);


/**
 * \brief                  Converts the command line arguments to UTF-8 strings
 * \details This function will attempt to ensure that the command line arguments contained in argv[] are UTF-8 strings. The caller must call FreeUtf8Argv when done with argv.
 *
 * \param[in] argc         The argc argument that was originally passed to main().
 * \param[in] argvp        A pointer to a char *[] which should hold the original value of argv passed to main() when called. A new value may be set if needed.
 * \return                 Returns TRUE if the command line arguments were successfully converted to UTF-8.
 */
BOOL GetUtf8Argv(int argc, char ***argvp);

/**
 * \brief                  Frees any memory allocated by GetUtf8Argv()
 *
 * \param[in] argc         The argc argument that was originally passed to main.
 * \param[in] argvp        The argvp argument that was passed to GetUtf8Argv().
 * \return                 Returns TRUE if successful.
 */
BOOL FreeUtf8Argv(int argc, char ***argvp);


/**
 * \brief                  Frees a pointer allocated and returned by an function from libxpl.
 *
 * \param[in] buffer       A pointer returned by libxpl to free
 */
void XplFreeBuffer(void *buffer);
/**@} Miscellanous */

#if defined(LINUX) || defined(MAC) || defined(DOXYGEN)
/** @name Miscellaneous
 *  Various support functions
 *  @{
 */
/**
 * \fn BOOL GetUserNameA(char *lpBuffer, unsigned long *pcbBuffer)
 * \brief                   Retrieves the name of the user associated with the current thread.
 *
 * \param[in] lpBuffer      A pointer to the buffer to receive the user's logon name. If this buffer is not large enough to contain the entire user name, the function fails.
 * \param[out] pcbBuffer    On input, this variable specifies the size of the lpBuffer buffer, in bytes. On output, the variable returns the number of characters copied to the buffer, including the terminating null character.
 *
 * \return                  If the function succeeds, the return value is a nonzero value, and the variable pointed to by lpnSize contains the number of characters copied to the buffer specified by lpBuffer, including the terminating null character
 *
 * \note This function is built-in on Windows, and provided by libxpl on Linux and Mac.
 */
BOOL GetUserNameA(char *lpBuffer, unsigned long *pcbBuffer);

/**
* \fn BOOL GetComputerNameA(char *lpBuffer, unsigned long *nSize)
* \brief                   Retrieves the name of the local computer.
*
* \param[in] lpBuffer      A pointer to a buffer that receives the computer name.
* \param[out] nSize        On input, specifies the size of the buffer, in characters. On output, returns the number of characters copied to the destination buffer, not including the terminating null character.
*
* \return                  If the function succeeds, the return value is a nonzero value
*
* \note This function is built-in on Windows, and provided by libxpl on Linux and Mac.
*/
BOOL GetComputerNameA(char *lpBuffer, unsigned long *nSize);

/**
* \brief                  Retrieves the home directory of the current user.
* \details This function retrieves the home director of the current user, and optionally appends a string to it, separated by /. This allows for a single call to build a complete filename in the users home directory.
*
* \param[in] append       A string to append to the returned home directory, or \c NULL. If non-NULL, GetHomeDir() will append a forward-slash and the provided string.
*
* \return                 A pointer to a buffer containing the home directory. Must be freed with XplFreeBuffer() when no longer needed.
*
* \note This function is only provided on Linux and Mac.
*/
char *GetHomeDir(const char *append);
/**@} Miscellanous */

/** @name String Encoding, Decoding and Conversion
 *  Functions to convert between different character sets and encodings.
 *  @{
 */
 
/**
* \brief                  Converts a string to uppercase.
* \details The _strupr_s() function converts, in place, each lowercase letter in str to uppercase.
*
* \param[in] str          String to capitalize
* \param[in] numberOfElements Size of the buffer in bytes
* \return                 Zero if successful; a non-zero error code on failure.
*
* \note This function is only provided on Linux and Mac.
*/
int _strupr_s(char *str, size_t numberOfElements);

/**
* \brief                  Converts a string to lowercase.
* \details The _strupr_s() function converts, in place, each uppercase letter in str to lowercase.
*
* \param[in] str          Null-terminated string to convert to lowercase
* \param[in] numberOfElements Size of the buffer in bytes
* \return                 Zero if successful; a non-zero error code on failure.
*
* \note This function is only provided on Linux and Mac.
*/
int _strlwr_s(char *str, size_t numberOfElements);

/**@} String Encoding */
#if defined(LINUX) || defined(DOXYGEN)
/** @name Miscellaneous
 *  Various support functions
 *  @{
 */
 /**
* \fn char *GetSymLinkPath(char *path)
* \brief                  Resolves a symbolic link to the real filename.
*
* \param[in] path         The symbolic file to resolve
*
* \return                 A pointer to a buffer containing the real filename. Must be freed with XplFreeBuffer() when no longer needed.
*
* \note This function is only provided on Linux.
*/
char *GetSymLinkPath(char *path);
/**@} Miscellaneous */

#endif  /* LINUX || DOXYGEN */
#endif  /* LINUX || MAC || DOXYGEN */

/**
* \brief                  Releases an allocated pointer
* \details The release() function checks the specified pointer for NULL, then
* calls free if it is needed, and finally sets the pointer to NULL.
*
* \param[in] ptr          A pointer to the pointer to be released
* \return                 Zero if successful; a non-zero error code on failure.
*/
int release(void **ptr);


#define	Unchecked(memfunction)			memfunction
#define Reassign(ptr)

#if !defined(_IN_MUXMEM_C) && defined(CHECK_MEMORY)
#include "xpl/muxmem.h"
#endif
#ifdef __cplusplus
}
#endif

/// \}

#endif /* PLATFORM_H */
		 
