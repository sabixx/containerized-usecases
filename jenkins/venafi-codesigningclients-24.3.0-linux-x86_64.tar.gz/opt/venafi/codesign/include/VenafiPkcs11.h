//
// Copyright 2019 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#ifndef __VENAFI_PKCS11_H_
#define __VENAFI_PKCS11_H_

#if defined(WIN32)
/* The packing and the five definitions below must be set before including the OASIS Pkcs11.h header */
#pragma pack(push, cryptoki, 1)

#define CK_PTR *
#define CK_DECLARE_FUNCTION(returnType, name) returnType __declspec(dllexport) name
#define CK_DECLARE_FUNCTION_POINTER(returnType, name) returnType __declspec(dllexport) (* name)
#define CK_CALLBACK_FUNCTION(returnType, name) returnType (* name)
#elif defined(LINUX)
#define CK_PTR *
#define CK_DECLARE_FUNCTION(returnType, name) returnType name
#define CK_DECLARE_FUNCTION_POINTER(returnType, name) returnType (* name)
#define CK_CALLBACK_FUNCTION(returnType, name) returnType (* name)
#elif defined(MAC)
#define CK_PTR *
#define CK_DECLARE_FUNCTION(returnType, name) returnType name
#define CK_DECLARE_FUNCTION_POINTER(returnType, name) returnType (* name)
#define CK_CALLBACK_FUNCTION(returnType, name) returnType (* name)
#else
#error Unsupported target platform. You must define WIN32, LINUX or MAC, matching your platform, to use this header file
#endif

#ifndef NULL_PTR
#define NULL_PTR 0
#endif

#include "pkcs11/pkcs11.h"

#if defined(WIN32)
#pragma pack(pop, cryptoki)
#endif

/* End OASIS PKcs11 header include */

#endif	/* __VENAFI_PKCS11_H_ */