///
/// Copyright 2019-2023 Venafi, Inc.
/// All Rights Reserved.
/// 
/// This program is unpublished proprietary source code of Venafi, Inc.
/// Your use of this code is limited to those rights granted in the license between you and Venafi.
/// 
/// Author: Peter Dennis Bartok (peter@venafi.com)
/// Author: Micah N Gorrell (micah.gorrell@venafi.com)
/// 
///
/// \file
/// \brief Main LibHsm include file. Provides prototypes for all public functions, and defines relevant types and structures
/// \addtogroup LibHsm LibHsm Client Library (libhsm)
/// \{
///

#ifndef LIBHSM_H
#define LIBHSM_H

#include <platform.h>
#include <hsm/HsmErrors.h>
#include <hsm/HsmObjects.h>
#include <hsm/HsmCryptoParameter.h>
#include <hsm/libhsm-constants.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void *LibHsmHandle;								/**< Handle for LibHsm access; obtained via LibHsmInitialize() */
typedef unsigned long (*CreateMutexFunc)(void **mutex);	/**< Delegate for creating a new mutex */
typedef unsigned long (*DestroyMutexFunc)(void *mutex);	/**< Delegate for destroying a mutex obtained via CreateMutexFunc() */
typedef unsigned long (*LockMutexFunc)(void *mutex);	/**< Delegate for locking a mutex */
typedef unsigned long(*UnlockMutexFunc)(void *mutex);	/**< Delegate for unlocking a mutex */


/*
 * \var LibHsmLoadObjectsOnInit
 * \brief Alter cache load behavior.
 *
 * \details If this variable is set to \c TRUE before LibHsmInitialize() is called, the object cache will be populated
 * on initialization. Otherwise, by default, it will only be populated when the object list is requested via
 * LibHsmGetObjectList(). Loading the cache involves connecting to the backend REST server and initialization by
 * default avoids the extra time required for the REST request.
 */
extern BOOL LibHsmLoadObjectsOnInit;

/**
 * \struct MutexInfoStruct
 * \brief Structure holding Mutex delegates.
 */
typedef struct {
	CreateMutexFunc create_func;
	DestroyMutexFunc destroy_func;
	LockMutexFunc lock_func;
	UnlockMutexFunc unlock_func;
} MutexInfoStruct;

/**
 * \brief                       Initializes a LibHsm context and returns a handle for it.
 *
 * \details This function initializes a LibHsm instance for use. It is usually the first function called when trying to use LibHsm, and it will
 * return the handle required to use any other LibHsm function. If \p machine_context is set to \c TRUE, only the machine configuration
 * will be used. Otherwise, user configuration will be read, and if a particular item is not set for the user, it will fallback to
 * machine configuration (if present). The returned handle must be freed by calling LibHsmShutdown(). Name is optional and can be \c NULL.
 * If name is specified, it determines the name of the configuration file or registry key that is used. Default is "libhsm".
 * \note You must ensure that each application uses a unique name. Authorization tokens stored in the configuration file should not be shared
 * between multiple applications or one or more applications sharing the token may fail when the token is renewed.
 *
 * \param[out] handle           Holds a valid handle on return. \c NULL, on failure
 * \param[in] machine_context   \c TRUE if the machine configuration should be used. \c FALSE for using user configuration values
 * \param[in] name              The name of the configuration set to use, or \c NULL for default
 * \param[in] mutex_info        A pointer to a MutexInfoStruct with mutex delegates, or \c NULL to use defaults
 * \param[out] error            If the function fails, an error string will be stored at the location pointer to by \p error. Must be freed by the caller
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmInitialize(LibHsmHandle *handle, BOOL machine_context, const char *name, MutexInfoStruct *mutex_info, char **error);
	
/**
 * \brief                       Reinitializes a LibHsm context to pick up any changed configuration.
 *
 * \details This function re-initializes an existing LibHsm instance for use. Typically this function is only called if any LibHsm configuration
 * (e.g. Auth or HSM server URL, OAuth token, etc...) was changed. 
 *
 * \param[in] handle            The handle of the LibHsm instance to re-initialize
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmReinitialize(LibHsmHandle handle);

/**
 * \brief                       Frees all memory and structures related to libhsm operation.
 *
 * \details This function is used to free all memory and objects associated with the provided LibHsm handle.
 * (e.g. Auth or HSM server URL, OAuth token, etc...) was changed.
 *
 * \param[in] handle            The handle of the LibHsm instance to free
 */
void LibHsmShutdown(LibHsmHandle handle);

/**
 * \brief                       Returns a LibHsm version string.
 *
 * \details This function returns a string buffer with the version of LibHsm being used.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      A pointer to a buffer holding the version string.
 */
const char *LibHsmGetVersion(LibHsmHandle handle);

/**
 * \brief                       Frees a memory pointer returned by a LibHsmApi function.
 *
 * \details This function can be used to free the memory of results returned by LibHsmApi functions (signature from LibHsmApiSign(), ciphertext from LibHsmApiEncrypt() and plaintext from LibHsmDecrypt() for example).
 *
 * \param[in] result            A result pointer returned by LibHsmApi functions.
 */
void LibHsmFreeResult(void *result);

/**
 * \brief                       Returns a LibHsm version in byte format.
 *
 * \details This function returns the major, minor and revision version of LibHsm as bytes.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[out] major            Pointer to a byte receiving the major version number
 * \param[out] minor            Pointer to a byte receiving the minor version number
 * \param[out] revision         Pointer to a byte receiving the revision version number
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmGetVersionRaw(LibHsmHandle handle, unsigned char *major, unsigned char *minor, unsigned char *revision);

/**
 * \brief                       Returns the VedHsm server version in byte format.
 *
 * \details This function returns the major, minor and revision version of the configured server version.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[out] major            Pointer to a byte receiving the major version number
 * \param[out] minor            Pointer to a byte receiving the minor version number
 * \param[out] revision         Pointer to a byte receiving the revision version number
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmGetBackendVersionRaw(LibHsmHandle handle, unsigned char *major, unsigned char *minor, unsigned char *revision);

/**
 * \brief                       Retrieves data from a URL.
 *
 * \details This function allows to make HTTP and HTTPS web requests. It supports the GET and POST verbs, and supports providing a post body.
 * It provides the ability to set arbitrary headers for the request.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] verb              The HTTP verb to use. GET and POST are supported.
 * \param[in] url_path          The full URL for the request
 * \param[in] extra_headers     Any extra headers to send. Must be a single string, separating multiple HTTP header lines via \n
 * \param[in] post_body         Byte array to send as the post body. The MIME-Type of the body should be specified via a \p extra_headers CONTENT-TYPE: line
 * \param[in] post_body_length  The length, in bytes of the \p bost_body byte array
 * \param[out] status_description Receives a pointer to the status description returned by the server. Free with LibHsmFreeResult()
 * \param[out] response         Receives the response body, as byte array, returned by the server
 * \param[out] response_length  Receives length, in bytes, of the \p response byte array
 *
 * \return                      The HTTP status code or -1 if the server could not be contacted.
 */
int LibHsmWebRequest(LibHsmHandle handle, const char *verb, const char *url_path, const unsigned char *extra_headers, const unsigned char *post_body, unsigned long post_body_length, char **status_description, unsigned char **response, unsigned long *response_length);

/**
 * \brief A callback to be used with LibHsmWebRequestCallback() to receive a portion
 * of a response body.
 * \param[in] parameter         The \p parameter value passed to LibHsmWebRequestCallback()
 * \param[in] status_code       The HTTP status code.
 * \param[in] status_description The status description returned by the server. This buffer should not be free'd and is only valid while in this callback.
 * \param[in] response_chunk    A portion of the response body, as a byte array, returned by the server. This buffer should not be free'd and is only valid while in this callback.
 * \param[in] response_chunk_length The length, in bytes, of the \p reponse_chunk byte array.
 * \param[in] total_length      The length, in bytes, of the entire response body if it is known. If chunking is used then -1 will be passed instead.
 */
typedef void (* LibHsmWebRequestCb)(void *parameter, int status_code, char * status_description, unsigned char *response_chunk, unsigned long response_chunk_length, signed long total_length);

/**
 * \brief                       Retrieves data from a URL.
 *
 * \details This function allows to make HTTP and HTTPS web requests. It supports the GET and POST verbs, and supports providing a post body.
 * It provides the ability to set arbitrary headers for the request.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] verb              The HTTP verb to use. GET and POST are supported.
 * \param[in] url_path          The full URL for the request
 * \param[in] extra_headers     Any extra headers to send. Must be a single string, separating multiple HTTP header lines via \n
 * \param[in] post_body         Byte array to send as the post body. The MIME-Type of the body should be specified via a \p extra_headers CONTENT-TYPE: line
 * \param[in] post_body_length  The length, in bytes of the \p bost_body byte array
 * \param[in] response_cb       A callback that should be called each time a portion of the response body is available, until the entire response body has been read.
 * \param[in] parameter         A \p parameter value to passed to each call of \p response_cb
 *
 * \return                      The HTTP status code or -1 if the server could not be contacted.
 */
int LibHsmWebRequestCallback(LibHsmHandle handle, const char *verb, const char *url_path, const unsigned char *extra_headers, const unsigned char *post_body, unsigned long post_body_length, LibHsmWebRequestCb response_cb, void *parameter);



/**
 * \brief An enumeration of the possible network connection error states.
 */
typedef enum {
	LibHsmNetworkOk = 0,			/**< No connectivity problem on request */
	LibHsmNetworkFailed = 1,		/**< Last network request failed to connect */
	LibHsmNetworkMultipleFailed = 2,/**< Multiple network requests failed */
} LibHsmNetworkFailLevel;

/**
 * \brief                       Returns an indication for past network problems
 *
 * \details This function returns an enumeration indicating how many past network requests failed. 
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      A value from the \c LibHsmNetworkFailLevel enumeration
 */
LibHsmNetworkFailLevel LibHsmGetNetworkFailLevel(LibHsmHandle handle);

/**
 * \brief                       Returns the location of the user and machine certificate trust store.
 *
 * \details This function returns a the filename of the user and machine trust store.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[out] user_store       Receives a pointer to the user trust store filename
 * \param[out] machine_store    Receives a pointer to the machine trust store filename
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmGetTrustStore(LibHsmHandle handle, const char **user_store, const char **machine_store);

/**
 * \brief                       Returns the certificates a server presents when using SSL/TLS.
 *
 * \details Performs a GET request to the provided \p url_path and returns the server response as well as the certificate and chain. 
 * The chain is type "mbedtls_x509_crt *" but marked as void to not require mbedtls sources for everyone using libhsm.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] url_path          A complete HTTPS url to connect to
 * \param[in] response          Receives a pointer to the data returned by the server. \note The \p response must be freed with LibHsmFreeResult() when no longer needed
 * \param[in] response_length   Receives the length, in bytes, of \p response
 * \param[out] chain            Holds a pointer to the certificate chain on successful return. The actual type is \c mbedtls_x509_crt *
 * \param[out] trusted          Set to \c TRUE if the server is trusted based on current trust configuration, otherwise \c FALSE
 *
 * \return                      The HTTP status code, or -1 if the connection failed.
 */
int LibHsmWebGetCertificateChain(LibHsmHandle handle, const char *url_path, unsigned char **response, unsigned long *response_length, void *chain, BOOL *trusted);

/**
 * \brief                       Returns the leaf certificate a server presents when using SSL/TLS.
 *
 * \details Performs a GET request to the provided \p url_path and returns the server response as well as the leaf certificate without the chain. 
 * The certificate is type "mbedtls_x509_crt *" but marked as void to not require mbedtls sources for everyone using libhsm.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] url_path          A complete HTTPS url to connect to
 * \param[in] response          Receives a pointer to the data returned by the server. \note The \p response must be freed with LibHsmFreeResult() when no longer needed
 * \param[in] response_length   Receives the length, in bytes, of \p response
 * \param[out] cert             Holds a pointer to the leaf certificate on successful return. The actual type is \c mbedtls_x509_crt *
 * \param[out] trusted          Set to \c TRUE if the server is trusted based on current trust configuration, otherwise \c FALSE
 *
 * \return                      The HTTP status code, or -1 if the connection failed.
 */
int LibHsmWebGetCertificate(LibHsmHandle handle, const char *url_path, unsigned char **response, unsigned long *response_length, void *cert, BOOL *trusted);

/**
 * \brief                       Returns the URL for the VedHsm backend.
 *
 * \details This function returns a string buffer with the URL of the configured VedHsm backend.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      A pointer to a buffer holding the URL.
 */
const char *LibHsmGetHsmUrl(LibHsmHandle handle);

/**
 * \brief                       Returns the URL for the VedAuth backend.
 *
 * \details This function returns a string buffer with the URL of the configured VedAuth backend.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      A pointer to a buffer holding the URL.
 */
const char *LibHsmGetAuthUrl(LibHsmHandle handle);

/**
 * \brief                       Sets the URLs for accessing the VedAuth and/or VedHsm backend.
 *
 * \details This function sets the URLs to use when communicating with the backed, both for authentication and for HSM operations.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] auth_url          The VedAuth URL to use, or \c NULL of the existing URL should not be changed
 * \param[in] hsm_url           The VedHsm URL to use, or \c NULL of the existing URL should not be changed
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmSetUrls(LibHsmHandle handle, const char *auth_url, const char *hsm_url);

/**
 * \brief An enumeration of the possible URL types that can be set
 */
typedef enum {
	LibHsmUrlTypeDetect = 0,		/**< A hostname or base URL to use as the basis for URL auto detection */
	LibHsmUrlTypeAuth = 1,			/**< The `/VedAuth` URL to be used for authentication */
	LibHsmUrlTypeHSM = 2,			/**< The `/VedHsm` URL to be used for HSM operations */
	LibHsmUrlTypeTimestamp = 3,		/**< The `/timestamp` URL to be used for timestamping */
	LibHsmUrlTypePks = 4,			/**< The `/pks` URL to be used for GPG public key server requests */
	LibHsmUrlTypeUpdates = 5,		/**< The `/csc` URL to be used for client updates */
} LibHsmUrlType;

/**
 * \brief                       Sets a URL for accessing various backends
 *
 * \details This function sets one or more URLs to use when communicating with
 *          the backed, for authentication, HSM operations and other operations.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] url_type			The URL that should be set.
 * \param[in] url				The URL to use
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmSetUrl(LibHsmHandle handle, LibHsmUrlType url_type, const char *url);

/**
 * \brief                       Returns the specified URL.
 *
 * \details This function returns a string buffer with the URL configured for the specified purpose.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] url_type			The type of the URL to be returned.
 *
 * \return                      A pointer to a buffer holding the URL.
 */
const char *LibHsmGetUrl(LibHsmHandle handle, LibHsmUrlType url_type);

/**
 * \brief An enumeration of the available web proxy modes that may be used.
 */
typedef enum {
	LibHsmWebProxyUnconfigured = 0,	/**< Proxy option has not been initialized; will act as disabled until default is loaded */
	LibHsmWebProxyAutomatic = 1,	/**< Web requests will use the system HTTP proxy if configured */
	LibHsmWebProxyUrl = 2,			/**< A user specified HTTP proxy will be used for all web requests */
	LibHsmWebProxyDisabled = 3,		/**< Web requests will not use an HTTP proxy */
} LibHsmWebProxyMode;

/**
 * \brief						Sets proxy options for all web requests.
 *
 * \details This function sets the proxy mode and URL to use when making any web request.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] mode              The desired proxy mode
 * \param[in] url               The proxy URL to use if mode is LibHsmWebProxyUrl, or \c NULL otherwise. The URL must use the http: scheme, and should include a host and port.
 * \param[in] no_proxy          A list of host names for which the proxy should not be used
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmWebSetProxy(LibHsmHandle handle, LibHsmWebProxyMode mode, char *url, char *no_proxy);

/**
 * \brief						Returns the proxy mode and/or the configured proxy URL used for web requests.
 *
 * \details	This function returns the configured proxy mode, and if applicable the URL of the HTTP proxy being used for web requests.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[out] mode             Receives the currently configured proxy mode
 * \param[out] url              Receives a pointer to a buffer holding the URL of the HTTP proxy currently being used for web requests. If the mode is set to \c LibHsmWebProxyAutomatic then this will return the system proxy if enabled or \c NULL
 * \param[out] no_proxy         Receives a pointer to a buffer holding a list of hosts for which the proxy should not be used
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmWebGetProxy(LibHsmHandle handle, LibHsmWebProxyMode *mode, char **url, char **no_proxy);

/**
 * \brief                       Load the full LibHsm configuration.
 *
 * \details This function (re-)loads all configuration values for the LibHsm instance. \note Use with caution. LibHsm might cache certain configuration items despite the reload. Use LibHsmReinitialize() instead.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmLoadConfiguration(LibHsmHandle handle);

/**
 * \brief                       Free any loaded configuration values.
 *
 * \details This function frees all configuration values for the LibHsm instance. \note Use with caution. LibHsm expects a valid configuration in memory.
 *
 * \param[in] handle            A valid LibHsm instance handle
 */
void LibHsmConfigurationCleanup(LibHsmHandle handle);

/**
 * \brief                       Verify functioning LibHsm configuration.
 *
 * \details Attempts to connect to the configured HSM Backend URL and confirms it responds to HSM commands; returns the server response in result which must be freed with GlobalFree.
 * \note This API is intended for utilities (like CSPDiag) to verify configuration status.
 *
 * \param[in] machine_context   \c FALSE is the user configuration is to be used, \c TRUE for machine configuration
 * \param[in] name              The configuration context (e.g. libhsm or CSP)
 * \param[out] result           A pointer to the server response. Must be freed with GlobalFree()
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmVerifyConfiguration(BOOL machine_context, const char *name, unsigned char **result);

/**
 * \brief                       Check authentication requirements. (FUTURE USE)
 *
 * \details Checks if 2-factor authentication is required in order to use libhsm (determined by configuration)
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      \c TRUE if authentication is required, \c FALSE otherwise.
 */
BOOL LibHsmAuthenticationRequired(LibHsmHandle handle);

/**
 * \brief                       Verifies that the client can communicate with the configured VedHsm server.
 *
 * \details This function will contact the configured VedHsm server to test communication.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return						\c TRUE if the function was successful. \c FALSE if an error occurred.
 */
BOOL LibHsmCheck(LibHsmHandle handle);

/**
 * \brief                       Returns information about the stored authentication grant.
 *
 * \param[in] handle              A valid LibHsm instance handle
 * \param[out] have_access_token  Receives a \c TRUE if an access token is stored, \c FALSE otherwise
 * \param[out] have_refresh_token Receives a \c TRUE if a refresh token is stored, \c FALSE otherwise
 * \param[out] access_days        Receives the number of days the grant is still valid
 * \param[out] valid_until        Receives the date/time the grant expires
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmGetGrantStatus(LibHsmHandle handle, BOOL *have_access_token, BOOL *have_refresh_token, long *access_days, time_t *valid_until);

/**
 * \brief                       Returns configured value 'LABEL FILTER'.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      \c A pointer to a buffer holding configured 'LABEL FILTER' if it exists, \c NULL.
 */
const char *LibHsmGetLabelFilter(LibHsmHandle handle);

/**
 * \brief                       Checks if a specific error has occurred.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] expected          The \ref LibHsmErrorStatus value to lof for
 * \param[out] result           The LibHsmError object if a match was found. Pass \c NULL of the object is not wanted. 
 *
 * \return                      \c TRUE if the error occurred, \c FALSE otherwise.
 */
BOOL LibHsmHasError(LibHsmHandle handle, LibHsmErrorStatus expected, LibHsmError **result);

/**
 * \brief                       Checks if an error has occurred.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      \c TRUE if an error occurred, \c FALSE otherwise.
 */
BOOL LibHsmInError(LibHsmHandle handle);

/**
 * \brief                       Adds an error to the error stack.
 * \details LibHsm tracks errors in a stack. This way it is possible for each layer for function calls to add context-specifc details to an error condition. This function adds a new error to the top of the stack.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] status            The \ref LibHsmErrorStatus to add to the error stack
 * \param[in] error             The error text to add to the error stack
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmSetError(LibHsmHandle handle, LibHsmErrorStatus status, char *error);

/**
 * \brief                       Adds an error to the error stack.
 * \details This function allows to use printf() formatting in \p error_format to easily build an error text to be added to the error stack.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] status            The \ref LibHsmErrorStatus to add to the error stack
 * \param[in] error_format      The print() format string
 * \param[in] ...               The arguments for the error_format string
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmSetErrorArgs(LibHsmHandle handle, LibHsmErrorStatus status, char *error_format, ...);

/**
 * \brief                       Clears the error stack.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmClearErrors(LibHsmHandle handle);

/**
 * \brief                       Returns the top error stack error.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      The \ref LibHsmErrorStatus that was recorded last, or ::LibHsmErr_Success if no error occurred.
 */
LibHsmErrorStatus LibHsmGetError(LibHsmHandle handle);

/**
 * \brief                       Returns the complete error stack as a single string.
 * \details This function either returns the last error string, or takes all errors, depending on \p all, 
 * from the stack and combines them into a single string. The beginning of the string holds the newest error 
 * (closest to the caller). The error elements are separated by the \p separator string.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] all               \c TRUE if all errors should be returned
 * \param[in] separator         The string to use to separate errors, or \c NULL to use the default "; ".
 * \param[out] error            Pointer to the error strings. \note \p error must be freed with LibHsmFreeErrorText()
 *
 * \return                      The \ref LibHsmErrorStatus that was recorded last, or ::LibHsmErr_Success if no error occurred.
 */
BOOL LibHsmGetErrorText(LibHsmHandle handle, BOOL all, const char *separator, char **error);

/**
 * \brief                       Frees a memory pointer returned by the LibHsmGetErrorText() function.
 *
 * \details This function must be used to free the error pointer returned by LibHsmGetErrorText().
 *
 * \param[in] error             The pointer to free
 */
void LibHsmFreeErrorText(char *error);

/**
 * \brief                       Frees a LibHsmError structure.
 *
 * \details This function must be used to free a LibHsmError structure.
 *
 * \param[in] error             The structure to free
 */
void LibHsmFreeError(LibHsmError *error);

/**
 * \brief                       Request a new grantjwt from the configured authentication server.
 *
 * \details Used to request a new OAuth grant using a JWT from the Authentication server. The URL for the server must
 * already be configured.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] scope             The scope to request
 * \param[in] jwt				A valid, signed JWT
 * 
 * \return                      \c TRUE if a new grant has been obtained, \c FALSE otherwise.
 */
BOOL LibHsmOAuthRequestGrantJwt(LibHsmHandle handle, const char *scope, const char *jwt);

/**
 * \brief                       Request a new grant from the configured authentication server.
 *
 * \details Used to request a new OAuth grant from the Authentication server. The URL for the server must
 * already be configured. JWTs are also included
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] username          The username to use for authenticaton
 * \param[in] password          The password for \p username
 * \param[in] scope             The scope to request
 *
 * \return                      \c TRUE if a new grant has been obtained, \c FALSE otherwise.
 */
BOOL LibHsmOAuthRequestGrant(LibHsmHandle handle, const char* username, const char* password, const char* scope);

/**
 * \brief                       Refresh the current grant.
 *
 * \details If a grant exists, this command can refresh it. It requires that the existing grant is refreshable.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      \c TRUE if the existing grant has been refreshed, \c FALSE otherwise.
 */
BOOL LibHsmOAuthRefreshAccessToken(LibHsmHandle handle);

/**
 * \brief                       Revokes the current grant.
 *
 * \details If a grant exists, this command will revoke it with the configured authentication server.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      \c TRUE if the existing grant has been revoked, \c FALSE otherwise.
 */
BOOL LibHsmOAuthRevokeGrant(LibHsmHandle handle);

/**
 * \brief                       Verifies that the current grant is known to the configured authentication server.
 *
 * \details This function will contact the configured authentication server and confirm that the current grant is known and valid.
 *
 * \param[in] handle            A valid LibHsm instance handle
 *
 * \return                      \c TRUE if the current grant is valid, \c FALSE otherwise.
 */
BOOL LibHsmOAuthVerifyGrant(LibHsmHandle handle);


/**
 * \brief                       Retrieves Hsm objects from the configured VedHsm server.
 *
 * \details This function will make a REST call to the configured server and retrieve available objects. The \p filter_object allows to
 * filter the list of returned objects. If \p include_chains is set to \c TRUE, the available certificate chain for certificate
 * objects will be returned as well. If \p pending is \c TRUE on success, it indicates that there are more objects available for the caller, but the server had not
 * finished issuing the key material for them yet. 
 *
 * \note The returned \p objects object list must be freed with LibHsmFreeObjectList() when no longer used.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] filter            \c NULL if no filtering is needed, or a valid \p LibHsmFilterHandle (can be obtained via LibHsmFilterCreate())
 * \param[in] include_chains    \c TRUE if the chain for any certificate objects should be included in the object list
 * \param[in] include_archived  \c TRUE to return expired/renewed objects for the same environment
 * \param[out] pending          \c TRUE on return if the server has objects that could not be used yet because they're still in the process of being created.
 * \param[out] truncated        \c TRUE on return if the server has objects that could not be used yet because the maximum number of objects was exceeded.
 * \param[out] objects          Receives the pointer to a linked list of HsmObject objects with all found and matching objects
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiGetObjects(LibHsmHandle handle, LibHsmFilterHandle filter, BOOL include_chains, BOOL include_archived, BOOL *pending, BOOL *truncated, HsmObject **objects);

/**
 * \brief                       Stores a public and private key for an HSM object on the configured VedHsm server.
 *
 * \details This function will make a REST call to the configured server and store the specified key pair for the given key id and context.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] key				The key id for which to update the key pair
 * \param[in] context			The context of the key, or \c NULL
 * \param[in] public_key		A pointer to the public key data
 * \param[in] public_key_len	The length, in bytes, of the public key
 * \param[in] private_key		A pointer to the private key data
 * \param[in] private_key_len	The length, in bytes, of the private key
 * \param[in] timestamp			An ISO8601-formatted string indicating the creation time of the key pair, or \c NULL
 * \param[in] identifier        An identifier string associated with the key, or \c NULL
 * \param[in] password          The password needed to decrypt the provided private key, or \c NULL
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiStoreObject(LibHsmHandle handle, char *key, char *context, unsigned char *public_key, unsigned long public_key_len, unsigned char *private_key, unsigned long private_key_len, char *timestamp, char *identifier, char *password);

/**
 * \brief                       Retrieves the certificate chain for a certificate object.
 *
 * \details Use this function to retrieve the certificate chain objects for the certificate specified by \p certificate. 
 *
 * \note The returned \p chain object list must be freed with LibHsmFreeObjectList() when no longer used.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] certificate       A \p HsmObject of type ::CryptokiCertificate for which to retrieve the chain
 * \param[out] chain           Receives the pointer to a linked list of HsmObject objects with the ordered certificate chain starting with the root entity
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiGetCertificateChain(LibHsmHandle handle, HsmObject *certificate, HsmObject **chain);

/**
 * \brief                       Retrieves the certificate chain for a certificate object.
 *
 * \details Use this to obtain a Windows \c PCCERT_CONTEXT for the \p object of type ::CryptokiCertificate.
 *
 * \note This function is a no-op on Mac and Linux.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] object            A \p HsmObject of \ref HsmObject.ObjectType ::CryptokiCertificate for which to retrieve the chain
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
PCCERT_CONTEXT LibHsmLoadWinCertificateHandle(LibHsmHandle handle, HsmObject *object);

/**
 * \brief                       Signs data.
 *
 * \details Use this function to sign data. The function will perform a REST call to the VedHsm backend and the backend will create the signature if the
 * caller is permitted to.
 *
 * \note The returned \p signature pointer must be freed with LibHsmFreeResult() when no longer used.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] mechanism         The \ref CryptokiMechanism to be used for signing
 * \param[in] client_mechanism  The \ref CryptokiMechanism the client calling LibHsm was asked to use. (If the client performs hashing by itself, it would not specify the hash in \p mechanism, but it must provide it for this parameter. For example ::CryptokiMechanismRsaPkcs and ::CryptokiMechanismRsaSha256 respectively)
 * \param[in] key               The key to use for signing
 * \param[in] hash_value        The data/hash to sign
 * \param[in] hash_len          The length, in bytes, of the \p hash_value data
 * \param[in] parameter         If a parameter is required for the specific signature \p mechanism, it can be provided via this argument. Otherwise \c NULL
 * \param[out] signature        Receives a pointer to the signature
 * \param[out] signature_len    Receives the length of the \p signature byte array
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiSign(LibHsmHandle handle, unsigned long mechanism, unsigned long client_mechanism, const HsmObject *key, const unsigned char *hash_value, unsigned long hash_len, LibHsmApiCryptoParameter *parameter, unsigned char **signature, unsigned long *signature_len);

/**
 * \brief                       Verifies a signature. (FUTURE USE)
 *
 * \details Use this function to verify signatures. The function will perform a REST call to the VedHsm backend for verification. 
 * \note Use LibHsmVerifySignature() to verify signatures locally without involving a REST call.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] mechanism         The \ref CryptokiMechanism to be used for verification
 * \param[in] client_mechanism  The \ref CryptokiMechanism the client calling LibHsm was asked to use. (If the client performs hashing by itself, it would not specify the hash in \p mechanism, but it must provide it for this parameter. For example ::CryptokiMechanismRsaPkcs and ::CryptokiMechanismRsaSha256 respectively)
 * \param[in] key               The key to use for verification
 * \param[in] hash_value        The data/hash to sign
 * \param[in] hash_len          The length, in bytes, of the \p hash_value data
 * \param[in] signature         The signature to verify
 * \param[in] signature_len     The length of the \p signature byte array
 * \param[in] parameter         If a parameter is required for the specific verification \p mechanism, it can be provided via this argument. Otherwise \c NULL
 * \param[in] signature_ok      Receives \c TRUE if the signature was valid, \c FALSE otherwise. \note Do NOT use the return value from LibHsmApiVerify() to determine if the signature is valid. It will only return false if the REST call failed.
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiVerify(LibHsmHandle handle, unsigned long mechanism, unsigned long client_mechanism, const HsmObject *key, const unsigned char *hash_value, unsigned long hash_len, const unsigned char *signature, unsigned long signature_len, LibHsmApiCryptoParameter *parameter, BOOL *signature_ok);

/**
 * \brief                       Encrypt data. (FUTURE USE)
 *
 * \details Use this function to encrypt data. The function will perform a REST call to the VedHsm backend and the backend will perform the encryption if the
 * caller is permitted to.
 *
 * \note The returned \p ciphertext pointer must be freed LibHsmFreeResult() when no longer used.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] mechanism         The \ref CryptokiMechanism to be used for signing
 * \param[in] key               The key to use for encryption
 * \param[in] plaintext         The data to encrypt
 * \param[in] plaintext_len     The length, in bytes, of the \p plaintext data
 * \param[in] parameter         If parameters are required for the specific \p mechanism, they can be provided via this arguments. Otherwise \c NULL
 * \param[out] ciphertext       Receives a pointer to the ciphertext
 * \param[out] ciphertext_len   Receives the length of the \p ciphertext byte array
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiEncrypt(LibHsmHandle handle, unsigned long mechanism, const HsmObject *key, const unsigned char *plaintext, unsigned long plaintext_len, LibHsmApiCryptoParameter *parameter, unsigned char **ciphertext, unsigned long *ciphertext_len);

/**
 * \brief                       Decrypt data.
 *
 * \details Use this function to encrypt data. The function will perform a REST call to the VedHsm backend and the backend will perform the decryption if the
 * caller is permitted to.
 *
 * \note The returned \p plaintext pointer must be freed LibHsmFreeResult() when no longer used.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] mechanism         The \ref CryptokiMechanism to be used for signing
 * \param[in] key               The key to use for decryption
 * \param[in] ciphertext        The data to decrypt
 * \param[in] ciphertext_len    The length, in bytes, of the \p ciphertext data
 * \param[in] parameter         If parameters are required for the specific \p mechanism, they can be provided via this arguments. Otherwise \c NULL
 * \param[out] plaintext        Receives a pointer to the plaintext
 * \param[out] plaintext_len    Receives the length of the \p plaintext byte array
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiDecrypt(LibHsmHandle handle, unsigned long mechanism, const HsmObject *key, const unsigned char *ciphertext, unsigned long ciphertext_len, LibHsmApiCryptoParameter *parameter, unsigned char **plaintext, unsigned long *plaintext_len);

BOOL LibHsmApiWrapKey(LibHsmHandle handle, const HsmObject *wrapping_key, const HsmObject *key, unsigned char **wrapped_key, unsigned long *wrapped_key_len);
BOOL LibHsmApiUnwrapKey(LibHsmHandle handle, const HsmObject *unwrapping_key, unsigned char **wrapped_key, unsigned long *wrapped_key_len);

/**
 * \brief                       Signs JSON Web Token.
 *
 * \details Use this function to sign a JWT Token. The function will perform a REST call to the VedHsm backend and the backend will create the signature if the
 * caller is permitted to and return the whole token.
 *
 * \note The returned \p signature pointer must be freed with LibHsmFreeResult() when no longer used.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] key               The key to use for signing
 * \param[in] header			The Base64Url encoded header of the token to sign
 * \param[in] payload			The Base64Url encoded payload of the token to sign
 * \param[in] parameter         If a parameter is required for the specific signature \p mechanism, it can be provided via this argument. Otherwise \c NULL
 * \param[out] signature        Receives a pointer to the signature
 * \param[out] signature_len    Receives the length of the \p signature byte array
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiSignJwt(LibHsmHandle handle, const HsmObject* key, char* header, char* payload, LibHsmApiCryptoParameter* parameter, unsigned char** signature, unsigned long* signature_len);

/**
 * \brief                       Derive an ECDH key
 *
 * \details Use this function to perform ECDH key derivation. The function will perform a REST call to the VedHsm backend and the backend will
 * perform the key derivation if the caller is permitted to.
 *
 * \note The returned \p key pointer must be freed LibHsmFreeResult() when no longer used.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] mechanism         The \ref CryptokiMechanism to be used for key derivation
 * \param[in] private_key       The private EC key to use for key derivation
 * \param[in] parameter         The parameter required by the specific key derivation \p mechanism
 * \param[out] derived_key		Receives a pointer to the resulting derived key
 * \param[out] derived_key_len	Receives the length of the \p derived_key byte array
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiDeriveKey(LibHsmHandle handle, unsigned long mechanism, const HsmObject *private_key, LibHsmApiCryptoParameter *parameter, unsigned char **derived_key, unsigned long *derived_key_len);

/**
 * \brief                       Retrieves a GPG public key from the configured VedHsm server
 *
 * \details This function will make a REST call to the configured server and retrieve details about the GPG public key for the specified object.
 *
 * \note The returned \p values must be freed with LibHsmFreeResult() when no longer used.
 *
 * \param[in] handle			A valid LibHsm instance handle
 * \param[in] key				The key id which the returned public key should represent
 * \param[in] context			The context of the key, or \c NULL
 * \param[out] fingerprint		Receives the GPG fingerprint, returned by the server
 * \param[out] public_key		Receives a pointer to the resulting public key
 * \param[out] public_key_len	Receives the length of the \p public_key byte array
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmApiGetGPGPublicKey(LibHsmHandle handle, const char *key, const char *context, char **fingerprint, unsigned char **public_key, unsigned long *public_key_len);

/**
 * \brief                       Return the cached object list.
 *
 * \details This function returns a pointer to the LibHsm object list. If the object list has not yet been retrieved, it will trigger a REST call to the server
 * and obtain all objects permitted to be viewed based on the current grant.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[out] result           Received a pointer to the cached \ref HsmObject list 
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmGetObjectList(LibHsmHandle handle, HsmObject **result);

/**
 * \brief                       Frees an object list.
 *
 * \details Use this function to free all data associated with an object list returned by LibHsmApiGetObjects() or LibHsmApiGetCertificateChain() once the objects are no longer needed and referenced.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] objects           A \ref HsmObject obtained via LibHsmApi calls.
 *
 * \return                      \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmFreeObjectList(LibHsmHandle handle, HsmObject *objects);

/**
 * \brief                       Looks up an existing object by Handle.
 *
 * \details This function uses a dictionary to quickly look up an existing object by handle.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] object_handle     The object handle to search for
 * \param[out] result           Receives a pointer to the matching \ref HsmObject.
 *
 * \return                      \c TRUE if an object was found, \c FALSE otherwise.
 */
BOOL LibHsmFindObjectByHandle(LibHsmHandle handle, const unsigned long object_handle, HsmObject **result);

/**
 * \brief                       Looks up an existing certificate object by key_id.
 *
 * \details This function uses a dictionary to quickly look up an existing certificate object by key id.
 *
 * \param[in] handle            A valid LibHsm instance handle
 * \param[in] key_id            The key id to search for
 * \param[out] result           Receives a pointer to the matching \ref HsmObject.
 *
 * \return                      \c TRUE if an object was found, \c FALSE otherwise.
 */
BOOL LibHsmFindObjectByKeyId(LibHsmHandle handle, const char *key_id, HsmObject **result);

/**
 * \brief                       Creates a new filter object.
 *
 * \details Use this function to obtain an \p LibHsmFilterHandle. You can then use LibHsmFilter methods to add items to the filter. Filters are accepted for LibHsmApi methods that retrieve objects.
 * \note When the filter object is no longer needed or in use, use LibHsmFilterFree() to release its resources.
 *
 * \param[out] handle            Receives the filter handle
 * \param[out] error             Receives any error that may have occurred. Can be \c NULL if no error detail is needed
 *
 * \return                      \c TRUE if a handle was created, \c FALSE otherwise.
 */
BOOL LibHsmFilterCreate(LibHsmFilterHandle *handle, LibHsmError **error);

/**
 * \brief                       Set a key id as filter.
 *
 * \details This functions sets the key id filter. One filter can only filter by a single key id. If the filter already has a key id when this function
 * is called, the previous key id will be replaced.
 *
 * \param[in] handle            The filter handle
 * \param[in] object            The object whose key id should be added to the filter
 * \param[out] error            Receives any error that may have occurred. Can be \c NULL if no error detail is needed
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmFilterAddKeyId(LibHsmFilterHandle handle, HsmObject *object, LibHsmError **error);

/**
 * \brief                       Set a key context as filter.
 *
 * \details This functions sets the key context filter. One filter can only filter by a single key context. If the filter already has a key context when this function
 * is called, the previous key context will be replaced.
 *
 * \param[in] handle            The filter handle
 * \param[in] object            The object whose key context should be added to the filter
 * \param[out] error            Receives any error that may have occurred. Can be \c NULL if no error detail is needed
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmFilterAddKeyContext(LibHsmFilterHandle handle, HsmObject *object, LibHsmError **error);

/**
 * \brief                       Adds a \ref CryptokiObjectType to the filter.
 *
 * \details This functions adds a \ref CryptokiObjectType to the filter. If the object type already is in the filter, the function will return \c TRUE.
 *
 * \param[in] handle            The filter handle
 * \param[in] object_type       The \ref CryptokiObjectType to add to the filter
 * \param[out] error            Receives any error that may have occurred. Can be \c NULL if no error detail is needed
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmFilterAddObjectType(LibHsmFilterHandle handle, CryptokiObjectType object_type, LibHsmError **error);

/**
 * \brief                       Adds a \ref HsmEnvironmentType to the filter.
 *
 * \details This functions adds a \ref HsmEnvironmentType to the filter. If the environment type already is in the filter, the function will return \c TRUE.
 *
 * \param[in] handle            The filter handle
 * \param[in] environment_type  The \ref HsmEnvironmentType to add to the filter
 * \param[out] error            Receives any error that may have occurred. Can be \c NULL if no error detail is needed
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmFilterAddEnvironmentType(LibHsmFilterHandle handle, HsmEnvironmentType environment_type, LibHsmError **error);

/**
 * \brief                       Set or clear filter flags
 *
 * \details This functions sets or clears flags on a filter, which can modify the behavior of LibHsmApiGetObjects.
 *
 * \param[in] handle            The filter handle
 * \param[in] set               A flag to set, or 0
 * \param[in] clear             A flag to clear, or 0
 * \param[out] error            Receives any error that may have occurred. Can be \c NULL if no error detail is needed
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
 */
BOOL LibHsmFilterSetFlags(LibHsmFilterHandle handle, LibHsmFilterFlags set, LibHsmFilterFlags clear, LibHsmError **error);

/**
 * \brief                       Resets the filter criteria stored in a filter.
 *
 * \details Use this function to reset a filter.
 *
 * \param[in] handle            The filter handle
 *
 * \return                      \c TRUE if the handle was reset, \c FALSE otherwise.
 */
BOOL LibHsmFilterReset(LibHsmFilterHandle handle);

/**
 * \brief                       Frees a filter object.
 *
 * \details Use this function to release any memory associated with an \p LibHsmFilterHandle once you no longer need the filter
 *
 * \param[in] handle            The filter handle
 *
 * \return                      \c TRUE if the handle was freed, \c FALSE otherwise.
 */
BOOL LibHsmFilterFree(LibHsmFilterHandle handle);

/**
 * \brief                Verifies a signature against the public key.
 *
 * \param[in] handle     A valid LibHsm handle
 * \param[in] key        The public key to use for verification
 * \param[in] mechanism  The Pkcs11 mechanism id used to sign
 * \param[in] parameter  A \ref LibHsmApiCryptoParameter parameter structure, or \c NULL if no parameters are needed
 * \param[in] hash       The hash/digest to verify against the signature
 * \param[in] hash_len   The length of the hash/digest
 * \param[in] sig        The signature byte array
 * \param[in] sig_len    Length of the signature in bytes
 *
 * \return               \c TRUE if the signature was valid, \c FALSE if an error occurred or the signature was not valid. Use LibHsmHasError(handle, LibHsmErr_InvalidSignature, NULL) to determine if the signature was invalid.
 */
BOOL LibHsmVerifySignature(LibHsmHandle handle, HsmObject *key, unsigned long mechanism, LibHsmApiCryptoParameter *parameter, const unsigned char *hash, size_t hash_len, const unsigned char *sig, size_t sig_len);

/**
 * \brief                Creates an ASN.1 MessageDigest structure.
 *
 * \param[in] handle           A valid LibHsm handle
 * \param[in] digest_mechanism The Pkcs#11 Mechanism specifying the digest \ref CryptokiMechanism 
 * \param[in] hash             Byte array containing the hash to store in the message digest
 * \param[in] hash_len         The length of the \p hash byte array
 * \param[out] digest_ptr      A pointer to a byte array pointer; on return it will be a pointer to the generated message digest
 * \param[out] digest_len      A pointer to a length variable holding the length, in bytes, of the message digest upon return
 *
 * \return               \c TRUE if the digest was created, \c FALSE otherwise.
 */
BOOL LibHsmCreateMessageDigest(LibHsmHandle handle, unsigned long digest_mechanism, const unsigned char *hash, size_t hash_len, unsigned char **digest_ptr, size_t *digest_len);

/**
 * \brief                Frees an ASN.1 MessageDigest structure returned by \c LibHsmCreateMessageDigest.
 *
 * \param[in] handle        A valid LibHsm handle
 * \param[in] digest_ptr    A message digest pointer returned by \c LibHsmCreateMessageDigest
 *
 * \return               \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmFreeMessageDigest(LibHsmHandle handle, unsigned char *digest_ptr);

/**
 * \brief               Obtains cryptographically-safe random numbers.
 * \details Returns an array of random numbers based on NIST SP 800-90 DRBG.
 *
 * \param[in] handle    A valid LibHsm handle
 * \param[out] buffer   The buffer to store \c length bytes of random data
 * \param[in] length    The number of random bytes to return in \c buffer. \c buffer must be at least \c length bytes in size.
 *
 * \return               \c TRUE on success, \c FALSE otherwise.
 */
BOOL LibHsmRngGet(LibHsmHandle handle, unsigned char *buffer, size_t length);

/**
 * \brief               Initialize the trace logging APIs.
 * \details The trace target is configured via options by the end-user through the config utility. Users can trace to file and/or console.
 *
 * \param[in] handle    A valid LibHsm handle
 *
 * \note VTraceInit() and VTraceShutdown() perform reference counting. You can call VTraceInit() more than once but you must call VTraceShutdown() a matching number of times.
 */
void VTraceInit(LibHsmHandle handle);

/**
 * \brief               Logs a static message text.
 *
 * \param[in] message   The message to record
 */
void VTraceMessage(const char *message);

/**
 * \brief               Logs a message. printf() equivalent trace function.
 * \param[in] message   The print() message-format string
 * \param[in] ...       The arguments for the \p message string
 */
void VTraceMessageArgs(const char *message, ...);

/**
 * \brief               Closes the trace output and disables further tracing.
 *
 * \note VTraceInit() and VTraceShutdown() perform reference counting. You must issue a call to VTraceShutdown() for each call to VTraceInit(). The trace will only be closed on the last VTraceShutdown().
 */
void VTraceShutdown(void);

/**
 * \struct ProcessInfoStruct
 *
 * \brief Data object to information about the calling process.
 *
 * \details The \p ProcessInfoStruct is returned by the GetProcessInfo() function to obtain information about
 * the calling process (when used in a shared library/DLL). Not all fields will be filled out on all platforms.
 *
 * \headerfile libhsm.h <venafi/libhsm.h>
 */
typedef struct _ProcessInfoStruct {
	char *Application;                  /**< The name of the application binary */
	size_t ApplicationSize;             /**< The size of the application binary */
	char *Commandline;                  /**< The full commandline that was used to start the application */
	unsigned char *Hash;                /**< The Sha-256 hash of the application binary */
	char *SignedProgramName;            /**< The name of the application binary when it was signed */
	char *SignedTimestamp;              /**< The timestamp when the application was signed */
	char *Signer;                       /**< The X.509 DN of the signer of the application */
	char *Issuer;                       /**< The X.509 DN of the issuer of the signing certificate for the application */
} ProcessInfoStruct;

/**
 * \brief                       Obtains information about the calling process.
 *
 * \details This function, when used in a shared library/DLL, will return a \p ProcessInfoStruct with details about the calling application.
 *
 * \return                      A pointer to a ProcessInfoStruct, or \c NULL on error. Must be freed with FreeProcessInfo()
 */
ProcessInfoStruct *GetProcessInfo(void);

/**
 * \brief               Frees a \ref ProcessInfoStruct returned from GetProcessInfo().
 *
 * \param[in] info      The structure to free
 */
void FreeProcessInfo(ProcessInfoStruct *info);

/**
 * \brief               Obtains information about the specified application.
 *
 * \details This function, when used in a shared library/DLL, will return a \p ProcessInfoStruct with details about the specified application.
 *
 * \param[in] application   Path to the application
 *
 * \return              A pointer to a ProcessInfoStruct, or \c NULL on error. Must be freed with FreeProcessInfo().
 */
ProcessInfoStruct *GetApplicationInfo(unsigned char *application);

/**
 * \typedef ConfigHandle
 *
 * \brief Handle for a configuration object.
 *
 * \headerfile libhsm.h <venafi/libhsm.h>
 */
typedef void	*ConfigHandle;

/**
 * \brief               Open a configuration store.
 *
 * \details Opens the named configuration store. This function will load all configuration values from the store into memory on open. An application
 * should not keep a configuration store open for longer than to read its configuration values. 
 *
 * \param[in] name            The name of the store to open.
 * \param[in] machine_context \c TRUE if the machine store should be opened, \c FALSE otherwise
 * \param[out] handle         Receives a valid \ref ConfigHandle on return
 * \param[out] error          Receives a valid \ref LibHsmError object on error
 *
 * \return                \c TRUE if the store was successfully opened. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL LibHsmConfLoad(const char *name, BOOL machine_context, ConfigHandle *handle, LibHsmError **error);

/**
 * \brief               Open or create a configuration store.
 *
 * \details Opens the named configuration store. This function will load all configuration values from the store into memory on open. An application
 * should not keep a configuration store open for longer than to read its configuration values. If the store does not exist and \p create_ok is \c TRUE
 * the store will be created. Store creation requires sufficient privileges for the calling user (e.g. on Unix the caller must have write rights to  /etc/venafi).
 *
 * \param[in] name            The name of the store to open.
 * \param[in] machine_context \c TRUE if the machine store should be opened, \c FALSE otherwise
 * \param[out] handle         Receives a valid \ref ConfigHandle on return
 * \param[in] create_ok       Set to \c TRUE if the store should be created if it does not exist
 * \param[out] error          Receives a valid \ref LibHsmError object on error
 *
 * \return                \c TRUE if the store was successfully opened. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL LibHsmConfLoadCreate(const char *name, BOOL machine_context, ConfigHandle *handle, BOOL create_ok, LibHsmError **error);

/* Returns a list of stores; typical name_buffer = NULL asks for size in name_buffer_length rules apply */
/**
 * \brief                Returns names of all configuration stores.
 *
 * \details This function returns the names of all stores. It is useful when enumerating and retrieving every store is required.
 * The result buffer \p name_buffer must be allocated by the caller. To obtain the size of the buffer, first call with \p name_buffer set to \c NULL,
 * and the required number of bytes will be returned in \p name_buffer_length.
 *
 * \param[in] machine_context        \c TRUE if the machine store should be opened, \c FALSE otherwise
 * \param[in] name_buffer            A pointer to a buffer allocated by the caller. Pass \c NULL to get the required buffer size returned in \p name_buffer_length
 * \param[in,out] name_buffer_length If \p name_buffer is not \c NULL, must contain the size of the buffer. On return, holds the number of bytes stored in \p name_buffer
 * \param[out] number_of_names       On return, holds the number of names stored in \p name_buffer
 * \param[out] error                 Receives a valid \ref LibHsmError object in case of error
 *
 * \return               \c TRUE on success. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL
LibHsmConfEnumerateInstances(BOOL machine_context, char **name_buffer, unsigned long *name_buffer_length, int *number_of_names,
	LibHsmError **error);

/**
 * \brief                Save a configuration store.
 *
 * \details Saves all values set for a configuration store. Values in an open store are only stored in memory until this function is called to
 * write them out to the store (disk or registry).
 *
 * \param[in] handle     A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] error      Receives a valid \ref LibHsmError object in case of error
 *
 * \return               \c TRUE if the store was successfully saved. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL LibHsmConfSave(ConfigHandle handle, LibHsmError **error);

/**
 * \brief                Mark a configuration store for deletion
 *
 * \details Calling this function marks a configuration store for deletion. The store will not actually be deleted until LibHsmConfFree() is
 * called and the \ref ConfigHandle is released.
 *
 * \param[in] handle    A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 *
 * \return              \c TRUE if the function was successful. \c FALSE if an error occurred.
 */
BOOL LibHsmConfDelete(ConfigHandle handle);

/**
 * \brief                Releases a configuration store handle.
 *
 * \details This function will release and close a configuration store. All configuration values in memory will be freed. If the store was marked for
 * deletion, this function will remove it. Unless LibHsmConfSave() was called first, all changes to the configuration store will be lost.
 *
 * \param[in] handle    A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[out] error    Receives a valid \ref LibHsmError object in case of error
 *
 * \return              \c TRUE if the store was successfully freed. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL LibHsmConfFree(ConfigHandle handle, LibHsmError **error);

/**
 * \brief                Check if a configuration value exists.
 *
 * \details This function checks if a value for the given \p name exists in the configuration store.
 *
 * \param[in] handle     A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] name       The configuration name to look for
 *
 * \return               \c TRUE if a value exists, \c FALSE otherwise.
 */
BOOL LibHsmConfHasValue(ConfigHandle handle, const char *name);

/**
 * \brief                Deletes a configuration item from the store.
 *
 * \details This function removes the value for \p name from the store.
 *
 * \param[in] handle     A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] name       The configuration name to look for
 *
 * \return               \c TRUE if the value was found and removed. \c FALSE if no item with the name could be found.
 */
BOOL LibHsmConfDeleteValue(ConfigHandle handle, const char *name);

/**
 * \brief                Retrieve a string value.
 *
 * \details This function retrieves a configuration value of type string from the store.
 *
 * \param[in] handle     A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] name       The configuration name to look for
 * \param[out] value     The stored value for \p name
 *
 * \return               \c TRUE if the value was found and returned. \c FALSE if no item with the name could be found.
 */
BOOL LibHsmConfGetValueString(ConfigHandle handle, const char *name, char **value);

/**
 * \brief                Stores a string value.
 *
 * \details This function stores a configuration value of type string in the store.
 *
 * \param[in] handle     A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] name       The name of the value
 * \param[in] value      The value string to store
 * \param[out] error     Receives a valid \ref LibHsmError object in case of error
 *
 * \return               \c TRUE if the value was stored. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL LibHsmConfSetValueString(ConfigHandle handle, const char *name, const char *value, LibHsmError **error);

/**
 * \brief                Retrieve a binary value.
 *
 * \details This function retrieves a binary configuration value from the store.
 *
 * \param[in] handle     A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] name       The configuration name to look for
 * \param[out] value     The stored byte array for \p name
 * \param[out] value_len The length, in bytes of the data returned in \p value
 * \param[in] decrypt    \c TRUE if the value was stored encrypted and should be returned decrypted 
 * \param[out] error     Receives a valid \ref LibHsmError object in case of error
 *
 * \return               \c TRUE if the value was found and returned. \c FALSE if no item with the name could be found or an error occurred.
 */
BOOL LibHsmConfGetValueData(ConfigHandle handle, const char *name, unsigned char **value, unsigned long *value_len, BOOL decrypt, LibHsmError **error);

/**
 * \brief                Stores a binary value.
 *
 * \details This function stores a binary configuration value in the store. Optionally, the value can be encrypted. On systems where encryption is not
 * supported, the configuration system checks that only the user has access to the stored value and warns if the store (file) is viewable by users other
 * than the store owner.
 *
 * \param[in] handle     A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] name       The name of the value
 * \param[in] value      The byte array to store
 * \param[in] value_len  The length, in bytes, of \p value
 * \param[in] encrypt    \c TRUE if the value should be stored encrypted.
 * \param[out] error     Receives a valid \ref LibHsmError object in case of error
 *
 * \return               \c TRUE if the value was stored. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL LibHsmConfSetValueData(ConfigHandle handle, const char *name, const unsigned char *value, unsigned long value_len, BOOL encrypt, LibHsmError **error);

/* Returns a list of names in the configuration store; typical name_buffer = NULL asks for size in name_buffer_length rules apply */
/**
 * \brief                Returns all names in the configuration store.
 *
 * \details This function returns all configuration names in the store. It is useful when enumerating and retrieving every value in the store is desired.
 * The result buffer \p name_buffer must be allocated by the caller. To obtain the size of the buffer, first call with \p name_buffer set to \c NULL,
 * and the required number of bytes will be returned in \p name_buffer_length.
 *
 * \param[in] handle                 A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] name_buffer            A pointer to a buffer allocated by the caller. Pass \c NULL to get the required buffer size returned in \p name_buffer_length
 * \param[in,out] name_buffer_length If \p name_buffer is not \c NULL, must contain the size of the buffer. On return, holds the number of bytes stored in \p name_buffer
 * \param[out] number_of_names       On return, holds the number of names stored in \p name_buffer
 * \param[out] error                 Receives a valid \ref LibHsmError object in case of error
 *
 * \return               \c TRUE on success. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL LibHsmConfGetNames(ConfigHandle handle, char **name_buffer, unsigned long *name_buffer_length, int *number_of_names, LibHsmError **error);

/* Returns a list of names in the configuration store; typical name_buffer = NULL asks for size in name_buffer_length rules apply */
/**
 * \brief                Returns all names in the configuration store.
 *
 * \details This function returns all configuration names in the store. It is useful when enumerating and retrieving every value in the store is desired.
 * The result buffer \p name_buffer must be allocated by the caller. To obtain the size of the buffer, first call with \p name_buffer set to \c NULL,
 * and the required number of bytes will be returned in \p name_buffer_length.
 *
 * \param[in] handle                 A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in] name_buffer            A pointer to a buffer allocated by the caller. Pass \c NULL to get the required buffer size returned in \p name_buffer_length
 * \param[in,out] name_buffer_length If \p name_buffer is not \c NULL, must contain the size of the buffer. On return, holds the number of bytes stored in \p name_buffer
 * \param[out] number_of_names       On return, holds the number of names stored in \p name_buffer
 * \param[in] returnOnlyStrings      If TRUE, returns only strings, otherwise returns strings and binary data
 * \param[out] error                 Receives a valid \ref LibHsmError object in case of error
 *
 * \return               \c TRUE on success. \c FALSE if an error occurred. In case of an error, \p error will give details.
 */
BOOL LibHsmConfGetAllNames(ConfigHandle handle, char **name_buffer, unsigned long *name_buffer_length, int *number_of_names, 
	BOOL returnOnlyStrings, LibHsmError **error);

/* mbedTls/Ed25519 */
#define ed25519_public_key_size  32     /**< Constant for Ed25519 public key size */
#define ed25519_secret_key_size  32     /**< Constant for Ed25519 secret key material size */
#define ed25519_private_key_size 64     /**< Constant for Ed25519 private key size */
#define ed25519_signature_size   64     /**< Constant for Ed25519 signature size */

/**
 * \brief                       Generate a Ed25519 public/private key.
 *
 * \param[out] pubKey           Receives the public key [32 bytes]
 * \param[out] privKey          Receives the private key [64 bytes]
 * \param[in] blinding          \c NULL or a blinding context
 * \param[in] sk                A 32 byte secret key
 */
void ed25519_CreateKeyPair(unsigned char *pubKey, unsigned char *privKey, const void *blinding, const unsigned char *sk);

/**
 * \brief                       Sign a message with an Ed25519 key.
 *
 * \param[out] signature        Pointer to a 64-byte buffer to hold the signature (R,S)
 * \param[in] privKey           The private key [64 bytes] (sk,pk)
 * \param[in] blinding          \c NULL or a blinding context
 * \param[in] msg               The message to sign
 * \param[in] msg_size          The size, in bytes, of the message to sign
 */
void ed25519_SignMessage(unsigned char *signature, const unsigned char *privKey, const void *blinding, const unsigned char *msg, size_t msg_size);

/**
 * \brief                       Validate an Ed25519 signature.
 *
 * \param[in] signature         Pointer to a 64-byte buffer with the signature to verify (R,S)
 * \param[in] publicKey         The public key [32 bytes]
 * \param[in] msg               The message to verify
 * \param[in] msg_size          The size, in bytes, of the message to verify
 *
 * \return                      1 if the signature was verified, 0 if not.
 */
int ed25519_VerifySignature(const unsigned char *signature, const unsigned char *publicKey, const unsigned char *msg, size_t msg_size);

/* X509.c */
/**
 * \brief                       Translates an ASN.1 X.509 distinguished name into a string.
 *
 * \param[in] asn1              ASN.1 byte array holding the distinguished name
 * \param[in] len               Length of the \p asn1 byte array
 * \param[out] buffer           Existing buffer that receives the translated string
 * \param[in] buffer_len        The size, in bytes, of the \p buffer
 *
 * \return                      \c TRUE if the name was successfully translated, \c FALSE otherwise.
 */
BOOL LibHsmUtilGetX509Name(unsigned char *asn1, size_t len, char *buffer, size_t buffer_len);

/**
 * \brief                       Creates a SHA-256 hash for a file.
 *
 * \param[in] filename          The name of the file to create the hash for
 * \param[out] error            Receives any error that may have occurred. Can be \c NULL if no error detail is needed
 *
 * \return                      A byte array containing the SHA-256 hash for the file. Must be freed with LibHsmFreeResult(). \c NULL on error.
 */
unsigned char *LibHsmGetFileHash(const char *filename, LibHsmError **error);

/**
 * \brief                       Creates a SHA-256 hash for a file.
 *
 * \param[in] fp                An open FILE * of the file to create the hash for
 * \param[out] error            Receives any error that may have occurred. Can be \c NULL if no error detail is needed
 *
 * \return                      A byte array containing the SHA-256 hash for the file. Must be freed with LibHsmFreeResult(). \c NULL on error.
 */
unsigned char *LibHsmGetFPHash(FILE *fp, LibHsmError **error);

/**
 * \brief                       Checks to see if the LibHsm instance supports the CloudApiKey.
 *
 * \details This function checks an existing LibHsm instance for use. Typically
 * this function is only called if any LibHsm configuration (e.g. Auth or HSM
 * server URL, OAuth token, etc...) was changed.
 *
 * \param[in] handle            The handle of the LibHsm instance to check
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
*/
BOOL
LibHsmSupportsCloudApiKey(LibHsmHandle *handle);

/**
 * \brief                       Checks to see if the LibHsm instance has a CloudApiKey.
 *
 * \details This function checks an existing LibHsm instance for use. Typically
 * this function is only called if any LibHsm configuration (e.g. Auth or HSM
 * server URL, OAuth token, etc...) was changed.
 *
 * \param[in] handle            The handle of the LibHsm instance to check
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
*/
BOOL
LibHsmHasCloudApiKey(LibHsmHandle *handle);

/**
 * \details This function stores a configuration value of type string in the store.
 *
 * \param[in]  handle           A valid \ref ConfigHandle returned by LibHsmConfLoad() or LibHsmConfLoadCreate()
 * \param[in]  name            The name of the store to open.
 * \param[in]  machine		    \c TRUE if the machine configuration should be used. \c FALSE for using user configuration values
 * \param[out] cloud_api_key    Receives a valid Cloud API Key 
 *
 * \return                      \c TRUE if successful, \c FALSE otherwise.
*/
BOOL
LibHsmConfSetCloudApiKey(LibHsmHandle *handle, const char *name, BOOL machine, char *cloud_api_key);

/**
 * \brief                  Un-escapes a JSON string and returns it as a unicode string.
 *
 * \param[in] src          The Utf-8 JSON string to un-escape
 * \param[in] src_len      The length, in bytes of \p src
 * \param[out] dest        Receives pointer to the un-escaped JSON string in unicode
 *
 * \return                 The number of characters of the JSON string.
 */
int JsonUnescapeW(const char *src, int src_len, unicode *dest);

/**
 * \brief                  Un-escapes a JSON string and returns it as a utf-8 string.
 *
 * \param[in] src          The Utf-8 JSON string to un-escape
 * \param[in] src_len      The length, in bytes of \p src
 * \param[out] dest        Receives pointer to the un-escaped JSON string 
 *
 * \return                 The number of characters of the JSON string.
 */
int JsonUnescapeA(const char *src, int src_len, char *dest);

#if defined(UNICODE)
#define JsonUnescape	JsonUnescapeW
#else
#define JsonUnescape	JsonUnescapeA
#endif

#ifdef __cplusplus
}
#endif

/// \}

#endif // LIBHSM_H
