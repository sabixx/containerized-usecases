///
/// Copyright 2019-2021 Venafi, Inc.
/// All Rights Reserved.
/// 
/// This program is unpublished proprietary source code of Venafi, Inc.
/// Your use of this code is limited to those rights granted in the license between you and Venafi.
/// 
/// Author: Peter Dennis Bartok (peter@venafi.com)
/// 
/// \file
/// \brief Definitions for passing parameters to cryptographic functions
/// \addtogroup LibHsm LibHsm Client Library (libhsm)
/// \{
///

#ifndef HSM_CRYPTO_PARAMETER_H
#define HSM_CRYPTO_PARAMETER_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \brief Structure holding an Initialization Vector (IV), for encryption/decryption.
 * \details A \p LibHsmApiCryptoIVParameter provides the Initialization Vector for secret (symmetric) key operations.
 * It is part of the \p LibHsmApiCryptoParameter struct and should not be instantiated directly.
 * To easily set the IV in a \p LibHsmApiCryptoParameter struct, use the \ref SetIVParameter macro.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
 */
typedef struct {
	unsigned char	*IV;			/**< Byte array holding the IV */
	unsigned long	IVLen;			/**< Length of the IV array in bytes */
} LibHsmApiCryptoIVParameter;


// These must match the Pkcs#11 CKG_MGF1_ definitions; they're here 
// with a different name to allow including this header alongside pkcs11.h
#define MGF1_SHA1	0x00000001		/**< SHA1 Mask Generation Function */
#define MGF1_SHA224	0x00000005		/**< SHA2-224 Mask Generation Function */
#define MGF1_SHA256	0x00000002		/**< SHA2-256 Mask Generation Function */
#define MGF1_SHA384	0x00000003		/**< SHA2-384 Mask Generation Function */
#define MGF1_SHA512	0x00000004		/**< SHA2-512 Mask Generation Function */

#define SOURCE_NONE				0x00000000	/**< No Source data */
#define SOURCE_DATA_SPECIFIED	0x00000001	/**< Source data specified */

/**
 * \brief Structure holding OAEP parameters, for encryption/decryption.
 * \details A \p LibHsmApiCryptoOAEPParameter provides the values for using optimal asymmetric encryption padding (OAEP).
 * OAEP can be used for increased safety when performing encryption/decryption with the \c RSA algorithm.
 * It is part of the \p LibHsmApiCryptoParameter struct and should not be instantiated directly.
 * To easily set the OAEP values in a \p LibHsmApiCryptoParameter struct, use the \ref SetOAEPParameter macro.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
 */
typedef struct {
	unsigned long	HashAlg;		/**< PKCS#11 \c CKM_ Mechanism type indicating the hash algorithm used to calculate the digest of the encoding parameter */
	unsigned long	MGF;			/**< Mask Generation Function to use on the encoded block(see \c MGF1_ defines) */
	unsigned long	Source;			/**< Indicates if source of the encoding parameter is specified (\c SOURCE_DATA_SPECIFIED) or none (\c SOURCE_NONE) */
	unsigned char	*SourceData;	/**< Data used as the input for the encoding parameter source (if Source is \c SOURCE_DATA_SPECIFIED), or \c NULL (if \c SourceData is \c SOURCE_NONE)*/
	unsigned long	SourceDataLen;	/**< The length of SourceData, in bytes, or \c 0 if \c SourceData is \c SOURCE_NONE */
} LibHsmApiCryptoOAEPParameter;

/**
 * \brief Structure holding PSS parameter, for signing/verification.
 * \details A \p LibHsmApiCryptoPKCSPSSParameter provides the values for using the probabilistic signature scheme (PSS).
 * PSS can be used for increased safety when performing signing/verification with the \c RSA algorithm.
 * It is part of the \p LibHsmApiCryptoParameter struct and should not be instantiated directly.
 * To easily set the PSS values in a \p LibHsmApiCryptoParameter struct, use the \ref SetPKCSPSSParameter macro.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
 */
typedef struct {
	unsigned long	HashAlg;		/**< PKCS#11 \c CKM_ Mechanism type indicating the hash algorithm. If the signature mechanism does not include message hashing, then this value must be the mechanism used by the application to generate the message hash; if the signature mechanism includes hashing, then this value must match the hash algorithm indicated by the signature mechanism */
	unsigned long	MGF;			/**< Mask Generation Function to use on the encoded block (see \c MGF1_ defines) */
	unsigned long	SaltLen;		/**< Length, in bytes, of the salt value used in the PSS encoding; typical values are the length of the message hash and zero */
} LibHsmApiCryptoPKCSPSSParameter;

/**
 * \brief Structure holding Microsoft-Style EC key derivation parameter.
 * \details A \p LibHsmApiCryptoMSHashECDHParameter provides the values for performing Microsoft-style EC key derivation.
 * Microsoft-style EC key derivation automatically hashes the derived key material, unlike regular PKCS#11 EC key derivation.
 * It is part of the \p LibHsmApiCryptoParameter struct and should not be instantiated directly.
 * To easily set the values in a \p LibHsmApiCryptoParameter struct, use the \ref SetMSHashECDHParameter macro.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
 */
typedef struct {
	unsigned long	HashAlg;		/**< PKCS#11 \c CKM_ Mechanism type indicating the hash algorithm to use for derivation. */
	unsigned char	*Prepend;		/**< The bytes to prepend when generating the key */
	unsigned long	PrependLen;		/**< Length, in bytes, of the Prepend data */
	unsigned char	*Append;		/**< The bytes to append when generating the key */
	unsigned long	AppendLen;		/**< Length, in bytes, of the Append data */
	unsigned char	*PublicData;	/**< The EC public key material */
	unsigned long	PublicDataLen;	/**< Length, in bytes, of the EC key material */
} LibHsmApiCryptoMSHashECDHParameter;

/**
 * \brief Structure holding Microsoft-Style HMAC EC key derivation parameter.
 * \details A \p LibHsmApiCryptoMSHmacECDHParameter provides the values for performing Microsoft-style EC key derivation.
 * Microsoft-style EC key derivation automatically hashes the derived key material, unlike regular PKCS#11 EC key derivation.
 * It is part of the \p LibHsmApiCryptoParameter struct and should not be instantiated directly.
 * To easily set the values in a \p LibHsmApiCryptoParameter struct, use the \ref SetMSHmacECDHParameter macro.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
 */
typedef struct {
	unsigned long	HashAlg;		/**< PKCS#11 \c CKM_ Mechanism type indicating the hash algorithm to use for derivation. */
	unsigned char	*HMacKey;		/**< The HMac Key material, or \c NULL */
	unsigned long	HMacKeyLen;		/**< Length, in bytes, of the HMacKey data */
	unsigned char	*Prepend;		/**< The bytes to prepend when generating the key */
	unsigned long	PrependLen;		/**< Length, in bytes, of the Prepend data */
	unsigned char	*Append;		/**< The bytes to append when generating the key */
	unsigned long	AppendLen;		/**< Length, in bytes, of the Append data */
	unsigned char	*PublicData;	/**< The EC public key material */
	unsigned long	PublicDataLen;	/**< Length, in bytes, of the EC key material */
} LibHsmApiCryptoMSHmacECDHParameter;

/**
 * \brief Structure holding EC key derivation parameter.
 * \details A \p LibHsmApiCryptoECDH1Parameter provides the values for performing EC key derivation.
 * It is part of the \p LibHsmApiCryptoParameter struct and should not be instantiated directly.
 * To easily set the values in a \p LibHsmApiCryptoParameter struct, use the \ref SetECDH1Parameter macro.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
 */
typedef struct {
	unsigned long	Kdf;			/**< PKCS#11 \c CKM_ Mechanism type indicating the hash algorithm. If the signature mechanism does not include message hashing, then this value must be the mechanism used by the application to generate the message hash; if the signature mechanism includes hashing, then this value must match the hash algorithm indicated by the signature mechanism */
	unsigned char	*SharedData;	/**< The data shared between two parties */
	unsigned long	SharedDataLen;	/**< Length, in bytes, of the shared data */
	unsigned char	*PublicData;	/**< The EC public key material (encoded as DER raw octet string) */
	unsigned long	PublicDataLen;	/**< Length, in bytes, of the public key data */
} LibHsmApiCryptoECDH1Parameter;

/**
 * \brief Structure holding all supported crypto parameters.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
 */
typedef struct {
	char *parameter_type;			/**< The parameter type to use; must be one of \c "IV", \c "OAEP", \c "PKCSPSS", \c "MSHASHECDH", \c "MSHMACECDH" or \c "ECDH1" */
	union {
		LibHsmApiCryptoIVParameter			IV;				/**< \c IV parameters */
		LibHsmApiCryptoOAEPParameter		OAEP;			/**< \c OAEP parameters */
		LibHsmApiCryptoPKCSPSSParameter		PKCSPSS;		/**< \c PKCSPSS parameters */
		LibHsmApiCryptoMSHashECDHParameter	MSHashECDH;		/**< \c MS Hash ECDH parameters */
		LibHsmApiCryptoMSHmacECDHParameter	MSHmacECDH;		/**< \c MS Hmac ECDH parameters */
		LibHsmApiCryptoECDH1Parameter		ECDH1;			/**< \c ECDH1 parameters */
	};
} LibHsmApiCryptoParameter;

/**
 * \def SetIVParameter
 * \brief Convenience macro to easily set the IV parameters in a \p LibHsmApiCryptoParameter structure.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
 */
#define SetIVParameter(parameter, iv, len)	(parameter)->parameter_type = "IV";		\
											(parameter)->IV.IV = iv;				\
											(parameter)->IV.IVLen = len;

/**
* \def SetOAEPParameter
* \brief Convenience macro to easily set the OAEP parameters in a \p LibHsmApiCryptoParameter structure.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
*/
#define SetOAEPParameter(parameter, hashalg, mgf, source_data, source_len)	(parameter)->parameter_type = "OAEP";	\
											(parameter)->OAEP.HashAlg = hashalg;					\
											(parameter)->OAEP.MGF = mgf;							\
											if (source_data != NULL) {								\
												(parameter)->OAEP.Source = SOURCE_DATA_SPECIFIED;	\
												(parameter)->OAEP.SourceData = source_data;			\
												(parameter)->OAEP.SourceDataLen = source_len;		\
											} else {												\
												(parameter)->OAEP.Source = SOURCE_DATA_SPECIFIED;	\
												(parameter)->OAEP.SourceData = NULL;				\
												(parameter)->OAEP.SourceDataLen = 0;				\
											}

/**
* \def SetPKCSPSSParameter
* \brief Convenience macro to easily set the PSS parameters in a \p LibHsmApiCryptoParameter structure.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
*/
#define SetPKCSPSSParameter(parameter, hashalg, mgf, salt_len)	(parameter)->parameter_type = "PKCSPSS";	\
											(parameter)->PKCSPSS.HashAlg = hashalg;			\
											(parameter)->PKCSPSS.MGF = mgf;					\
											(parameter)->PKCSPSS.SaltLen = salt_len;

/**
* \def SetMSHashECDHParameter
* \brief Convenience macro to easily set the Microsoft Hash EC key derivation parameters in a \p LibHsmApiCryptoParameter structure.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
*/
#define SetMSHashECDHParameter(parameter, hashalg, prepend, prepend_len, append, append_len, public_data, public_data_len)	(parameter)->parameter_type = "MSHASHECDH";	\
											(parameter)->MSHashECDH.HashAlg = hashalg;				\
											(parameter)->MSHashECDH.Prepend = prepend;				\
											(parameter)->MSHashECDH.PrependLen = prepend_len;		\
											(parameter)->MSHashECDH.Append = append;				\
											(parameter)->MSHashECDH.AppendLen = append_len;			\
											(parameter)->MSHashECDH.PublicData = public_data;		\
											(parameter)->MSHashECDH.PublicDataLen = public_data_len;

/**
* \def SetMSHmacECDHParameter
* \brief Convenience macro to easily set the Microsoft HMAC EC key derivation parameters in a \p LibHsmApiCryptoParameter structure.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
*/
#define SetMSHmacECDHParameter(parameter, hashalg, hmac_key, hmac_key_len, prepend, prepend_len, append, append_len, public_data, public_data_len)	(parameter)->parameter_type = "MSHMACECDH";	\
											(parameter)->MSHmacECDH.HashAlg = hashalg;				\
											(parameter)->MSHmacECDH.HMacKey = hmac_key;				\
											(parameter)->MSHmacECDH.HMacKeyLen = hmac_key_len;		\
											(parameter)->MSHmacECDH.Prepend = prepend;				\
											(parameter)->MSHmacECDH.PrependLen = prepend_len;		\
											(parameter)->MSHmacECDH.Append = append;				\
											(parameter)->MSHmacECDH.AppendLen = append_len;			\
											(parameter)->MSHmacECDH.PublicData = public_data;		\
											(parameter)->MSHmacECDH.PublicDataLen = public_data_len;

/**
* \def SetECDH1Parameter
* \brief Convenience macro to easily set the PKCS#11 EC key derivation parameters in a \p LibHsmApiCryptoParameter structure.
 *
 * \headerfile HsmCryptoParameter.h <venafi/hsm/HsmCryptoParameter.h>
*/
#define SetECDH1Parameter(parameter, kdf, shared_data, shared_data_len, public_data, public_data_len)	(parameter)->parameter_type = "ECDH1";	\
											(parameter)->ECDH1.Kdf = hashalg;						\
											(parameter)->ECDH1.SharedData = shared_data;			\
											(parameter)->ECDH1.SharedDataLen = shared_data_len;		\
											(parameter)->ECDH1.PublicData = public_data;			\
											(parameter)->ECDH1.PublicDataLen = public_data_len;


#ifdef __cplusplus
}
#endif

/// \}

#endif /* HSM_CRYPTO_PARAMETER_H */
