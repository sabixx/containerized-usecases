//
// Copyright 2019-2023 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// Author: Micah N Gorrell (micah.gorrell@venafi.com)
// 

#ifndef _LIBHSM_CONSTANTS
#define _LIBHSM_CONSTANTS

#define CONFIGURATION_AUTH_SERVER_URL		"Auth Server Url"
#define CONFIGURATION_HSM_SERVER_URL		"Hsm Server Url"
#define CONFIGURATION_TIMESTAMP_SERVER_URL	"Timestamp Server Url"
#define CONFIGURATION_PKS_SERVER_URL		"Pks Server Url"
#define CONFIGURATION_CSC_SERVER_URL		"CSC Server Url"

#define CONFIGURATION_ACCESS_TOKEN			"Access Token"
#define CONFIGURATION_REFRESH_TOKEN			"Refresh Token"
#define CONFIGURATION_ACCESS_EXPIRES		"Access Expires"
#define CONFIGURATION_NETWORK_TIMEOUT		"Network Timeout"
#define CONFIGURATION_NETWORK_TIMEOUT2		"First Error Timeout"
#define CONFIGURATION_NETWORK_TIMEOUT3		"Multiple Error Timeout"
#define CONFIGURATION_GRANTEE				"Grantee"
#define CONFIGURATION_CA_TRUST				"CA Trust"
#define CONFIGURATION_CHAIN_VALIDATION		"Chain Validation"
#define CONFIGURATION_PROXY_URL				"Proxy Url"
#define CONFIGURATION_PROXY_MODE			"Proxy Mode"
#define CONFIGURATION_PROXY_BYPASS_HOSTS	"Proxy Bypass Hosts"
#define CONFIGURATION_LABEL_FILTER          "Label Filter"
#define CONFIGURATION_UNSAFE_OPTION_STORAGE	"Use Unsafe Option Storage"
#define CONFIGURATION_SYNC_KEEP_ITEMS		"Sync Keep Items"
#define CONFIGURATION_CLOUD_API_KEY         "API Key"  // this is the cloud api key

#define CONFIGURATION_PQ_ENABLED			"Enable PQ Experimental"


#define OAUTH_CLIENT_ID						"VenafiCodeSignClient"
#define OAUTH_HSM_SCOPE						"codesignclient"
#define DEFAULT_MACHINE_CA_TRUST			"/etc/venafi/trust"
#define DEFAULT_USER_CA_TRUST				".libhsmtrust"


#endif /* _LIBHSM_CONSTANTS */
