///
/// Copyright 2020 Venafi, Inc.
/// All Rights Reserved.
/// 
/// This program is unpublished proprietary source code of Venafi, Inc.
/// Your use of this code is limited to those rights granted in the license between you and Venafi.
/// 
/// Author: Peter Dennis Bartok (peter@venafi.com)
/// 
///
/// \file
/// \brief LibHsm errors enumeration
/// \addtogroup LibHsm LibHsm Client Library (libhsm)
/// \{
///

#ifndef HSM_ERRORS_H
#define HSM_ERRORS_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \brief Error code enumeration of all \c libhsm errors.
 *
 * \headerfile HsmErrors.h <venafi/hsm/HsmErrors.h>
 */
typedef enum {
    LibHsmErr_Success               = 0,    /**< Operation completed successfully */
    LibHsmErr_OutOfMemory           = 1,    /**< The operation failed to allocate required memory */
    LibHsmErr_LibraryInitFailed     = 2,    /**< Failed to initialize LibHsm */
    LibHsmErr_ArgumentNull          = 3,    /**< A reqired argument was NULL */
    LibHsmErr_ArgumentLen           = 4,    /**< A reqired argument length was 0 */
    LibHsmErr_ArgumentInvalid       = 5,    /**< A reqired argument or argument combination was not provided */
    LibHsmErr_CryptoError           = 6,    /**< A cryptographic function failed */
    LibHsmErr_InvalidData           = 7,    /**< An argument contained invalid data */
    LibHsmErr_SyscallFailed         = 8,    /**< The function failed due to an underlying OS/Library call failure */
    LibHsmErr_InvalidLibHsmHandle   = 9,    /**< The LibHsmHandle was not a valid handle */
    LibHsmErr_NameNotFound          = 10,   /**< The requested name was not found */
    LibHsmErr_BufferTooSmall        = 11,   /**< The provided buffer was not big enough to hold all data */
    LibHsmErr_RestApiError          = 12,   /**< A REST call was successful, but returned an error */
    LibHsmErr_HttpError             = 13,   /**< A REST call failed */
    LibHsmErr_NotImplemented        = 14,   /**< The called method is not implemented */
    LibHsmErr_InvalidKeyId          = 15,   /**< The object specified by the provided KeyId does not exist */
    LibHsmErr_GrantExpired          = 16,   /**< An OAuth grant expired and cannot be refreshed */
    LibHsmErr_MissingAccessToken    = 17,   /**< No OAuth access token exists */
    LibHsmErr_MissingRefreshToken   = 18,   /**< No OAuth refresh token exists */
    LibHsmErr_HsmObjectWrongType    = 19,   /**< The provided HsmObject argument is not of the expected type */
    LibHsmErr_UnsupportedKeyType    = 20,   /**< The provided key HsmObject type is not supported */
    LibHsmErr_UnsupportedMechanism  = 21,   /**< The provided mechanism is not supported */
    LibHsmErr_InvalidSignature      = 22,   /**< The signature did not match what was expected */
    LibHsmErr_MutexLockError        = 23,   /**< Failed to obtain a mutex lock */
    LibHsmErr_FileOpenFailed        = 24,   /**< Failed to open a file */
    LibHsmErr_FileCreateFailed      = 25,   /**< Failed to create a file */
    LibHsmErr_FileReadFailed        = 26,   /**< Failed to read from a file */
    LibHsmErr_FileWriteFailed       = 27,   /**< Failed to write to a file */
    LibHsmErr_ConfigLoadFailed      = 28,   /**< Failed to load configuration */
    LibHsmErr_ConfigWriteFailed     = 29,   /**< Failed to write configuration */
    LibHsmErr_WrongObjectType       = 30,   /**< The object provided was the type */
    LibHsmErr_WrongKeyType          = 31,   /**< The key object provided was the wrong type */
    LibHsmErr_VedHsmErrorMessage    = 32,   /**< An error message that was returned from a successful REST call */
    LibHsmErr_VedHsmInvalidHashLen  = 33,   /**< A provided hash does not have the right length for the chosen digest */
    LibHsmErr_VedHsmTryLater        = 34,   /**< Indicates that the server accepted the request but cannot complete it until later (e.g. after an approval has been issued). When retrying, *all* parameters and values must be the same or it is considered a new request */
    LibHsmErr_UnknownParameterType  = 35,   /**< The \ref LibHsmApiCryptoParameter has an unknown or invalid type  */
} LibHsmErrorStatus;

/**
 * \brief Error element.
 * \details LibHsm errors are represented as a list of \p LibHsmError elements. The list starts with the error closest to the 
 * called function. Multiple error elements are collected since a low-level error in, for example, a REST call might
 * not provide enough context to understand what failed, only why it failed. Higher-level functions can add error
 * elements that explain the context.
 *
 * \headerfile HsmErrors.h <venafi/hsm/HsmErrors.h>
 */
typedef struct _LibHsmError {
    LibHsmErrorStatus status;               /**< The \p LibHsmErrorStatus for this error element */
    char *error;                            /**< A textual explanation of the error */
    char *context;
#if defined(_DEBUG)
    const char *source_file;
    int source_line;
#endif
    struct _LibHsmError *next;              /**< Link to the next error element */
    struct _LibHsmError *prev;              /**< Link to the previous error element */
} LibHsmError;

#ifdef __cplusplus
}
#endif

/// \}

#endif /* HSM_ERRORS_H */