///
/// Copyright 2019-2020 Venafi, Inc.
/// All Rights Reserved.
/// 
/// This program is unpublished proprietary source code of Venafi, Inc.
/// Your use of this code is limited to those rights granted in the license between you and Venafi.
/// 
/// \author Peter Dennis Bartok (peter@venafi.com)
/// 
///
/// \file HsmObjects.h
/// \brief Provides definitions for all objects the LibHsm user has access to.
/// \addtogroup LibHsm LibHsm Client Library (libhsm)
/// \{
///

#ifndef HSMOBJECTS_H
#define HSMOBJECTS_H

#ifdef __cplusplus
extern "C" {
#endif

#if !defined(WIN32)
typedef void *PCCERT_CONTEXT;
#endif

/**
 * \brief An enumeration of all Venafi HSM Environment types.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef enum {
	HsmEnvCertificate = 0,	/**< Certificate environment; single certificate and keypair */
	HsmEnvGPG= 1,			/**< GPG environment; three keypairs (sign, encrypt, auth), certificates optional */
	HsmEnvDotNet= 2,		/**< .Net Strongname environment; no certificate; RSA only*/
	HsmEnvCSP= 3,			/**< CSP environment; two keypairs (sign and encrypt), certificates optional */
	HsmEnvKeyPair= 4,		/**< Keypair environment; single keypair; no certificate; generic use */
	HsmEnvSecretKey= 5,		/**< Key environment; single symmetric key; no certificate; generic use */
	HsmEnvApple= 6,			/**< Apple environment; single certificate and keypair */
} HsmEnvironmentType;

/**
 * \brief An enumeration of all supported Hsm object types.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef enum {
	CryptokiData = 0,				/**< Data */
	CryptokiCertificate = 1,		/**< X.509 Certificate */
	CryptokiPublicKey = 2,			/**< Public Key */
	CryptokiPrivateKey = 3,			/**< Private Key */
	CryptokiSecretKey = 4,			/**< Symmetric Key */
	CryptokiHwFeature = 5,			/**< Hardware Feature; unsupported */
	CryptokiDomainParameters = 6,	/**< Domain Parameters; unsupported */
	CryptokiMechanismType = 7,		/**< Mechanism; unsupported */
	CryptokiOtpKey = 8				/**< One-Time Password; Unsupported */
} CryptokiObjectType;

/**
 * \brief An enumeration of all supported Hsm object types.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef enum {
	CryptokiMechanismRsaPkcs		= 0x00000001UL,		/**< RSA */
	CryptokiMechanismRsaPkcsOaep	= 0x00000009UL,		/**< RSA OAEP */
	CryptokiMechanismRsaPkcsPss		= 0x0000000DUL,		/**< RSA PSS */

	CryptokiMechanismDsa			= 0x00000011UL,		/**< DSA */

	CryptokiMechanismRsaMd5			= 0x00000005UL,		/**< RSA MD-5 */

	CryptokiMechanismRsaSha1		= 0x00000006UL,		/**< RSA SHA-1 */
	CryptokiMechanismRsaSha224		= 0x00000046UL,		/**< RSA SHA-224 */
	CryptokiMechanismRsaSha256		= 0x00000040UL,		/**< RSA SHA-256 */
	CryptokiMechanismRsaSha384		= 0x00000041UL,		/**< RSA SHA-384 */
	CryptokiMechanismRsaSha512		= 0x00000042UL,		/**< RSA SHA-512 */
	CryptokiMechanismRsaPssSha1		= 0x0000000EUL,		/**< RSA PSS SHA-1 */
	CryptokiMechanismRsaPssSha224	= 0x00000047UL,		/**< RSA PSS SHA-224 */
	CryptokiMechanismRsaPssSha256	= 0x00000043UL,		/**< RSA PSS SHA-256 */
	CryptokiMechanismRsaPssSha384	= 0x00000044UL,		/**< RSA PSS SHA-384 */
	CryptokiMechanismRsaPssSha512	= 0x00000045UL,		/**< RSA PSS SHA-512 */

	CryptokiMechanismEcDsa			= 0x00001041UL,		/**< EcDSA Elliptic Curve */
	CryptokiMechanismEcDsaSha1		= 0x00001042UL,		/**< EcDSA SHA-1 */
	CryptokiMechanismEcDsaSha224	= 0x00001043UL,		/**< EcDSA SHA-224 */
	CryptokiMechanismEcDsaSha256	= 0x00001044UL,		/**< EcDSA SHA-256 */
	CryptokiMechanismEcDsaSha384	= 0x00001045UL,		/**< EcDSA SHA-384 */
	CryptokiMechanismEcDsaSha512	= 0x00001046UL,		/**< EcDSA SHA-512 */

	CryptokiMechanismEdDsa			= 0x00001057UL,		/**< EdDSA Edwards */

	CryptokiMechanismMd5			= 0x00000210UL,		/**< MD-5 */

	CryptokiMechanismSha1			= 0x00000220UL,		/**< SHA-1 */
	CryptokiMechanismSha224			= 0x00000255UL,		/**< SHA-224 */
	CryptokiMechanismSha256			= 0x00000250UL,		/**< SHA-256 */
	CryptokiMechanismSha384			= 0x00000260UL,		/**< SHA-384 */
	CryptokiMechanismSha512			= 0x00000270UL,		/**< SHA-512 */

	CryptokiMechanismECDH1Derive	= 0x00001050UL,		/**< ECDH1_Derive */

	CryptokiVenafiMicrosoftHashECDHDerive
									= 0x80001050,		/**< EC Derivation following Microsoft NCrypt model where the key material is automatically hashed */
	CryptokiVenafiMicrosoftHMACECDHDerive
									= 0x80001051,		/**< EC Derivation following Microsoft NCrypt model where the key material is automatically hashed; HMAC version */

	// Post Quantum
	CryptokiMechanismMlDsaKeyPairGen	= 0x80000001, /** ML-DSA (Dilithium) Key Pair Generation, 2147483649u */
	CryptokiMechanismMlDsa				= 0x80000002, /** ML-DSA, 2147483650u */
	CryptokiMechanismSlhDsaKeyParGen	= 0x80000003, /** SLH - DSA(Sphincs + ), Key Pair Generation, 2147483651u */
	CryptokiMechanismSlhDsa				= 0x80000004, /** SLH - DSA(Sphincs + ), 2147483652u */
	CryptokiMechanismFalconKeyPairGen 	= 0x80000005, /** Falcon Key Pair Generation, 2147483653u */
	CryptokiMechanismFalcon				= 0x80000006, /** Falcon, 2147483654u */

	//     No matching mechanism defined
	CryptokiMechanismUndefined		= 0x07ffffff, /** 134217727u */
} CryptokiMechanism;

/**
 * \brief An enumeration of all supported Hsm object types
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef enum {
	CryptokiKeyRSA              =  0x00000000UL,	/**< RSA */
	CryptokiKeyDSA              =  0x00000001UL,	/**< DSA */
	CryptokiKeyDH               =  0x00000002UL,	/**< Diffie-Hellman */
	CryptokiKeyEC               =  0x00000003UL,	/**< Elliptic Curve */
	CryptokiKeyX9_42_DH         =  0x00000004UL,	/**< X9.42 Diffie Hellman */
	CryptokiKeyKEA              =  0x00000005UL,	/**< KEA */
	CryptokiKeyGENERIC_SECRET   =  0x00000010UL,	/**< Generic Symmetric key */
	CryptokiKeyRC2              =  0x00000011UL,	/**< RC2 */
	CryptokiKeyRC4              =  0x00000012UL,	/**< RC4 */
	CryptokiKeyDES              =  0x00000013UL,	/**< DES */
	CryptokiKeyDES2             =  0x00000014UL,	/**< DES2 */
	CryptokiKeyDES3             =  0x00000015UL,	/**< Triple-DES */
	CryptokiKeyRC5              =  0x00000019UL,	/**< RC5 */
	CryptokiKeyAES              =  0x0000001FUL,	/**< AES */
	CryptokiKeyBLOWFISH         =  0x00000020UL,	/**< Blowfish */
	CryptokiKeyTWOFISH          =  0x00000021UL,	/**< Twofish */
	CryptokiKeySECURID          =  0x00000022UL,	/**< RSA SecurID */
	CryptokiKeyMD5_HMAC         =  0x00000027UL,	/**< MD5 HMAC */
	CryptokiKeySHA_1_HMAC       =  0x00000028UL,	/**< SHA-1 HMAC */
	CryptokiKeyRIPEMD128_HMAC   =  0x00000029UL,	/**< RIPE-MD128 HMAC */
	CryptokiKeyRIPEMD160_HMAC   =  0x0000002AUL,	/**< RIPE-MD160 HMAC */
	CryptokiKeySHA256_HMAC      =  0x0000002BUL,	/**< SHA-256 HMAC */
	CryptokiKeySHA384_HMAC      =  0x0000002CUL,	/**< SHA-384 HMAC */
	CryptokiKeySHA512_HMAC      =  0x0000002DUL,	/**< SHA-512 HMAC */
	CryptokiKeySHA224_HMAC      =  0x0000002EUL,	/**< SHA-224 HMAC */
	CryptokiKeySEED             =  0x0000002FUL,	/**< SEED */
	CryptokiKeyGOSTR3410        =  0x00000030UL,	/**< GOST R3410 */
	CryptokiKeyGOSTR3411        =  0x00000031UL,	/**< GOST R3411 */
	CryptokiKeyGOST28147        =  0x00000032UL,	/**< GOST 28147 */
	CryptokiKeyCHACHA20         =  0x00000033UL,	/**< ChaCha20 */
	CryptokiKeyPOLY1305         =  0x00000034UL,	/**< Poly1305 */
	CryptokiKeyAES_XTS          =  0x00000035UL,	/**< AES XTS*/
	CryptokiKeySHA3_224_HMAC    =  0x00000036UL,	/**< SHA3-224 HMAC */
	CryptokiKeySHA3_256_HMAC    =  0x00000037UL,	/**< SHA3-256 HMAC  */
	CryptokiKeySHA3_384_HMAC    =  0x00000038UL,	/**< SHA3-384 HMAC  */
	CryptokiKeySHA3_512_HMAC    =  0x00000039UL,	/**< SHA3-512 HMAC  */
	CryptokiKeyBLAKE2B_160_HMAC =  0x0000003aUL,	/**< Blake2B-160 HMAC  */
	CryptokiKeyBLAKE2B_256_HMAC =  0x0000003bUL,	/**< Blake2B-256 HMAC */
	CryptokiKeyBLAKE2B_384_HMAC =  0x0000003cUL,	/**< Blake2B-384 HMAC */
	CryptokiKeyBLAKE2B_512_HMAC =  0x0000003dUL,	/**< Blake2B-512 HMAC */
	CryptokiKeySALSA20          =  0x0000003eUL,	/**< Salsa20 */
	CryptokiKeyX2RATCHET        =  0x0000003fUL,	/**< X2 Ratchet */
	CryptokiKeyEC_EDWARDS       =  0x00000040UL,	/**< EdDSA */
	CryptokiKeyEC_MONTGOMERY    =  0x00000041UL,	/**< Curve25519 */
	CryptokiKeyHKDF             =  0x00000042UL, 	/**< HKDF */

	// Post Quantum
	CryptokiKeyMlDsa			=  0x00000050UL,	/**< MlDsa (Dilithium) */
	CryptokiKeySlhDsa 			=  0x00000051UL,	/**< SlhDsa (Sphincs+) */
	CryptokiKeyFalcon 			=  0x00000052UL,	/**< Falcon */

	VendorDefined 				=  0x80000000UL
} CryptokiKeyType;

/**
 * \brief An enumeration of all supported ParameterSet for PostQuantum
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef enum {
	//     Dilithium2
	ML_DSA_44 = 1u,
	//     Dilithium3
	ML_DSA_65 = 2u,
	//     Dilithium5
	ML_DSA_87 = 3u,

	//     Sphincs+ SHA2 128bit Small
	SLH_DSA_SHA2_128S = 4u,
	//     Sphincs+ SHAKE 128bit Small
	SLH_DSA_SHAKE_128S = 5u,
	//     Sphincs+ SHA2 128bit Fast
	SLH_DSA_SHA2_128F = 6u,
	//     Sphincs+ SHAKE 128bit Fast
	SLH_DSA_SHAKE_128F = 7u,
	//     Sphincs+ SHA2 192bit Small
	SLH_DSA_SHA2_192S = 8u,
	//     Sphincs+ SHAKE 192bit Small
	SLH_DSA_SHAKE_192S = 9u,
	//     Sphincs+ SHA2 192bit Fast
	SLH_DSA_SHA2_192F = 10u,
	//     Sphincs+ SHAKE 192bit Fast
	SLH_DSA_SHAKE_192F = 11u,
	//     Sphincs+ SHA2 256bit Small
	SLH_DSA_SHA2_256S = 12u,
	//     Sphincs+ SHAKE 256bit Small
	SLH_DSA_SHAKE_256S = 13u,
	//     Sphincs+ SHA2 256bit Fast
	SLH_DSA_SHA2_256F = 14u,
	//     Sphincs+ SHAKE 256bit Fast
	SLH_DSA_SHAKE_256F = 15u,

	//     Falcon512
	FALCON512_ROUND3 = 16u,
	//     Falcon1024
	FALCON1024_ROUND3 = 17u,

	PQVendorDefined = 0x80000000,
} CryptokiParameterType;

/**
 * \struct HsmDataObject
 *
 * \brief Data object to hold arbitrary application data.
 *
 * \details The \p HsmDataObject can be used by applications to store arbitrary data. Currently unsupported.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef struct _HsmDataObject {
	unsigned char		*Application;			/**< Name of the application that understands this data object */
	unsigned char		*ApplicationData;		/**< Binary application data */
	unsigned long		ApplicationDataLen;		/**< The length, in bytes, of the application data array */
} HsmDataObject;

/**
 * \struct HsmCertificateObject
 *
 * \brief X.509 Certificate object.
 *
 * \details The \p HsmCertificateObject holds certificate specific data.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef struct _HsmCertificateObject {
	BOOL				CACert;					/**< Indicates if the certificate is a CA certificate (Intermediate or Root) */
	BOOL				Trusted;				/**< Indicates if the certificate is trusted */
	unsigned char		*Value;					/**< The raw DER certificate */
	unsigned long		ValueLen;				/**< Length, in bytes, of \p Value */
	unsigned char		*CheckValue;			/**< The PKCS#11 Check value for the certificate */
	unsigned long		CheckValueLen;			/**< The length, in bytes, of \p CheckValue  */
	unsigned char		*StartDate;				/**< The certificate validity start date (in format YYYYMMDD) */
	unsigned char		*EndDate;				/**< The certificate expiration date (in format YYYYMMDD) */
	unsigned char		*Subject;				/**< The subject of the certificate, in DER (ASN.1) format */
	unsigned long		SubjectLen;				/**< The length, in bytes, of \p Subject */
	unsigned char		*Issuer;				/**< The issuer of the certificate, in DER (ASN.1) format */
	unsigned long		IssuerLen;				/**< The length, in bytes, of \p Issuer */
	struct _HsmObject	*Intermediates;			/**< Intermediate certificates that should be synchronized into the consumer's certificate store */
	struct _HsmObject	*Root;					/**< Root certificate that should be synchronized into the consumer's certificate store */
	PCCERT_CONTEXT		WinCertContext;			/**< A Windows PCCERT_CONTEXT for the certificate. Only generated on demand by calling LibHsmLoadWinCertificateHandle(). Always \c NULL for non-Windows systems */
	unsigned char       *TargetStore;
} HsmCertificateObject;

/**
 * \struct HsmSecretKeyObject
 *
 * \brief Secret (symmetric) key object.
 *
 * \details The \p HsmSecretKeyObject describes a symmetric key.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef struct _HsmSecretKeyObject {
	/* All Key objects*/
	CryptokiKeyType		KeyType;				/**< The \p KeyType of this secret (symmetric) key */
	BOOL				Derive;
	BOOL				Local;

	/* Secret specific */
	BOOL				Sensitive;
	BOOL				Encrypt;				/**< \c TRUE if the key can be used for encryption */
	BOOL				Decrypt;				/**< \c TRUE if the key can be used for decryption */
	BOOL				Sign;					/**< \c TRUE if the key can be used for signing */
	BOOL				Verify;					/**< \c TRUE if the key can be used for verification */
	BOOL				Wrap;					/**< \c TRUE if the key can be used for key wrapping */
	BOOL				Unwrap;					/**< \c TRUE if the key can be used for key unwrapping */
	BOOL				Extractable;
	BOOL				AlwaysSensitive;
	BOOL				NeverExtractable;
	BOOL				WrapWithTrusted;
} HsmSecretKeyObject;

/**
 * \struct HsmPrivateKeyObject
 *
 * \brief Private key object.
 *
 * \details The \p HsmPrivateKeyObject describes the private part of a public/private key pair.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef struct _HsmPrivateKeyObject {
	/* All Key objects*/
	CryptokiKeyType		KeyType;				/**< The \p KeyType of this private key */
	BOOL				Derive;
	BOOL				Local;

	/* Private Key specific */
	BOOL				Sensitive;				
	BOOL				Decrypt;				/**< \c TRUE if the key can be used for decryption */
	BOOL				Sign;					/**< \c TRUE if the key can be used for signing */
	BOOL				SignRecover;
	BOOL				Unwrap;
	BOOL				Extractable;
	BOOL				AlwaysSensitive;
	BOOL				NeverExtractable;

	/* RSA */
	int					Bits;					/**< \c For \p KeyType ::CryptokiKeyRSA, indicates the size of the key, in bits */
	unsigned char		*Modulus; 				/**< \c For \p KeyType ::CryptokiKeyRSA, the modulus */
	int					ModulusLen;				/**< \c For \p KeyType ::CryptokiKeyRSA, the length of the \p Modulus byte array */
	unsigned char		*Exponent;				/**< \c For \p KeyType ::CryptokiKeyRSA, the exponent */
	int					ExponentLen;			/**< \c For \p KeyType ::CryptokiKeyRSA, the length of the \p Exponent byte array */

	/* EC */
	char				*Curve;					/**< \c For \p KeyType ::CryptokiKeyEC and ::CryptokiKeyEC_EDWARDS, the name of the curve (P256, P384, P521, 25519, 448) */
	unsigned char		*Params;				/**< \c For \p KeyType ::CryptokiKeyEC and ::CryptokiKeyEC_EDWARDS, the curve parameters */
	unsigned long		ParamsLen;				/**< \c For \p KeyType ::CryptokiKeyEC and ::CryptokiKeyEC_EDWARDS, the length of the \p Params byte array */

	/* PQ */
	unsigned long		ParameterSet;
} HsmPrivateKeyObject;

/**
 * \struct HsmPublicKeyObject
 *
 * \brief Public key object.
 *
 * \details The \p HsmPublicKeyObject describes the public part of a public/private key pair.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef struct _HsmPublicKeyObject {
	/* All Key objects*/
	CryptokiKeyType		KeyType;				/**< The \p KeyType of this public key */
	BOOL				Derive;
	BOOL				Local;

	/* Public Key specific */
	BOOL				Encrypt;				/**< \c TRUE if the key can be used for encryption */
	BOOL				Verify;					/**< \c TRUE if the key can be used for verification */
	BOOL				VerifyRecover;
	BOOL				Wrap;

	/* RSA */
	int					Bits;					/**< \c For \p KeyType ::CryptokiKeyRSA, indicates the size of the key, in bits */
	unsigned char		*Modulus;				/**< \c For \p KeyType ::CryptokiKeyRSA, the modulus */
	int					ModulusLen;				/**< \c For \p KeyType ::CryptokiKeyRSA, the length of the \p Modulus byte array */
	unsigned char		*Exponent;				/**< \c For \p KeyType ::CryptokiKeyRSA, the exponent */
	int					ExponentLen;			/**< \c For \p KeyType ::CryptokiKeyRSA, the length of the \p Exponent byte array */

	/* EC */
	char				*Curve;					/**< \c For \p KeyType ::CryptokiKeyEC and ::CryptokiKeyEC_EDWARDS, the name of the curve (P256, P384, P521, 25519, 448) */
	unsigned char		*Params;				/**< \c For \p KeyType ::CryptokiKeyEC and ::CryptokiKeyEC_EDWARDS, the curve parameters */
	unsigned long		ParamsLen;				/**< \c For \p KeyType ::CryptokiKeyEC and ::CryptokiKeyEC_EDWARDS, the length of the \p Params byte array */
	unsigned char		*ECPoint;				/**< \c For \p KeyType ::CryptokiKeyEC and ::CryptokiKeyEC_EDWARDS, the public key byte array */
	unsigned long		ECPointLen;				/**< \c For \p KeyType ::CryptokiKeyEC and ::CryptokiKeyEC_EDWARDS, the length of the \p ECPointLen byte array */

	/* Post Quantum */
	unsigned char		*Value;			/* needed for verification */
	unsigned long		ValueLen;		/* needed for verification */
	unsigned long		ParameterSet;
} HsmPublicKeyObject;

/**
 * \struct HsmObject
 *
 * \brief Object representing a public or private key, certificate, symmetric key or data object.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef struct _HsmObject {
	char					*KeyId;				/**< The identifier to use when referencing this object with VedHsm (Typically represents the GUID of the server-side environment) */
	char					*KeyAlias;			/**< The human-readable alias for KeyId. (Typically this includes the project name and environemnt name of the object) */
	char					*KeyContext;		/**< The server provided context referencing a particular key within an environment */
	char					*CreatedOn;			/**< The server provided ISO8601 time  the object was created */
	unsigned long			Handle;				/**< This ID was cast from unsigned long long to unsigned long. ID for the object. Handles within an object list are guaranteed to be unique. \note Handle values are not guaranteed to be the same for an object between sessions */
	unsigned long long		OrigHandle;		    /**< This is the original ID received from TPP. ID for the object. Handles within an object list are guaranteed to be unique. \note Handle values are not guaranteed to be the same for an object between sessions */
	CryptokiObjectType		ObjectType;			/**< The \ref CryptokiObjectType of this item */
	HsmEnvironmentType		EnvironmentType;	/**< \p HsmEnvironmentType value indicating the type of environment this object comes from */
	unsigned char			*Label;				/**< The server-assigned label for this object. \note Labels between objects of different \p ObjectType will be the same if they belong to the same environment */
	unsigned char			*Id;				/**< A byte array representing an ID for this object. \note IDs between objects of different \p ObjecType will be the same if they belong to the same environment */
	unsigned long			IdLen;				/**< The length of the \p Id byte array */
	BOOL					Authentication;		/**< \c TRUE if the object can be used for authentication purposes */
	BOOL					Signing;			/**< \c TRUE if the object can be used for signing/verification purposes */
	BOOL					Encipherment;		/**< \c TRUE if the object can be used for encryption/decryption purposes */
	BOOL					Copyable;
	BOOL					Modifiable;
	BOOL					Priv;
	BOOL					Token;
	BOOL					Pending;

	struct _HsmObject 	    *next;				/**< Link to the next HsmObject element in the list */
	struct _HsmObject	    *prev;				/**< Link to the previous HsmObject element in the list */

	union {
		HsmDataObject		 Data;				/**< If the \p ObjecType is ::CryptokiData this element will hold all Data specific values */
		HsmCertificateObject Certificate;		/**< If the \p ObjecType is ::CryptokiCertificate this element will hold all Data specific values */
		HsmPublicKeyObject	 PublicKey;			/**< If the \p ObjecType is ::CryptokiPublicKey this element will hold all Data specific values */
		HsmPrivateKeyObject	 PrivateKey;		/**< If the \p ObjecType is ::CryptokiPrivateKey this element will hold all Data specific values */
		HsmSecretKeyObject	 SecretKey;			/**< If the \p ObjecType is ::CryptokiSecretKey this element will hold all Data specific values */
	};
} HsmObject;

/**
 * \typedef LibHsmFilterHandle
 *
 * \brief The handle to a filtering object that can be used to control what objects LibHsmApiGetObjects() returns.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef void *LibHsmFilterHandle;

/**
 * \brief An enumeration of flags that may be set on a \p LibHsmFilterHandle to control what objects LibHsmApiGetObjects() returns.
 *
 * \headerfile HsmObjects.h <venafi/hsm/HsmObjects.h>
 */
typedef enum {
	LibHsmFilterIncludePending = 1,				/**< Return objects which are pending creation or pending upload. These will have \p Token set to FALSE to indicate that no key is stored. */
} LibHsmFilterFlags;

#ifdef __cplusplus
}
#endif

/// \}

#endif // HSMOBJECTS_H
