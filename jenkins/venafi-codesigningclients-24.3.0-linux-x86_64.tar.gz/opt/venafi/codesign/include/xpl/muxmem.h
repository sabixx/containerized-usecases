/*
Copyright 1996-2003 Terran Software, Inc.
Copyright 2016-2019 Venafi, Inc.
All Rights Reserved.

This program is unpublished proprietary source code of Venafi, Inc.
Your use of this code is limited to those rights granted in the license between you and Venafi.

Author: Peter Dennis Bartok (peter@venafi.com)
*/

#ifndef TERRAN_MUXMEM_H
#define TERRAN_MUXMEM_H

#include <platform.h>

#define MEM_POS							__FILE__, __LINE__

#undef Unchecked
#define	Unchecked(memfunction)			Unchecked_ ## memfunction

#undef Reassign
#define	Reassign(block)					Reassign_Internal(block, MEM_POS)

#define	Malloc(size)					Malloc_Internal(size, MEM_POS)
#define	Calloc(size, ElSize)			Calloc_Internal(size, ElSize, MEM_POS)
#define	Free(block)						Free_Internal(block, MEM_POS)
#define Realloc(block, size)			Realloc_Internal(block, size, MEM_POS)
#define	Strdup(s)						Strdup_Internal(s, MEM_POS)
#define	Memcpy(d,s,size)				Memcpy_Internal(d,s,size, MEM_POS)
#define	Memset(d,c,size)				Memset_Internal(d,c,size, MEM_POS)

#define	malloc(size)					Malloc_Internal(size, MEM_POS)
#define	calloc(size, ElSize)			Calloc_Internal(size, ElSize, MEM_POS)
#define	free(block)						Free_Internal(block, MEM_POS)
#define realloc(block, size)			Realloc_Internal(block, size, MEM_POS)
#ifdef strdup
# undef strdup
#endif
#define	strdup(s)						Strdup_Internal(s, MEM_POS)
#ifdef _strdup
# undef _strdup
#endif
#define	_strdup(s)						Strdup_Internal(s, MEM_POS)
#define	_wcsdup(s)						Wcsdup_Internal(s, MEM_POS)
#ifdef memcpy
# undef memcpy
#endif
#define	memcpy(d,s,size)				Memcpy_Internal(d,s,size, MEM_POS)
#ifdef memset
# undef memset
#endif
#define	memset(d,c,size)				Memset_Internal(d,c,size, MEM_POS)
#define	DictCreate()					DictCreate_Internal(MEM_POS)
#define	DictDestroy(d)					DictDestroy_Internal(d, MEM_POS)


/* Functions in the string replacement code*/
void		*Malloc_Internal(size_t size, char *SourceFilename, int SourceCodeline);
void		*Calloc_Internal(size_t size, size_t ElSize, char *SourceFilename, int SourceCodeline);
void		Free_Internal(void *block, char *SourceFilename, int SourceCodeline);
void		*Realloc_Internal(void *block, size_t size, char *SourceFilename, int SourceCodeline);
void		*Strdup_Internal(const char *s, char *SourceFilename, int SourceCodeline);
void		*Memset_Internal(void *dest, int c, size_t n, char *SourceFilename, int SourceCodeline);
void		*Memcpy_Internal(void *dest, const void *src, size_t n, char *SourceFilename, int SourceCodeline);
void		ShutMemDown(char *Name);
void		ShutMemDownDetails(char *filename, unsigned long *leak, unsigned long *illegal_free, unsigned long *illegal_realloc, unsigned long *overwrite);
void		*DictCreate_Internal(char *SourceFilename, int SourceCodeline);
void		*DictDestroy_Internal(Dict d, char *SourceFilename, int SourceCodeline);
void		*Unchecked_malloc(size_t size);
void		*Unchecked_calloc(size_t size, size_t Elsize);
void		*Unchecked_memset(void *dest, int c, size_t n);
void		*Unchecked_memcpy(void *dest, const void *src, size_t n);
void		Unchecked_free(void *block);
void		Reassign_Internal(void *ptr, char *SourceFilename, int SourceCodeline);

#if defined(WIN32)
void		*Wcsdup_Internal(const WCHAR *s, char *SourceFilename, int SourceCodeline);
#endif


#endif /* TERRAN_MUXMEM_H */
