//
// Copyright 2016-2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

/*
	This must be defined BEFORE including `string.h` and others for things such
	as `strcasecmp` and `qsort_r`
*/
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif

#ifndef _XPL_LIN_H
#define _XPL_LIN_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <pthread.h>
#include <semaphore.h>
#include <strings.h>
#include <string.h>
#include <limits.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <dirent.h>
#include <dlfcn.h>
#include <signal.h>
#include <sys/file.h>
#include <sys/poll.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <stdarg.h>
#include <ctype.h>
#include <termios.h>
#include <pwd.h>

#ifdef __cplusplus
extern "C" {
#endif

/*********************
  General Defines
 *********************/
typedef	int					BOOL;
typedef long				LONG;
typedef	unsigned long		ULONG;
typedef	unsigned char		BYTE;
typedef	unsigned short		WORD;
typedef unsigned short		unicode;
typedef unsigned short		WCHAR;
typedef unsigned char		byte;
typedef unsigned long		DWORD;
typedef char				TCHAR;
typedef int					errno_t;

#define	_MAX_PATH		PATH_MAX
#define	MAX_PATH		PATH_MAX

#if !defined(UNREFERENCED_PARAMETER)
#define UNREFERENCED_PARAMETER(P)          (P)
#endif

/**********************
  General Unix/PC diffs
 **********************/
#define stricmp(a,b)					strcasecmp(a,b)
#define strnicmp(a,b,c)					strncasecmp(a,b,c)
#define _strdup(a)						strdup(a)
#define _strnicmp(a,b,c)				strncasecmp(a,b,c)
#define _stricmp(a,b)					strcasecmp(a,b)
#define strcat_s(a,b,c)			        strcat(a,c)
#define strncat_s(a,b,c,d)		        strncat(a,c,d)
#define sprintf_s(a,b,c,...)			sprintf(a,c,__VA_ARGS__)
#define vsprintf_s(h,a,b,c)			    vsprintf(h,b,c)
#define fopen_s(pFile,filename,mode)	(((*(pFile))=fopen((filename),(mode)))==NULL)
#define _fsopen(filename,mode,share)	fopen((filename),(mode))
#define wcslen(a)						strlen(a)
#define _time64(a)						time(a)
#define localtime_s(a,b)				localtime_r((b),(a))
#define strtok_s(a,b,c)                 strtok_r((a), (b), (c))
#define _stat							stat
#define _fstat							fstat
#define _fileno							fileno
#define _unlink(a)						unlink(a)
#define _dup(a)							dup(a)
#define _dup2(a, b)						dup2(a, b)
#define _getcwd(b, s)					getcwd(b, s)
#define _isatty(f)						isatty((f))

typedef int								SOCKET;
#ifndef closesocket
#define closesocket(a)					close(a)
#endif  /* closesocket */
#define _close(a)						close(a)
#define _read(a, b, c)					read(a, b, c)
#define _write(a, b, c)					write(a, b, c)

#if !defined(__isascii)
#define __isascii(c)					((unsigned)(c) < 0x80)
#endif  /* __isascii */
#define __ascii_tolower(c)				( (((c) >= 'A') && ((c) <= 'Z')) ? ((c) - 'A' + 'a') : (c) )
#define __ascii_toupper(c)				( (((c) >= 'a') && ((c) <= 'z')) ? ((c) - 'a' + 'A') : (c) )

#ifndef min
#define min(a,b)						(((a)<(b)) ? (a) : (b))	
#endif /* min */
#ifndef max
#define max(a,b)						(((a)<(b)) ? (b) : (a))	
#endif /* max */

#define strncpy_s(a,b,c,d) {						\
	size_t dest_size = (size_t) b;					\
	size_t copy_count = min(dest_size, (d));		\
													\
	if (dest_size > copy_count) {					\
		Unchecked(memcpy(a, c, copy_count));		\
		(a)[copy_count] = '\0';						\
	} else {										\
		/* We don't have space for the \0 */		\
		Unchecked(memcpy(a, c, copy_count));		\
		(a)[dest_size-1] = '\0';					\
	}												\
}
#define strcpy_s(a,b,c) {							\
	size_t dest_size = (size_t) b;					\
	size_t copy_count = strlen(c);					\
													\
	if (copy_count < dest_size)						\
		strcpy(a, c);								\
	else {											\
		Unchecked(memcpy(a, c, copy_count));		\
		(a)[dest_size-1] = '\0';					\
	}												\
}

#define Sleep(ms) {									\
   struct timespec rem = { 0, 0 };					\
   struct timespec req = {							\
       (int)((ms) / 1000),							\
       ((ms) % 1000) * 1000000						\
   };												\
													\
   nanosleep(&req , &rem);							\
}

char *GetEnv(const char *name);

#ifdef __cplusplus
}
#endif

#endif /* _XPL_LIN_H */
