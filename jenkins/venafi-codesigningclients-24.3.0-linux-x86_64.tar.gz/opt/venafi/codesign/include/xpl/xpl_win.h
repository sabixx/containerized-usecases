//
// Copyright 2016-2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#ifndef _XPL_WIN_H
#define _XPL_WIN_H

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <process.h>
#include <signal.h>
#include <time.h>
#include <sys/stat.h>
#include <direct.h>
#include <limits.h>
#include <tchar.h>
#include <conio.h>


/* Disable signed/unsigned warnings */
// #pragma warning ( disable : 4018 )

/* Disable unreferenced formal parameter warning */
#pragma warning ( disable : 4100 )

/* Disable nonstandard extension used warning: for nameless union */
#pragma warning ( disable : 4201 )

/* Disable nonstandard extension used warning: translation unit is empty */
#pragma warning ( disable : 4206 )

/* Disable nonstandard extension used warning: translation unit is empty */
//#pragma warning ( disable : 4047 )

#ifdef __cplusplus
extern "C" {
#endif

typedef	unsigned short	unicode;

const char *strcasestr(const char *szStringToBeSearched, const char *szSubstringToSearchFor);
int vasprintf(char **dest, const char *format, va_list args);
int asprintf(char **dest, const char *format, ...);

wchar_t *Utf8ToWchar(const char *utf8, int size);
char *WcharToUtf8(const wchar_t *utf16);
void FreeWchar(wchar_t *utf16);
void FreeUtf8(char *utf8);
char *GetEnv(const char *name);

#define	gmtime_r(in, out)			gmtime_s(out, in) 
#define	localtime_r(in, out)		localtime_s(out, in)

#ifdef __cplusplus
}
#endif

#endif /* _XPL_WIN_H */
