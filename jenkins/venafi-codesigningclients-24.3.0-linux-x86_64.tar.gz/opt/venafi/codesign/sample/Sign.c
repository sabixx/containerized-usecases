//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#include "LibHsmSample.h"

int
DoSign() {
	char buffer[1024];
	char *error_text;
	HsmObject *objects;
	HsmObject *current;
	HsmObject *key;
	LibHsmError *hsm_error;
	unsigned char *hash;
	unsigned char *signature;
	unsigned long signature_len;
	unsigned char *digest;
	size_t digest_len;
	unsigned long sign_mechanism;
	unsigned long sign_client_mechanism;
	FILE *input;
	FILE *output;
	BOOL digest_ok;
	int ret;

	key = NULL;
	input = NULL;
	output = NULL;
	error_text = NULL;
	hsm_error = NULL;
	hash = NULL;
	digest = NULL;
	digest_len = 0;
	signature = NULL;
	signature_len = 0;
	ret = -1;

	if (cert_label == NULL) {
		if (ReadLine("Signing key label: ", buffer, sizeof(buffer), FALSE) == NULL) {
			goto sign_failed;
		}
		if (buffer[0] != '\0') {
			cert_label = _strdup(buffer);
		}
		if (cert_label == NULL) {
			Usage(TRUE, NULL, "ERROR: -label required.\n");
			goto sign_failed;
		}
	}

	if (filename == NULL) {
		if (ReadLine("File to sign: ", buffer, sizeof(buffer), FALSE) == NULL) {
			goto sign_failed;
		}
		if (buffer[0] != '\0') {
			filename = _strdup(buffer);
		}
	}

	if (output_name == NULL) {
		if (ReadLine("File to store signature: ", buffer, sizeof(buffer), FALSE) == NULL) {
			goto sign_failed;
		}
		if (buffer[0] != '\0') {
			output_name = _strdup(buffer);
		}
	}


	if ((filename == NULL) && (output_name == NULL)) {
		Usage(TRUE, NULL, "ERROR: -file and -output required.\n");
		goto sign_failed;
	}

	if (!FileExists(filename, NULL, NULL, NULL) || (fopen_s(&input, filename, "rb") != 0)) {
		printf("ERROR: Cannot find or open file '%s'.\n", filename);
		goto sign_failed;
	}

	if (!LibHsmGetObjectList(libhsm, &objects)) {
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error_text);
		printf("ERROR: Failed to retrieve key list.\n   %s\n", error_text);
		goto sign_failed;
	}

	if (objects == NULL) {
		printf("ERROR: No keys available.\n");
		goto sign_failed;
	}

	key = NULL;
	for (current = objects; current != NULL; current = current->next) {
		if (_stricmp((const char *)current->Label, cert_label) != 0) {
			continue;
		}
		if (current->ObjectType != CryptokiPrivateKey) {
			continue;
		}
		key = current;
		break;
	}

	if (key == NULL) {
		printf("ERROR: Key '%s' does not exist.\n", cert_label);
		goto sign_failed;
	}

	hash = LibHsmGetFileHash((const unsigned char *)filename, &hsm_error);
	if (hash == NULL) {
		printf("ERROR: Unable to create file hash. [%s]\n", hsm_error->error);
		goto sign_failed;
	}

	if (verbose) {
		char *hex;

		if (Bin2Hex((BYTE *)hash, 32, &hex)) {
			printf("INFO: File hash is %s\n", hex);
			LibHsmFreeResult(hex);
		}
	}

	switch (key->PrivateKey.KeyType) {
		case CryptokiKeyRSA:
			sign_mechanism = CryptokiMechanismRsaPkcs;
			sign_client_mechanism = CryptokiMechanismRsaSha256;
			// If we're not signing with Ed25519 we need to create a message digest for our hash
			digest_ok = LibHsmCreateMessageDigest(libhsm, CryptokiMechanismSha256, hash, 32, &digest, &digest_len);
			break;

		case CryptokiKeyEC:
			sign_mechanism = CryptokiMechanismEcDsa;
			sign_client_mechanism = CryptokiMechanismEcDsaSha256;
			// If we're not signing with Ed25519 we need to create a message digest for our hash
			digest_ok = LibHsmCreateMessageDigest(libhsm, CryptokiMechanismSha256, hash, 32, &digest, &digest_len);
			break;

		case CryptokiKeyEC_EDWARDS:
			sign_mechanism = CryptokiMechanismEdDsa;
			sign_client_mechanism = CryptokiMechanismEdDsa;
			digest_len = 32; /* Sha-256 is 32 bytes */
			digest_ok = TRUE;
			break;

		default:
			printf("ERROR: Unsupported key type. [%d]\n", key->PrivateKey.KeyType);
			goto sign_failed;

	}

	if (!digest_ok) {
		LibHsmGetErrorText(libhsm, TRUE, "; ", &error_text);
		printf("ERROR: Failed to create message digest. [%s]\n", error_text);
		goto sign_failed;
	}

	try_signing_again:
	if (!LibHsmApiSign(libhsm, sign_mechanism, sign_client_mechanism, key, digest ? digest : hash, (unsigned long)digest_len, NULL, &signature, &signature_len)) {
		LibHsmError *error_element;

		if (LibHsmHasError(libhsm, LibHsmErr_VedHsmTryLater, &error_element)) {
			// Server might indicate it requires approval; give the user a chance to repeat (after approving the request)
			printf("WARNING: %s\n", error_element->error);
			if (ReadLine("Do you want to try again (y/n): ", buffer, sizeof(buffer), FALSE) != NULL) {
				if ((buffer[0] == 'Y') || (buffer[0] == 'y')) {
					goto try_signing_again;
				}
			}
		} else {
			LibHsmGetErrorText(libhsm, TRUE, "; ", &error_text);
			printf("ERROR: Failed to sign. [%s].", error_text);
		}
		goto sign_failed;
	}

	if (fopen_s(&output, output_name, "wb") != 0) {
		printf("ERROR: Could not open or create file '%s'. [%d]\n", output_name, errno);
		goto sign_failed;
	}
	if (fwrite(signature, 1, signature_len, output) != signature_len) {
		printf("ERROR: Failed to write hash to output. [%d]\n", errno);
		goto sign_failed;
	}

	printf("SUCCESS: Signed file '%s', signature written to '%s'.\n", filename, output_name);

	ret = 0;

sign_failed:
	if (signature != NULL) {
		LibHsmFreeResult(signature);
	}

	if (digest != NULL) {
		LibHsmFreeMessageDigest(libhsm, digest);
	}

	if (hash != NULL) {
		LibHsmFreeResult(hash);
	}

	if (input != NULL) {
		fclose(input);
	}

	if (output != NULL) {
		fclose(output);
	}

	if (hsm_error != NULL) {
		LibHsmFreeError(hsm_error);
	}
	if (error_text != NULL) {
		LibHsmFreeErrorText(error_text);
	}

	return ret;
}
