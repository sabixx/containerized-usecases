//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#include "LibHsmSample.h"

int
DoCheckGrant(BOOL verification_call) {
	char *error;
	BOOL have_access_token;
	BOOL have_refresh_token;
	time_t valid_until;
	long days_valid;
	char time_buf[128];
	const char *url;

	Unchecked(memset(&valid_until, 0, sizeof(time_t)));

	if (!LibHsmLoadConfiguration(libhsm)) {
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
		printf("ERROR: Configuration cannot be read.\n  %s\n", error);
		LibHsmFreeErrorText(error);
		return -1;
	}

	url = (const char *)LibHsmGetAuthUrl(libhsm);
	if (url != NULL) {
		if (!verification_call) {
			printf("INFO: Authentication Url: %s\n", url);
		}
	} else {
		if (!verification_call) {
			printf("ERROR: No Authentication Url.\n");
		}
	}
	url = (const char *)LibHsmGetHsmUrl(libhsm);
	if (url != NULL) {
		if (!verification_call) {
			printf("INFO: HSM Url:            %s\n", url);	 // Matching the spacing of Authentication URL
		}
	} else {
		if (!verification_call) {
			printf("ERROR: No HSM Server Url.\n");
		}
	}

	if (!LibHsmGetGrantStatus(libhsm, &have_access_token, &have_refresh_token, &days_valid, &valid_until)) {
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
		printf("ERROR: Failed to obtain grant status.\n   %s\n", error);
		LibHsmFreeErrorText(error);
		return -1;
	}

	if (have_access_token) {
		if (!LibHsmOAuthVerifyGrant(libhsm)) {
			LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
			printf("ERROR: Configured grant is not known to the configured authentication server.\n   %s\n", error);
			LibHsmFreeErrorText(error);
			return 1;
		}
		if (have_refresh_token) {
			if (!verification_call) {
				printf("INFO: Valid grant and refresh token found. ");
			} else {
				printf("INFO: Valid grant and refresh token available. ");
			}
		} else {
			if (!verification_call) {
				printf("INFO: Valid grant found. Grant cannot be refreshed. ");
			} else {
				printf("INFO: Valid grant found. Grant cannot be refreshed. ");
			}
		}
	} else {
		if (!verification_call) {
			printf("ERROR: NO grant found.\n");
			return 1;
		} else {
			printf("ERROR: NO valid grant.\n");
			return 1;
		}
	}

	if (valid_until != 0) {
		struct tm tm_info;

		localtime_s(&tm_info, &valid_until);
		strftime(time_buf, sizeof(time_buf) / sizeof(char), "%c", &tm_info);

		if (days_valid > 0) {
			printf("Grant expires %s, %ld days from now", time_buf, days_valid);
		} else {
			printf("Grant expired %s, %ld days ago", time_buf, -days_valid);
		}
	}

	printf("\n");

	if (!have_access_token) {
		return 1;
	}

	if (days_valid < days) {
		if (days > 0) {
			printf("ERROR: Grant expires in less than %d days\n", days);
		}
		return 1;
	}
	printf("SUCCESS: Grant is valid.\n");

	return 0;
}

