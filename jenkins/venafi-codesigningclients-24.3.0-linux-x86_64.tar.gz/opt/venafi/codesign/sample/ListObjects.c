//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#include "LibHsmSample.h"

#if defined(WIN32)
int
ConsoleWidth() {
	CONSOLE_SCREEN_BUFFER_INFO csbi;

	if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi)) {
		return csbi.srWindow.Right - csbi.srWindow.Left + 1;
	}
	return 80;
}
#else
#include <sys/ioctl.h>
int
ConsoleWidth() {
	struct winsize size;

	if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &size) != -1) {
		return size.ws_col;
	}
	return 80;
}
#endif

const char line_filler[] = "------------------------------------------------------------------------------------";

char default_environments[128];
char default_objects[128];
char default_objects_verbose[128];

int table_label_width = 30;
int table_env_width = 5;
int table_obj_type_width = 9;
int table_context_width = 8;
int table_auth_width = 4;
int table_sign_width = 4;
int table_encipher_width = 4;
int table_detail_type_width = 9;
int table_detail_text_width = 30;
int table_key_id_width = 38;
int table_handle_width = 6;

BOOL
ParseEnvironmentTypes(char *list, int **types, int *type_count) {
	char *token;
	char *context;
	int *result;
	int count;

	result = calloc(20, sizeof(int));
	if (result == NULL) {
		printf("ERROR: Could not allocate environment list.\n");
		return FALSE;
	}
	context = NULL;
	count = 0;

	if (_stricmp(list, "all") == 0) {
		result[count++] = (int)HsmEnvCertificate;
		result[count++] = (int)HsmEnvGPG;
		result[count++] = (int)HsmEnvDotNet;
		result[count++] = (int)HsmEnvCSP;
		result[count++] = (int)HsmEnvKeyPair;
		result[count++] = (int)HsmEnvSecretKey;
	} else {
		token = strtok_s(list, ",", &context);
		do {
			if (_strnicmp("ce", token, 2) == 0) {
				result[count++] = (int)HsmEnvCertificate;
			} else if (_strnicmp("g", token, 1) == 0) {
				result[count++] = (int)HsmEnvGPG;
			} else if (_strnicmp("n", token, 1) == 0) {
				result[count++] = (int)HsmEnvDotNet;
			} else if (_strnicmp("cs", token, 2) == 0) {
				result[count++] = (int)HsmEnvCSP;
			} else if (_strnicmp("keyp", token, 2) == 0) {
				result[count++] = (int)HsmEnvKeyPair;
			} else if (_stricmp("key", token) == 0) {
				result[count++] = (int)HsmEnvSecretKey;
			} else {
				printf("WARNING: Ignoring unknown environment type '%s'.\n", token);
			}
			token = strtok_s(NULL, ",", &context);
		} while (token != NULL);
	}

	*types = result;
	*type_count = count;

	return TRUE;
}

BOOL
ParseObjectTypes(char *list, int **types, int *type_count) {
	char *token;
	char *context;
	int *result;
	int count;

	result = calloc(20, sizeof(int));
	if (result == NULL) {
		printf("ERROR: Could not allocate object list.\n");
		return FALSE;
	}
	context = NULL;
	count = 0;
	if (_stricmp(list, "all") == 0) {
		result[count++] = (int)CryptokiData;
		result[count++] = (int)CryptokiCertificate;
		result[count++] = (int)CryptokiPublicKey;
		result[count++] = (int)CryptokiPrivateKey;
		result[count++] = (int)CryptokiSecretKey;
		result[count++] = (int)CryptokiHwFeature;
		result[count++] = (int)CryptokiDomainParameters;
		result[count++] = (int)CryptokiMechanismType;
		result[count++] = (int)CryptokiOtpKey;
	} else {
		token = strtok_s(list, ",", &context);
		do {
			if (_strnicmp("d", token, 1) == 0) {
				result[count++] = (int)CryptokiData;
			} else if (_strnicmp("c", token, 1) == 0) {
				result[count++] = (int)CryptokiCertificate;
			} else if (_strnicmp("pu", token, 2) == 0) {
				result[count++] = (int)CryptokiPublicKey;
			} else if (_strnicmp("pr", token, 2) == 0) {
				result[count++] = (int)CryptokiPrivateKey;
			} else if (_strnicmp("s", token, 2) == 0) {
				result[count++] = (int)CryptokiSecretKey;
			} else if (_strnicmp("h", token, 1) == 0) {
				result[count++] = (int)CryptokiHwFeature;
			} else if (_strnicmp("d", token, 1) == 0) {
				result[count++] = (int)CryptokiDomainParameters;
			} else if (_strnicmp("m", token, 1) == 0) {
				result[count++] = (int)CryptokiMechanismType;
			} else if (_strnicmp("o", token, 1) == 0) {
				result[count++] = (int)CryptokiOtpKey;
			} else {
				printf("WARNING: Ignoring unknown object type '%s'.\n", token);
			}
			token = strtok_s(NULL, ",", &context);
		} while (token != NULL);
	}

	*types = result;
	*type_count = count;

	return TRUE;
}


BOOL
IsInList(int val, int *list, int list_len) {
	int i;

	for (i = 0; i < list_len; i++) {
		if (list[i] == val) {
			return TRUE;
		}
	}
	return FALSE;
}
int
DoListObjects() {
	char *error;
	HsmObject *objects;
	HsmObject *current;
	char buffer[1024];
	char *id;
	int cert_count;
	int pub_count;
	int priv_count;
	int secret_count;
	int *environment_types;
	int environment_count;
	int *object_types;
	int object_count;
	BOOL show_detail_text;
	BOOL show_keyid_text;
	BOOL show_handle_text;
	BOOL show_context_text;
	BOOL pending;
	int ret;
	int i;

	show_detail_text = FALSE;
	show_keyid_text = FALSE;
	show_handle_text = FALSE;
	show_context_text = FALSE;

	environment_types = NULL;
	environment_count = 0;
	object_types = NULL;
	object_count = 0;

	objects = NULL;
	ret = -1;

	if (env_list != NULL) {
		if (!ParseEnvironmentTypes(env_list, &environment_types, &environment_count)) {
			goto list_failed;
		}
	} else {
		if (!ParseEnvironmentTypes(default_environments, &environment_types, &environment_count)) {
			goto list_failed;
		}
	}

	if (type_list != NULL) {
		if (!ParseObjectTypes(type_list, &object_types, &object_count)) {
			goto list_failed;
		}
	} else {
		if (!verbose) {
			if (!ParseObjectTypes(default_objects, &object_types, &object_count)) {
				goto list_failed;
			}
		} else {
			if (!ParseObjectTypes(default_objects_verbose, &object_types, &object_count)) {
				goto list_failed;
			}
		}
	}

	pending = TRUE;
	for (i = 0; (i < 2) && pending; i++) {
		if (objects != NULL) {
			LibHsmFreeObjectList(libhsm, objects);
			objects = NULL;
		}
		if (pending && (i > 0)) {
			printf("INFO: Some objects are still being created. Waiting 10 seconds and trying again.\n");
#if defined(WIN32)
			Sleep(10000);
#elif defined(MAC) || defined(LINUX)
			sleep(10);
#endif
		}
		if (!LibHsmApiGetObjects(libhsm, NULL, TRUE, FALSE, &pending, &objects)) {
			LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
			printf("ERROR: Failed to retrieve objects.\n   %s\n", error);
			LibHsmFreeErrorText(error);
			goto list_failed;
		}
	}
	if (objects == NULL) {
		printf("INFO: No objects available.\n");
		ret = 0;
		goto list_failed;
	}

	if (table) {
		int need_width;
		int console_width;
		int max_label;

		max_label = 0;
		current = objects;
		while (current != NULL) {
			if (IsInList(current->EnvironmentType, environment_types, environment_count) && IsInList(current->ObjectType, object_types, object_count)) {
				int len;

				len = (int)strlen((const char *)current->Label);
				if (len > max_label) {
					max_label = len;
				}
			}

			current = current->next;
		}
		if (table_label_width > max_label) {
			table_label_width = max(max_label, 6);
		}
 
		console_width = ConsoleWidth();
		need_width = table_label_width + table_env_width + 2 + table_obj_type_width + 2 + table_detail_type_width + 2 + table_auth_width + 2 + table_sign_width + 2 + table_encipher_width + 2;
		if (console_width < need_width) {
			table_label_width = max(10, need_width - console_width);
		} else {
			// If we have space to bump the label width and need some more chars, lets add those now
			if (console_width > (need_width + (max_label - table_label_width))) {
				// Lets be reasonable and give the other columns space, too
				if ((max_label - table_label_width) > 10) {
					need_width += 10;
					table_label_width += 10;
				} else {
					need_width += (max_label - table_label_width);
					table_label_width = max_label;
				}
			}
			if ((need_width + 10) < console_width) {
				show_detail_text = TRUE;
				need_width += table_detail_text_width + 2;
				if (console_width < need_width) {
					table_detail_text_width = min(10, max(10, need_width - console_width));
				} else if ((need_width + 10) < console_width) {
					show_context_text = TRUE;
					need_width += table_context_width + 2;
					if (console_width < need_width) {
						table_context_width = min(10, max(10, need_width - console_width));
					} else if ((need_width + 10) < console_width) {
						show_keyid_text = TRUE;
						need_width += table_key_id_width + 2;
						if (console_width < need_width) {
							table_key_id_width = min(10, max(10, need_width - console_width));
						} else if ((need_width + 7) < console_width) {
							show_handle_text = TRUE;
							need_width += table_handle_width + 2;
							if (console_width < need_width) {
								table_handle_width = min(5, max(5, need_width - console_width));
							}
						}
					}
				}
			}
		}


		need_width = printf("%-*.*s| Env  | Object   | Type     |Sign|Ciph|Auth|", table_label_width, table_label_width, "Label");
		if (show_detail_text) {
			printf(" %-*.*s|", table_detail_text_width, table_detail_text_width, "Detail");
		}
		if (show_context_text) {
			printf("%-*.*s|", table_context_width, table_context_width, " Context");
		}
		if (show_keyid_text) {
			printf("%-*.*s|", table_key_id_width, table_key_id_width, " Key ID");
		}
		if (show_handle_text) {
			printf("%-*.*s|", table_handle_width, table_handle_width, "Handle");
		}
		printf("\n%.*s+%.*s-+%.*s-+%.*s-+%.*s+%.*s+%.*s+",
			table_label_width, line_filler, 
			table_env_width, line_filler, 
			table_obj_type_width, line_filler, 
			table_detail_type_width, line_filler, 
			table_sign_width, line_filler, 
			table_encipher_width, line_filler,
			table_auth_width, line_filler);

		if (show_detail_text) {
			printf("-%.*s+", table_detail_text_width, line_filler);
		}
		if (show_context_text) {
			printf("%.*s+", table_context_width, line_filler);
		}
		if (show_keyid_text) {
			printf("%.*s+", table_key_id_width, line_filler);
		}
		if (show_handle_text) {
			printf("%.*s+", table_handle_width, line_filler);
		}
		printf("\n");
	}

	cert_count = 0;
	pub_count = 0;
	priv_count = 0;
	secret_count = 0;
	for (current = objects; current != NULL; current = current->next) {
		if (!IsInList(current->EnvironmentType, environment_types, environment_count) || !IsInList(current->ObjectType, object_types, object_count)) {
			continue;
		}
		if (!table) {
			switch (current->ObjectType) {
				case CryptokiCertificate:	printf("Certificate %d: \n", ++cert_count); break;
				case CryptokiPrivateKey:	printf("Private Key %d: \n", ++priv_count); break;
				case CryptokiPublicKey:		printf("Public Key %d: \n", ++pub_count); break;
				case CryptokiSecretKey:		printf("Secret Key %d: \n", ++secret_count); break;
				default: continue;
			}

			printf("  Label:       %s\n", current->Label);

			switch (current->ObjectType) {
				case CryptokiCertificate: {
					if (LibHsmUtilGetX509Name(current->Certificate.Subject, current->Certificate.SubjectLen, buffer, sizeof(buffer))) {
						printf("  Subject:     %s\n", buffer);
					}
					break;
				}

				case CryptokiPrivateKey: {
					printf("  Key-Type:    ");
					switch (current->PrivateKey.KeyType) {
						case CryptokiKeyRSA: printf("RSA\n"); break;
						case CryptokiKeyDSA: printf("DSA\n"); break;
						case CryptokiKeyEC:	 printf("ECDSA\n"); break;
						case CryptokiKeyEC_EDWARDS:	 printf("EdDSA\n"); break;
						default: printf("%d", current->PrivateKey.KeyType); break;
					}
					break;
				}

				case CryptokiPublicKey: {
					printf("  Key-Type:    ");
					switch (current->PublicKey.KeyType) {
						case CryptokiKeyRSA: printf("RSA\n"); break;
						case CryptokiKeyDSA: printf("DSA\n"); break;
						case CryptokiKeyEC:	 printf("ECDSA\n"); break;
						case CryptokiKeyEC_EDWARDS:	 printf("EdDSA\n"); break;
						default: printf("%d", current->PublicKey.KeyType); break;
					}
					break;
				}

				case CryptokiSecretKey: {
					printf("  Key-Type:    ");
					switch (current->SecretKey.KeyType) {
						case CryptokiKeyAES:		printf("AES\n"); break;
						case CryptokiKeyDES:		printf("DES\n"); break;
						case CryptokiKeyDES3:		printf("Triple-DES\n"); break;
						case CryptokiKeyCHACHA20:	printf("ChaCha20\n"); break;
						case CryptokiKeySALSA20:	printf("Salsa20\n"); break;
						default: printf("%d", current->SecretKey.KeyType); break;
					}
					break;
				}

				default: {
					printf("Unknown object (Type %d)\n", current->ObjectType);
					break;
				}
			}

			if (Bin2Hex(current->Id, current->IdLen, &id)) {
				printf("  ID:          %s", id);
				free(id);
			}
			printf("\n");

			printf("  Environment: ");
			switch (current->EnvironmentType) {
				case HsmEnvCertificate: printf("Certificate"); break;
				case HsmEnvCSP: printf("CSP"); break;
				case HsmEnvDotNet: printf(".NET"); break;
				case HsmEnvGPG: printf("GPG"); break;
				case HsmEnvKeyPair: printf("Asymmetric Key Pair"); break;
				case HsmEnvSecretKey: printf("Symmetric Key"); break;
				default: printf("Unknown"); break;
			}
			printf("\n");

			if (verbose) {
				printf("  KeyId:       %s\n", current->KeyId);
				printf("  Context:     %s\n", current->KeyContext ? current->KeyContext : "<none>");
				printf("  Handle:      %ld\n", current->Handle);
				printf("  Auth:        %s\n", current->Authentication ? "yes" : "no");
				printf("  Sign:        %s\n", current->Signing ? "yes" : "no");
				printf("  Encipher:    %s\n", current->Encipherment ? "yes" : "no");
			}
			if (verbose) {
				printf("\n");
			}
		} else {
			const char *env_type;
			const char *object_type;
			char detail_type[128];
			const char *detail_text;

			detail_text = "";

			switch (current->EnvironmentType) {
				case HsmEnvCertificate: env_type = "Cert"; break;
				case HsmEnvCSP: env_type = "CSP"; break;
				case HsmEnvDotNet: env_type = ".NET"; break;
				case HsmEnvGPG:	env_type = "GPG"; break;
				case HsmEnvKeyPair:	env_type = "KeyPair"; break;
				case HsmEnvSecretKey: env_type = "Secret Key"; break;
				default: env_type = "Unsupported"; break;
			}

			switch (current->ObjectType) {
				case CryptokiCertificate: object_type = "Cert"; ++cert_count; break;
				case CryptokiPrivateKey: object_type = "Priv Key";  ++priv_count; break;
				case CryptokiPublicKey: object_type = "Pub Key"; ++pub_count; break;
				case CryptokiSecretKey:	object_type = "Secret Key"; ++secret_count; break;
				default: object_type = "Unsupported"; break;
			}

			switch (current->ObjectType) {
				case CryptokiCertificate: {
					strcpy_s(detail_type, sizeof(detail_type), "X.509");
					if (LibHsmUtilGetX509Name(current->Certificate.Subject, current->Certificate.SubjectLen, buffer, sizeof(buffer))) {
						detail_text = buffer;
					} else {
						detail_text = "n/a";
					}
					break;
				}

				case CryptokiPrivateKey: {
					switch (current->PrivateKey.KeyType) {
						case CryptokiKeyRSA: sprintf_s(detail_type, sizeof(detail_type), "RSA %d", current->PrivateKey.ModulusLen * 8);  break;
						case CryptokiKeyDSA: sprintf_s(detail_type, sizeof(detail_type), "DSA %d", current->PrivateKey.Bits); break;
						case CryptokiKeyEC: sprintf_s(detail_type, sizeof(detail_type), "ECC-%s", current->PrivateKey.Curve); break;
						case CryptokiKeyEC_EDWARDS:	 sprintf_s(detail_type, sizeof(detail_type), "Ed%s", current->PrivateKey.Curve); break;
						default: strcpy_s(detail_type, sizeof(detail_type), "Unknown"); break;
					}
					break;
				}

				case CryptokiPublicKey: {
					switch (current->PublicKey.KeyType) {
						case CryptokiKeyRSA: sprintf_s(detail_type, sizeof(detail_type), "RSA %d", current->PublicKey.Bits);  break;
						case CryptokiKeyDSA: sprintf_s(detail_type, sizeof(detail_type), "DSA %d", current->PublicKey.Bits); break;
						case CryptokiKeyEC: sprintf_s(detail_type, sizeof(detail_type), "ECC-%s", current->PublicKey.Curve); break;
						case CryptokiKeyEC_EDWARDS:	 sprintf_s(detail_type, sizeof(detail_type), "Ed%s", current->PublicKey.Curve); break;
						default: strcpy_s(detail_type, sizeof(detail_type), "Unknown"); break;
					}
					if (current->EnvironmentType == HsmEnvGPG) {
						char *ptr;

						strcpy_s(buffer, sizeof(buffer), (const char *)current->Label);
						ptr = strchr(buffer, '[');
						if (ptr != NULL) {
							ptr--;
							while ((ptr >= buffer) && isspace(*ptr)) {
								ptr--;
							}
							*(ptr + 1) = '\0';
							detail_text = buffer;
						}
					}
					break;
				}

				case CryptokiSecretKey: {
					switch (current->SecretKey.KeyType) {
						case CryptokiKeyAES: strcpy_s(detail_type, sizeof(detail_type), "AES"); break;
						case CryptokiKeyDES: strcpy_s(detail_type, sizeof(detail_type), "DES"); break;
						case CryptokiKeyDES3: strcpy_s(detail_type, sizeof(detail_type), "3-DES"); break;
						case CryptokiKeyCHACHA20: strcpy_s(detail_type, sizeof(detail_type), "ChaCha20"); break;
						case CryptokiKeySALSA20: strcpy_s(detail_type, sizeof(detail_type), "Salsa20"); break;
						default: strcpy_s(detail_type, sizeof(detail_type), "Unknown"); break;
					}
					break;
				}
				case CryptokiData:
					strcpy_s(detail_type, sizeof(detail_type), "Data");
					break;

				case CryptokiDomainParameters:
					strcpy_s(detail_type, sizeof(detail_type), "Domain Parameters");
					break;

				case CryptokiHwFeature:
					strcpy_s(detail_type, sizeof(detail_type), "H/W Feature");
					break;

				case CryptokiMechanismType:
					strcpy_s(detail_type, sizeof(detail_type), "Mechanism");
					break;
				case CryptokiOtpKey:
					strcpy_s(detail_type, sizeof(detail_type), "One-Time Key");
					break;

				default:
					strcpy_s(detail_type, sizeof(detail_type), "Unknown");
					break;
			}

			printf("%-*.*s| %-*.*s| %-*.*s| %-*.*s|%-*.*s|%-*.*s|%-*.*s|", 
				table_label_width, table_label_width, current->Label,
				table_env_width, table_env_width, env_type,
				table_obj_type_width, table_obj_type_width, object_type,
				table_detail_type_width, table_detail_type_width, detail_type,
				table_sign_width, table_sign_width, current->Signing ? " yes" : " no",
				table_encipher_width, table_encipher_width, current->Encipherment ? " yes" : " no",
				table_auth_width, table_auth_width, current->Authentication ? " yes" : " no"
			);
			if (show_detail_text) {
				printf(" %-*.*s|", table_detail_text_width, table_detail_text_width, detail_text);
			}
			if (show_context_text) {
				printf("%-*.*s|", table_context_width, table_context_width, current->KeyContext ? current->KeyContext : " <none>");
			}
			if (show_keyid_text) {
				printf("%-*.*s|", table_key_id_width, table_key_id_width, current->KeyId);
			}
			if (show_handle_text) {
				printf("%-*.*ld|", table_handle_width, table_handle_width, current->Handle);
			}
			printf("\n");
		}
	}

	printf("\n");
	if (pending) {
		printf("NOTICE: Not all objects displayed, some are still pending creation.\n");
	}
	printf("SUCCESS: %d certificate%s, %d public key%s, %d private key%s, %d secret key%s\n", cert_count, (cert_count != 1) ? "s" : "", pub_count, (pub_count != 1) ? "s" : "", priv_count, (priv_count != 1) ? "s" : "", secret_count, (secret_count != 1) ? "s" : "");
	ret = 0;

list_failed:
	if (environment_types != NULL) {
		free(environment_types);
	}

	if (object_types != NULL) {
		free(object_types);
	}

	if (objects != NULL) {
		LibHsmFreeObjectList(libhsm, objects);
	}

	return ret;
}
