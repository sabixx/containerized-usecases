//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#include "LibHsmSample.h"

int
DoSetUrl() {
	char buffer[1024];
	char *error;
	char *config_hsm_url;
	char *config_auth_url;
	LibHsmError *hsm_error;
	BOOL hsm_missing;
	BOOL auth_missing;
	ConfigHandle config;

	hsm_missing = TRUE;
	auth_missing = TRUE;
	hsm_error = NULL;

	if ((auth_url == NULL) || (hsm_url == NULL)) {
		if (auth_url == NULL) {
			if (ReadLine("Authentication URL: ", buffer, sizeof(buffer), FALSE) == NULL) {
				return -1;
			}
			if (buffer[0] != '\0') {
				auth_url = _strdup(buffer);
			}
		}
		if (hsm_url == NULL) {
			if (ReadLine("HSM Backend URL: ", buffer, sizeof(buffer), FALSE) == NULL) {
				return -1;
			}
			if (buffer[0] != '\0') {
				hsm_url = _strdup(buffer);
			}
		}
		if ((auth_url == NULL) || (hsm_url == NULL)) {
			Usage(TRUE, NULL, "ERROR: -authurl or -hsmurl required.\n");
			return -1;
		}
	}

	if (!LibHsmSetUrls(libhsm, auth_url, hsm_url)) {
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
		printf("ERROR: Failed to save URL%s.\n   %s\n", ((auth_url != NULL) && (hsm_url != NULL)) ? "s" : "", error);
		LibHsmFreeErrorText(error);
		return -1;
	}

	error = "0";
	config_auth_url = NULL;
	config_hsm_url = NULL;
	if (LibHsmConfLoad(component, machine, &config, &hsm_error)) {
		LibHsmError *h2;

		LibHsmConfGetValueString(config, CONFIGURATION_AUTH_SERVER_URL, &config_auth_url);
		LibHsmConfGetValueString(config, CONFIGURATION_HSM_SERVER_URL, &config_hsm_url);

		h2 = NULL;
		if (!LibHsmConfFree(config, &h2)) {
			LibHsmFreeError(h2);
		}

		if (config_auth_url != NULL) {
			printf("INFO: Authentication Url: %s\n", config_auth_url);
			auth_missing = FALSE;
		}

		if (config_hsm_url != NULL) {
			printf("INFO: HSM Url:            %s\n", config_hsm_url);
			hsm_missing = FALSE;
		}
		printf("\n");

		if (config_auth_url != NULL) {
			free(config_auth_url);
		}
		if (config_hsm_url != NULL) {
			free(config_hsm_url);
		}
	}

	if (!hsm_missing && !auth_missing) {
		printf("SUCCESS: URL%s saved.\n", ((auth_url != NULL) && (hsm_url != NULL)) ? "s" : "");
	} else {
		if (hsm_missing && auth_missing) {
			printf("ERROR: HSM and Authentication URLs not saved. [%s]\n", hsm_error != NULL ? hsm_error->error : "");
		} else if (hsm_missing) {
			printf("ERROR: HSM URL not saved. [%s]\n", hsm_error != NULL ? hsm_error->error : "");
		} else if (auth_missing) {
			printf("ERROR: Authentication URL not saved. [%s]\n", hsm_error != NULL ? hsm_error->error : "");
		}
		LibHsmFreeError(hsm_error);
		return -1;
	}

	return 0;
}

