//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

/** @example LibHsmSample.c
  * Sample code showing the use of LibHsm APIs
 **/

#define _GNU_SOURCE
#include "LibHsmSample.h"

/* Operational */
BOOL selected_command[NumOfCommands];
const char *error_sep_str = "\n   ";
const char *program_name;
LibHsmHandle libhsm;

/* Option variables */
char *auth_url;
char *cert_label;
char *chain_file;
BOOL check;
BOOL clear;
char *component;
BOOL console;
BOOL csp;
int days;
BOOL p11;
char *delete_name;
BOOL disable;
BOOL enable;
char *env_list;
BOOL export_der;
char *filename;
BOOL force;
BOOL get;
BOOL gpg;
char *hsm_url;
char *input_name;
BOOL log_flag;
BOOL machine;
char *module;
char *name;
BOOL named;
char *output_name;
BOOL revoke_flag;
char *password;
char *pkcs11;
BOOL root_first;
BOOL show;
BOOL split;
BOOL table;
char *type_list;
char *username;
char *value;
BOOL verbose;

int
main(int argc, const char *argv[]) {
	void *program_handle;
	char *error;
	int ret;
	int i;

	ret = 0;
	days = 0;
	p11 = TRUE;

	Unchecked(memset(&selected_command, 0, sizeof(selected_command)));
	program_name = GetProgramName(argv[0], &program_handle);

	if (strcasestr(program_name, "checkgrant") || strcasestr(program_name, "check-grant") || strcasestr(program_name, "check_grant")) {
		SelectCommand(CheckGrant);
		named = TRUE;
	} else if (strcasestr(program_name, "getgrant") || strcasestr(program_name, "get-grant") || strcasestr(program_name, "get_grant")) {
		SelectCommand(GetGrant);
		named = TRUE;
	} else if (strcasestr(program_name, "revokegrant") || strcasestr(program_name, "revoke-grant") || strcasestr(program_name, "revoke_grant")) {
		SelectCommand(RevokeGrant);
		revoke_flag = TRUE;
		named = TRUE;
	} else if (strcasestr(program_name, "grant") || strcasestr(program_name, "grant") || strcasestr(program_name, "grant")) {
		SelectCommand(Grant);
		named = TRUE;
	} else if (strcasestr(program_name, "listcertificates") || strcasestr(program_name, "list-certificates") || strcasestr(program_name, "list_certificates")) {
		SelectCommand(ListObjects);
		named = TRUE;
	} else if (strcasestr(program_name, "listobjects") || strcasestr(program_name, "list-objects") || strcasestr(program_name, "list_objects")) {
		SelectCommand(ListObjects);
		named = TRUE;
	} else if (strcasestr(program_name, "seturl") || strcasestr(program_name, "set-url") || strcasestr(program_name, "set_url")) {
		SelectCommand(SetUrl);
		named = TRUE;
	} else if (strcasestr(program_name, "scd") || strcasestr(program_name, "gpg")) {
		gpg = TRUE;
		p11 = FALSE;
	} else if (strcasestr(program_name, "csp")) {
		csp = TRUE;
		p11 = FALSE;
	}

	SetDefaults();

	for (i = 1; i < argc; i++) {
		// Options
		ArgCheckString(	"au",	auth_url);		// AuthUrl
		ArgCheckString(	"cha",	chain_file);	// ChainFile
		ArgCheckBool(	"cl",   clear);			// Clear
		ArgCheckBool(   "co",   console);		// Console
		ArgCheckBool(	"cs",   csp);			// Csp
		ArgCheckInt(	"da",	days);			// Days
		ArgCheckBool(	"def",  p11);			// Default
		ArgCheckString( "del",  delete_name);	// Delete
		ArgCheckBool(	"di",   disable);		// Disable
		ArgCheckBool(	"ena",  enable);		// Enable
		ArgCheckString( "env",  env_list);		// Environment
		ArgCheckString(	"fi",	filename);		// File
		ArgCheckBool(	"forc", force);			// Force
		ArgCheckMatch(	"form", "DER", export_der);	// Format
		ArgCheckBoolExact("get", get);			// Get
		ArgCheckBool(	"gp",	gpg);			// Gpg
		ArgCheckString(	"hs",	hsm_url);		// HsmUrl
		ArgCheckString(	"in",	input_name);	// Input
		ArgCheckString( "la",   cert_label);	// Label
		ArgCheckBool(	"lo",	log_flag);	    // Log
		ArgCheckBool(   "ma",   machine);		// Machine
		ArgCheckString( "mo",   module);		// Module
		ArgCheckString(	"na",	name);			// Name
		ArgCheckString(	"ou",	output_name);	// Output
		ArgCheckString(	"pa",	password);		// Password
		ArgCheckString(	"pk",	pkcs11);		// Pkcs11
		ArgCheckBool(	"ro",   root_first);	// Root first
		ArgCheckBool(   "sh",   show);			// Show
		ArgCheckBool(   "sp",   split);			// Split
		ArgCheckBool(   "ta",   table);			// Table
		ArgCheckString( "ty",   type_list);		// Type
		ArgCheckString(	"us",	username);		// Username
		ArgCheckString( "va",   value);			// Value
		ArgCheckBool(   "verb", verbose);		// Verbose

		// Commands
		ArgCheckIf("che") {	// CheckGrant
			if (CommandSelected()) {
				if (HaveCommand(Grant)) {
					check = TRUE;
					continue;
				} else {
					Usage(TRUE, argv[i], NULL);
					ret = -1;
					goto exit;
				}
			}
			SelectCommand(CheckGrant);
			continue;
		}
		ArgCheckIf("getg") {	// GetGrant
			if (CommandSelected()) {
				Usage(TRUE, argv[i], NULL);
				ret = -1;
				goto exit;
			}
			SelectCommand(GetGrant);
			continue;
		}
		ArgCheckIf("gra") {		// Grant
			if (CommandSelected()) {
				Usage(TRUE, argv[i], NULL);
				ret = -1;
				goto exit;
			}
			SelectCommand(Grant);
			continue;
		}
		ArgCheckIf("li") {		// ListObjects
			if (CommandSelected()) {
				Usage(TRUE, argv[i], NULL);
				ret = -1;
				goto exit;
			}
			SelectCommand(ListObjects);
			continue;
		}
		ArgCheckIf("re") {		// RevokeGrant
			if (CommandSelected()) {
				if (HaveCommand(Grant)) {
					revoke_flag = TRUE;
					continue;
				} else {
					Usage(TRUE, argv[i], NULL);
					ret = -1;
					goto exit;
				}
			}
			SelectCommand(RevokeGrant);
			continue;
		}
		ArgCheckIf("se") {		// SetUrl
			if (CommandSelected()) {
				Usage(TRUE, argv[i], NULL);
				ret = -1;
				goto exit;
			}
			SelectCommand(SetUrl);
			continue;
		}
		ArgCheckIf("sign") {		// Sign
			if (CommandSelected()) {
				Usage(TRUE, argv[i], NULL);
				ret = -1;
				goto exit;
			}
			SelectCommand(Sign);
			continue;
		}

		ArgCheckIf("veri") {	// Verify
			if (CommandSelected()) {
				Usage(TRUE, argv[i], NULL);
				ret = -1;
				goto exit;
			}
			SelectCommand(Verify);
			continue;
		}

		ArgCheckIf("vers") {	// Version
			if (CommandSelected()) {
				Usage(TRUE, argv[i], NULL);
				ret = -1;
				goto exit;
			}
			SelectCommand(Version);
			continue;
		}

		ArgCheckIfExact("h") {
			if (CommandSelected()) {
				Usage(TRUE, NULL, NULL);
			} else {
				Usage(FALSE, NULL, NULL);
			}
			ret = -1;
			goto exit;
		}
		ArgCheckIfExact("help") {
			if (CommandSelected()) {
				Usage(TRUE, NULL, NULL);
			} else {
				Usage(FALSE, NULL, NULL);
			}
			ret = -1;
			goto exit; 
		}
		ArgCheckIf("?") {
			if (CommandSelected()) {
				Usage(TRUE, NULL, NULL);
			} else {
				Usage(FALSE, NULL, NULL);
			}
			ret = -1; 
			goto exit; 
		}

		// Unknown option:
		Usage(!named, argv[i], NULL);
		ret = -1;
		goto exit;
	}

	// Call this again after processing the commandline
	SetDefaults();

	if (!LibHsmInitialize(&libhsm, machine, component, NULL, &error)) {
		printf("%s: Could not initialize LibHsm: %s\n", program_name, error);
		LibHsmFreeErrorText(error);
		FreeProgramName(program_handle);
		return -1;
	}

	if (LibHsmInError(libhsm)) {
		if (verbose) {
			LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
			printf("WARNING: Initialization reported potential issue: %s\n", error);
			LibHsmFreeErrorText(error);
			error = NULL;
		}
	}

	switch (CommandIndex()) {
		case CheckGrant:
			ret = DoCheckGrant(FALSE);
			break;

		case GetGrant:
			ret = DoGetGrant();
			break;

		case Grant:
			if (!check && !get && !revoke_flag) {
				Usage(TRUE, NULL, "ERROR: You must select one of the above grant command options");
				ret = -1;
				goto exit;
			}
			ret = DoGrant();
			break;

		case ListObjects:
			ret = DoListObjects();
			break;

		case RevokeGrant:
			ret = DoRevokeGrant(FALSE);
			break;

		case SetUrl:
			ret = DoSetUrl();
			break;

		case Sign:
			ret = DoSign();
			break;

		case Verify:
			ret = DoVerify();
			break;

		case Version:
			ret = DoVersion();
			break;

		default:
			Usage(FALSE, NULL, NULL);
			ret = -1;
			break;
	}

	exit:
	if (auth_url != NULL) free(auth_url);
	if (chain_file != NULL) free(chain_file);
	if (delete_name != NULL) free(delete_name);
	if (env_list != NULL) free(env_list);
	if (filename != NULL) free(filename);
	if (hsm_url != NULL) free(hsm_url);
	if (input_name != NULL) free(input_name);
	if (cert_label != NULL) free(cert_label);
	if (module != NULL) free(module);
	if (name != NULL) free(name);
	if (output_name != NULL) free(output_name);
	if (password != NULL) free(password);
	if (pkcs11 != NULL) free(pkcs11);
	if (username != NULL) free(username);
	if (type_list != NULL) free(type_list);
	if (value != NULL) free(value);

	FreeProgramName(program_handle);
	LibHsmShutdown(libhsm);

#ifdef TERRAN_MUXMEM_H
	{
		char buffer[1024];
		int i;
		char *ptr;

		buffer[0] = '\0';
		strcat_s(buffer, sizeof(buffer), program_name);
		for (i = 1; i < argc; i++) {
			strcat_s(buffer, sizeof(buffer), " ");
			strcat_s(buffer, sizeof(buffer), argv[i]);
		}
		ptr = buffer;
		while (*ptr) {
			switch (*ptr) {
				case '\\': *ptr = '_'; break;
				case ':': *ptr = '_'; break;
			}
			ptr++;
		}
		
		ShutMemDown(buffer);
	}
#endif
	return ret;
}

void
PrintCommonSwitches() {
#if defined(WIN32)
	printf("\nCommon options:\n");
	if (!csp) {
		printf("-csp               Use CSP configuraton store\n");
	}
#endif
	if (!gpg) {
		printf("-gpg               Use VenafiSCD for GnuPG configuration store\n");
	}
	if (!p11) {
		printf("-default           Use Pkcs11 configuration store\n");
	}
}

void
Usage(BOOL specific, const char *option_error, const char *error) {
		//      12345678901234567890123 56789012345678901234567890123456789012345678901234567890

	if ((named || specific) && (HaveCommand(CheckGrant) || (HaveCommand(Grant) && check))) {
		if (HaveCommand(CheckGrant)) {
			printf("%s options:\n\n", named ? program_name : "Checkgrant");
		} else {
			printf("%s options:\n\n", named ? program_name : "Grant -check");
		}
		printf("-days:<d>          Grant is not considered valid if it expires within <d> days\n");
		PrintCommonSwitches();
		printf("\n");
		printf("Checks if the system has a valid grant and displays grant information.\n");
		printf("\n");
		printf("Return code 0 indicates a grant has been configured.\n");
		printf("Return code 1 indicates a missing or expired grant.\n");
	}
	if ((named || specific) && (HaveCommand(GetGrant) || (HaveCommand(Grant) && get))) {
		if (HaveCommand(GetGrant)) {
			printf("%s options:\n\n", named ? program_name : "Getgrant");
		} else {
			printf("%s options:\n\n", named ? program_name : "Grant -get");
		}
		printf("-authurl:<url>     Authentication server URL\n");
		printf("-force             Forces getting a new get grant; never refreshes\n");
		printf("-hsmurl:<url>      HSM backend URL\n");
		printf("-password:<pw>     Authentication password\n");
		printf("-username:<user>   Authentication username\n");
		PrintCommonSwitches();
		printf("\n");
		printf("Obtains a code signing grant from the authentication server. If a refresh\n");
		printf("token exists, it will be used to renew the grant, unless -force is used.\n\n");
		printf("If URL arguments are specified, the given URL(s) will be configured and used\n");
		printf("to obtain the grant.\n");
	} 
	if ((named || specific) && (HaveCommand(Grant) && !check && !revoke_flag && !get)) {
		printf("%s options:\n\n", named ? program_name : "Grant");
		printf("-check             Checks if the system has a valid grant\n");
		printf("-get               Obtains a new grant\n");
		printf("-revoke            Revokes an existing grant\n");
		PrintCommonSwitches();
		printf("\n");
		printf("Grant-related functions. Use -h with the above options to get\n");
		printf("option-specific help.\n");
	}
	if ((named || specific) && HaveCommand(ListObjects)) {
		printf("%s options:\n\n", named ? program_name : "ListObjects");
		//      12345678901234567890123 56789012345678901234567890123456789012345678901234567890
		printf("-env:<env-list>    Only show environments of types specified in <env-list>.\n");
		printf("                   Available types: all, cert, gpg, csp, net, keypair, key\n");
		printf("-table             Output in table format\n");
		printf("-type:<type-list>  Only show objects of types specified in <type-list>\n");
		printf("                   Available types: all, priv, pub, cert, key\n");
		PrintCommonSwitches();
		printf("\n");
		printf("Displays a list of all available objects. Defaults to list certificates from\n");
		printf("certificate environments.\n");
	}
	if ((named || specific) && (HaveCommand(RevokeGrant) || (HaveCommand(Grant) && revoke_flag))) {
		if (HaveCommand(RevokeGrant)) {
			printf("%s has no options.\n\n", named ? program_name : "RevokeGrant");
		} else {
			printf("%s has no options.\n\n", named ? program_name : "Grant -revoke");
		}
		PrintCommonSwitches();
		printf("\n");
		printf("Revokes the configured grant.\n");
	}
	if ((named || specific) && HaveCommand(SetUrl)) {
		printf("%s options:\n\n", named ? program_name : "SetUrl");
		printf("-authurl:<url>     HSM backend URL\n");
		printf("-hsmurl:<url>      Authentication server URL\n");
		PrintCommonSwitches();
		printf("\n");
		printf("Configured the HSM and authentication server URLs. Both URLs are required for\n");
		printf("proper operation of the PKCS#11 driver.\n");
	}
	if ((named || specific) && HaveCommand(Sign)) {
		printf("%s options:\n\n", named ? program_name : "Sign");
		printf("-file:<file>       File to sign\n");
		printf("-label:<label>     Label of the key to use for signing\n");
		printf("-output:<file>     Filename to store the signature in\n");
		PrintCommonSwitches();
		printf("\n");
		printf("Creates a signature for a file using the HSM backend directly.\n");
	}
	if ((named || specific) && HaveCommand(Verify)) {
		printf("%s options:\n\n", named ? program_name : "Verify");
		printf("-file:<file>       File to verify\n");
		printf("-input:<file>      Filename that holds the signature\n");
		printf("-label:<label>     Label of the key to use for verification\n");
		PrintCommonSwitches();
		printf("\n");
		printf("Verifies a signature created by the sign command.\n");
	}

	if (!CommandSelected()) {
		printf("%s Configuration Utility\n", program_name);
		printf("\n");
		printf("Available commands:\n");
		printf("  checkgrant       Checks the current grant status\n");
		printf("  getgrant         Obtains or refreshes new grant\n");
		printf("  grant            All grant commands\n");
		printf("  listobjects      Lists all available objects\n");
		printf("  revokegrant      Revokes a grant\n");
		printf("  seturl           Sets the backend and authentication URLs\n");
		printf("  sign             Create a signature for a file\n");
		printf("  verify           Verify a file signature\n");
		printf("\n");
		printf("To get command help, run '%s <command> -h'.\n", program_name);
	}
	printf("\n");
	printf("(c) %s Venafi, Inc.\n\n", APPLICATION_COPYRIGHT_YEARS);

	if (option_error != NULL) {
		printf("\n");
		printf("ERROR: Unrecognized ");
		if (HaveCommand(Grant)) printf("'grant' ");
		if (HaveCommand(ListObjects)) printf("'listobjects' ");
		if (HaveCommand(SetUrl)) printf("'seturl' ");
		if (HaveCommand(Sign)) printf("'sign' ");
		if (HaveCommand(Verify)) printf("'verify' ");
		printf("option '%s'.\n", option_error);
	} else if (error != NULL) {
		printf("\n%s\n", error);
	}
}

BOOL
HaveCommand(enum Commands command) {
	return selected_command[command];
}

void
SelectCommand(enum Commands command) {
	selected_command[command] = TRUE;
}

void
DeselectCommand(enum Commands command) {
	selected_command[command] = FALSE;
}

BOOL
CommandSelected() {
	int i;

	for (i = 0; i < NumOfCommands; i++) {
		if (selected_command[i]) {
			return TRUE;
		}
	}

	return FALSE;
}

int
CommandIndex() {
	int i;

	for (i = 0; i < NumOfCommands; i++) {
		if (selected_command[i]) {
			return i;
		}
	}

	return -1;
}

int
DoVersion() {
	const char *os_name;
	const char *os_version;

	printf("Venafi %s Configuration Utility (%s)\n\n", csp ? "CSP" : "PKCS#11", program_name);
	printf("Application: %d.%d.%d\n", APPLICATION_VERSION_MAJOR, APPLICATION_VERSION_MINOR, APPLICATION_VERSION_REV);
	printf("LibHSM:      %s\n", LibHsmGetVersion(libhsm));
	printf("Timestamp:   %s %s\n", __DATE__, __TIME__);
	if (verbose) {
		if (GetOSInfo(&os_name, &os_version)) {
			printf("\nOS information\n");
			printf("   Name:    %s\n", os_name);
			printf("   Version: %s\n", os_version);
		} else {
			printf("Could not obtain OS information\n");
		}
		printf("\nBuild information:\n");
#if defined(__OPTIMIZE__)
		printf("   Optimized build\n");
#if defined(__OPTIMIZE_SIZE__)
		printf("   Optimized for size\n");
#else
		printf("   Optimized for speed\n");
#endif
#endif
#if defined(_DEBUG)
		printf("   Debug build\n");
#else
		printf("   Release build\n");
#endif
#if defined(WIN32)
#if defined(_DLL)
		printf("   Shared runtime\n");
#else
		printf("   Static runtime\n");
#endif
#endif
	}
	printf("\n");
	printf("(c) %s Venafi, Inc.\n\n", APPLICATION_COPYRIGHT_YEARS);

	return 0;
}
