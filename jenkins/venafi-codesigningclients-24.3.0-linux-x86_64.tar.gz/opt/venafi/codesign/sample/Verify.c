//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#include "LibHsmSample.h"

int
DoVerify() {
	char buffer[1024];
	char *error_text;
	HsmObject *objects;
	HsmObject *current;
	HsmObject *key;
	LibHsmError *hsm_error;
	unsigned char *hash;
	unsigned char *signature;
	unsigned long signature_len;
	size_t hash_len;
	unsigned long sign_mechanism;
	FILE *input;
	FILE *signature_file;
	struct stat stat_info;
	int ret;

	key = NULL;
	input = NULL;
	signature_file = NULL;
	error_text = NULL;
	hsm_error = NULL;
	hash = NULL;
	hash_len = 0;
	signature = NULL;
	signature_len = 0;
	ret = -1;

	if (cert_label == NULL) {
		if (ReadLine("Signing key label: ", buffer, sizeof(buffer), FALSE) == NULL) {
			goto verify_failed;
		}
		if (buffer[0] != '\0') {
			cert_label = _strdup(buffer);
		}
		if (cert_label == NULL) {
			Usage(TRUE, NULL, "ERROR: -label required.\n");
			goto verify_failed;
		}
	}

	if (filename == NULL) {
		if (ReadLine("File to verify: ", buffer, sizeof(buffer), FALSE) == NULL) {
			goto verify_failed;
		}
		if (buffer[0] != '\0') {
			filename = _strdup(buffer);
		}
	}

	if (input_name == NULL) {
		if (ReadLine("File with signature: ", buffer, sizeof(buffer), FALSE) == NULL) {
			goto verify_failed;
		}
		if (buffer[0] != '\0') {
			input_name = _strdup(buffer);
		}
	}


	if ((filename == NULL) && (input_name == NULL)) {
		Usage(TRUE, NULL, "ERROR: -file and -input required.\n");
		goto verify_failed;
	}

	if (!FileExists(filename, NULL, NULL, NULL) || (fopen_s(&input, filename, "rb") != 0)) {
		printf("ERROR: Cannot find or open file '%s'.\n", filename);
		goto verify_failed;
	}

	if (!FileExists(input_name, NULL, NULL, NULL) || (fopen_s(&signature_file, input_name, "rb") != 0)) {
		printf("ERROR: Cannot find or open file '%s'.\n", filename);
		goto verify_failed;
	}

	if (!LibHsmGetObjectList(libhsm, &objects)) {
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error_text);
		printf("ERROR: Failed to retrieve key list.\n   %s\n", error_text);
		goto verify_failed;
	}

	if (objects == NULL) {
		printf("ERROR: No keys available.\n");
		goto verify_failed;
	}

	key = NULL;
	for (current = objects; current != NULL; current = current->next) {
		if (_stricmp((const char *)current->Label, cert_label) != 0) {
			continue;
		}
		if (current->ObjectType != CryptokiPublicKey) {
			continue;
		}
		key = current;
		break;
	}

	if (key == NULL) {
		printf("ERROR: Key '%s' does not exist.\n", cert_label);
		goto verify_failed;
	}

	hash = LibHsmGetFileHash((const unsigned char *)filename, &hsm_error);
	if (hash == NULL) {
		printf("ERROR: Unable to create file hash. [%s]\n", hsm_error->error);
		goto verify_failed;
	}
	hash_len = 32;	// LibHsmGetFileHash produces SHA-256

	if (verbose) {
		char *hex;

		if (Bin2Hex((BYTE *)hash, 32, &hex)) {
			printf("INFO: File hash is %s\n", hex);
			LibHsmFreeResult(hex);
		}
	}

	if (stat(input_name, &stat_info) != 0) {
		printf("ERROR: Unable to determine signature file size.\n");
		goto verify_failed;
	}
	signature_len = stat_info.st_size;

	signature = calloc(1, signature_len);
	if (signature == NULL) {
		printf("ERROR: Could not allocate signature buffer.\n");
		goto verify_failed;
	}

	if (fread(signature, 1, signature_len, signature_file) != signature_len) {
		printf("ERROR: Failed to read signature. [%d]\n", errno);
		goto verify_failed;
	}

	switch (key->PrivateKey.KeyType) {
		case CryptokiKeyRSA:
			sign_mechanism = CryptokiMechanismRsaSha256;
			break;

		case CryptokiKeyEC:
			sign_mechanism = CryptokiMechanismEcDsaSha256;
			break;

		case CryptokiKeyEC_EDWARDS:
			sign_mechanism = CryptokiMechanismEdDsa;
			break;

		default:
			printf("ERROR: Unsupported key type. [%d]\n", key->PrivateKey.KeyType);
			goto verify_failed;

	}

	if (!LibHsmVerifySignature(libhsm, key, sign_mechanism, NULL, hash, hash_len, signature, (size_t)signature_len)) {
		if (LibHsmHasError(libhsm, LibHsmErr_InvalidSignature, NULL)) {
			printf("ERROR: Invalid signature.");
		} else {
			LibHsmGetErrorText(libhsm, TRUE, "; ", &error_text);
			printf("ERROR: Failed to verify. [%s].", error_text);
		}
		goto verify_failed;
	}

	printf("SUCCESS: Signature is valid.\n");

	ret = 0;

verify_failed:
	if (signature != NULL) {
		free(signature);
	}

	if (hash != NULL) {
		LibHsmFreeResult(hash);
	}

	if (input != NULL) {
		fclose(input);
	}

	if (signature_file != NULL) {
		fclose(signature_file);
	}

	if (hsm_error != NULL) {
		LibHsmFreeError(hsm_error);
	}
	if (error_text != NULL) {
		LibHsmFreeErrorText(error_text);
	}

	return ret;
}
