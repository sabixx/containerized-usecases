//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#include "LibHsmSample.h"

int
DoGrant() {
	if (get) {
		return DoGetGrant();
	}
	if (revoke_flag) {
		return DoRevokeGrant(FALSE);
	}
	if (check) {
		return DoCheckGrant(FALSE);
	}
	return 0;
}

