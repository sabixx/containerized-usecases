//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#ifndef _LIBHSM_SAMPLE_H_
#define _LIBHSM_SAMPLE_H_

#include <platform.h>
#include <libhsm.h>

#define PRODUCT_SHORTNAME		"libhsm"
#define PKCS11_SHORTNAME		"pkcs11"
#define CSP_SHORTNAME			"CSP"
#define VENAFISCD_SHORTNAME		"scd"

#if !defined(APPLICATION_VERSION_MAJOR)
#define APPLICATION_VERSION_MAJOR	20
#endif

#if !defined(APPLICATION_VERSION_MINOR)
#define APPLICATION_VERSION_MINOR	2
#endif

#if !defined(APPLICATION_VERSION_REV)
#define APPLICATION_VERSION_REV		0
#endif

#define APPLICATION_COPYRIGHT_YEARS	"2020"

extern const char *error_sep_str;

enum Commands {
	CheckGrant,
	GetGrant,
	Grant,
	ListObjects,
	RevokeGrant,
	SetUrl,
	Sign,
	Verify,
	Version,
	NumOfCommands
};

extern const char *program_name;
extern LibHsmHandle libhsm;

extern BOOL selected_command[NumOfCommands];

extern char *auth_url;
extern char *cert_label;
extern char *chain_file;
extern BOOL check;
extern BOOL clear;
extern BOOL csp;
extern char *component;
extern BOOL console;
extern int days;
extern BOOL p11;
extern BOOL disable;
extern char *delete_name;
extern BOOL enable;
extern char *env_list;
extern BOOL export_der;
extern char *filename;
extern BOOL force;
extern BOOL get;
extern BOOL gpg;
extern char *hsm_url;
extern char *input_name;
extern BOOL log_flag;
extern BOOL machine;
extern char *module;
extern char *name;
extern BOOL named;
extern char *output_name;
extern BOOL revoke_flag;
extern BOOL root_first;
extern char *password;
extern char *pkcs11;
extern BOOL show;
extern BOOL split;
extern BOOL table;
extern char *type_list;
extern char *username;
extern char *value;
extern BOOL verbose;

BOOL SetDefaults();

int DoCheckGrant(BOOL validate);
int DoGetGrant();
int DoGrant();
int DoListObjects();
int DoRevokeGrant(BOOL quiet);
int DoSetUrl();
int DoSign();
int DoVerify();
int DoVersion();



/*** Pkcs11Configuration.c ***/
void Usage(BOOL specific, const char *option_error, const char *error);

int CommandIndex();
BOOL CommandSelected();
void DeselectCommand(enum Commands command);
BOOL HaveCommand(enum Commands command);
void SelectCommand(enum Commands command);

#endif	//_LIBHSM_SAMPLE_H_