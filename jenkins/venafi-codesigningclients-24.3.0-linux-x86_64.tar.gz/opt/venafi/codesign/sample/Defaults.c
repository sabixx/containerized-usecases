//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#define _GNU_SOURCE
#include "LibHsmSample.h"

extern char default_environments[128];
extern char default_objects[128];
extern char default_objects_verbose[128];

BOOL
SetDefaults() {
	if (p11) {
		/* Configuration name */
		component = PKCS11_SHORTNAME;

		/* ListObjects defaults */
		strcpy_s(default_environments, sizeof(default_environments), "all");
		strcpy_s(default_objects, sizeof(default_objects), "cert,pub");
		strcpy_s(default_objects_verbose, sizeof(default_objects_verbose), "all");
	}

	if (csp) {
		/* Configuration name */
		component = CSP_SHORTNAME;

		/* ListObjects defaults */
		strcpy_s(default_environments, sizeof(default_environments), "cert");
		strcpy_s(default_objects, sizeof(default_objects), "cert");
		strcpy_s(default_objects_verbose, sizeof(default_objects_verbose), "cert,pub,priv");
	}

	if (gpg) {
		/* Configuration name */
		component = VENAFISCD_SHORTNAME;

		/* ListObjects defaults */
		strcpy_s(default_environments, sizeof(default_environments), "gpg");
		strcpy_s(default_objects, sizeof(default_objects), "pub");
		strcpy_s(default_objects_verbose, sizeof(default_objects_verbose), "pub,priv");
	}
	return TRUE;
}