//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#include "LibHsmSample.h"

int
DoGetGrant() {
	char buffer[256];
	char *error;
	BOOL have_access_token;
	BOOL have_refresh_token;
	time_t valid_until;
	long days_valid;
	const char *url;

	Unchecked(memset(&valid_until, 0, sizeof(time_t)));

	if ((auth_url != NULL) || (hsm_url != NULL)) {
	set_url:
		if (DoSetUrl() != 0) {
			return -1;
		}
		// We require the server certificate to be trusted!
		LibHsmReinitialize(libhsm);
	}

	if (!LibHsmLoadConfiguration(libhsm)) {
		if ((LibHsmGetAuthUrl(libhsm) == NULL) || (LibHsmGetHsmUrl(libhsm) == NULL)) {
			goto set_url;
		}
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
		printf("ERROR: Configuration cannot be read.\n   %s\n", error);
		LibHsmFreeErrorText(error);
		return -1;
	}

	url = (const char *)LibHsmGetAuthUrl(libhsm);
	if (url == NULL) {
		printf("ERROR: No authentication server URL configured.\n");
		return -1;
	}

	if (!LibHsmGetGrantStatus(libhsm, &have_access_token, &have_refresh_token, &days_valid, &valid_until)) {
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
		printf("ERROR: Failed to obtain grant status.\n   %s\n", error);
		LibHsmFreeErrorText(error);
		return -1;
	}

	if (have_access_token && have_refresh_token && !force) {
		printf("INFO: Refreshing existing grant.\n");
	} else {
		printf("INFO: Requesting a new grant.\n");
	}

	if (!have_refresh_token || force) {
		if (username == NULL) {
			if (ReadLine("Please enter username: ", buffer, sizeof(buffer), FALSE) == NULL) {
				printf("ERROR: Username required.\n");
				return -1;
			}
			username = _strdup(buffer);
		}

		if (password == NULL) {
			if (ReadLine("Please enter password: ", buffer, sizeof(buffer), TRUE) == NULL) {
				printf("ERROR: Password required.\n");
				return -1;
			}
			password = _strdup(buffer);
		}
		if (have_access_token) {
			if (LibHsmOAuthRevokeGrant(libhsm)) {
				printf("INFO: Revoked existing grant.\n");
			}
		}
		if (!LibHsmOAuthRequestGrant(libhsm, username, password, OAUTH_HSM_SCOPE)) {
			LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
			printf("ERROR: Failed to obtain grant.\n   %s\n", error);
			LibHsmFreeErrorText(error);
			return -1;
		}
		DoCheckGrant(TRUE);
		printf("SUCCESS: New grant obtained.\n");
	} else {
		if (!LibHsmOAuthRefreshAccessToken(libhsm)) {
			LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
			printf("ERROR: Failed to refresh access token.\n   %s\n", error);
			LibHsmFreeErrorText(error);
			return -1;
		}
		DoCheckGrant(TRUE);
		printf("SUCCESS: Grant refreshed.\n");
	}

	return 0;
}

