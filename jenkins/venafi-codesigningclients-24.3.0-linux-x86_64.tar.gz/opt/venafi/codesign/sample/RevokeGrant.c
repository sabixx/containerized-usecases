//
// Copyright 2020 Venafi, Inc.
// All Rights Reserved.
// 
// This program is unpublished proprietary source code of Venafi, Inc.
// Your use of this code is limited to those rights granted in the license between you and Venafi.
// 
// Author: Peter Dennis Bartok (peter@venafi.com)
// 

#include "LibHsmSample.h"

int
DoRevokeGrant(BOOL quiet) {
	char buffer[256];
	char *error;
	ConfigHandle config;
	LibHsmError *hsm_error;
	BOOL have_access_token;
	BOOL have_refresh_token;
	time_t valid_until;
	long days_valid;
	const char *url;

	Unchecked(memset(&valid_until, 0, sizeof(time_t)));

	if ((auth_url != NULL) || (hsm_url != NULL)) {
	set_url:
		if (DoSetUrl() != 0) {
			return -1;
		}
	}

	if (!LibHsmLoadConfiguration(libhsm)) {
		if ((LibHsmGetAuthUrl(libhsm) == NULL) || (LibHsmGetHsmUrl(libhsm) == NULL)) {
			goto set_url;
		}
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
		if (!quiet) printf("ERROR: Configuration cannot be read.\n   %s\n", error);
		LibHsmFreeErrorText(error);
		return -1;
	}

	url = (const char *)LibHsmGetAuthUrl(libhsm);
	if (url == NULL) {
		if (!quiet) printf("ERROR: No authentication server URL configured.\n");
		return -1;
	}

	if (!LibHsmGetGrantStatus(libhsm, &have_access_token, &have_refresh_token, &days_valid, &valid_until)) {
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
		if (!quiet) printf("ERROR: Failed to obtain grant status.\n   %s\n", error);
		LibHsmFreeErrorText(error);
		return -1;
	}

	if (!have_access_token) {
		if (!quiet) printf("ERROR: No access token to revoke configured.\n");
		return -1;
	}

	if (!quiet && !force) {
		struct tm tm_info;
		char time_buf[128];

		localtime_s(&tm_info, &valid_until);
		strftime(time_buf, sizeof(time_buf) / sizeof(char), "%c", &tm_info);

		if (days_valid > 0) {
			if (!quiet) printf("Grant is valid until %s, %ld days from now.\n", time_buf, days_valid);
		}

		if (ReadLine("Confirm you want to revoke the grant (y/N): ", buffer, sizeof(buffer), FALSE) == NULL) {
			return -1;
		}
		if (tolower(buffer[0]) != 'y') {
			return -1;
		}
	}
	if (!LibHsmOAuthRevokeGrant(libhsm)) {
		LibHsmGetErrorText(libhsm, TRUE, error_sep_str, &error);
		if (!quiet) printf("ERROR: Failed to revoke grant.\n   %s\n", error);
		LibHsmFreeErrorText(error);
		return -1;
	}

	if (clear) {
		if (!LibHsmConfLoad(component, machine, &config, &hsm_error)) {
			printf("ERROR: Unable to cleanup configuration. [%s]\n", hsm_error->error);
			LibHsmFreeError(hsm_error);
		} else {
			LibHsmConfDelete(config);
			if (!LibHsmConfFree(config, &hsm_error)) {
				printf("ERROR: Unable to cleanup configuration. [%s]\n", hsm_error->error);
				LibHsmFreeError(hsm_error);
			} else {
				printf("INFO: Configuration was removed\n");
			}
		}
	}

	if (!quiet) printf("SUCCESS: Grant revoked.\n");
	return 0;
}

