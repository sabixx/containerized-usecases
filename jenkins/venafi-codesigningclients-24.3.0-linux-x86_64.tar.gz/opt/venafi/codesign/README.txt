# Venafi Code Signing Clients Portable Distribution

The portable distribution behaves the same as the standard installation.

For more details, please visit: 
	https://docs.venafi.com/Docs/current/TopNav/Content/CodeSigning/t-codesigning-install-csp.php

